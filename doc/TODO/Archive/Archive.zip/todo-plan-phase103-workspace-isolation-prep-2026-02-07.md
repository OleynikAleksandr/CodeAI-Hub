# План разработки (Development TODO Plan)

## Правила выполнения (Execution Rules):
- **TODO Plan** состоит из Phase (Фаз). В каждой Phase — Stream (стрим) с микрозадачами.
- Каждая микрозадача затрагивает **≤ 3 файлов**.
- Каждая микрозадача оформляется парой пунктов: (1) реализация/изменения, (2) `Git Commit: ...` отдельной строкой.
- **Gates после каждой микрозадачи**: `./scripts/check-architecture.sh`, `npx ultracite check`, `npx ts-prune`, `npx jscpd --threshold 3 --silent --reporters console src --ignore "**/node_modules/**"`, `npm run check:links`, затем таргетная сборка/тест затронутых пакетов.
- После зелёных гейтов — Git Commit, затем сразу обновляем статусы/хеши в `doc/TODO/todo-plan.md`.
- Любые изменения логики/архитектуры синхронно отражаются в документации (`doc/SolidWorks-Flow/System/**`) в том же коммите.
- Любая фаза завершается только после чистого `git status` и фиксации session report.

## Required documents to review before work
1. `doc/SolidWorks-Flow/System/SystemArchitecture.md`
2. `doc/SolidWorks-Flow/SessionContinuity/Core/FlowNodeContinuity_InputLock_Contract_Architecture.md`
3. `doc/SolidWorks-Flow/SessionContinuity/Core/FlowNodeContinuity_TurnEnd_AtomicLock_Architecture.md`
4. `doc/TODO/Archive/todo-plan-phase100-continuity-ux-release-2026-02-06.md`
5. `doc/Sessions/Archive/Session104.md`
6. `doc/TODO/todo-plan.md` (THIS FILE)

---

## Phase 101 — Turn-End Continuity Lock Atomicity (owner: Oleksandr, updated: 2026-02-07)

### Stream: eliminate unlock gap before continuity relock + release
1. [DONE] Docs(design): утвердить архитектурный контракт атомарного turn-end lock arbitration и синхронизировать cross-links в continuity/system docs (scope: `doc/SolidWorks-Flow/SessionContinuity/Core/FlowNodeContinuity_TurnEnd_AtomicLock_Architecture.md`, `doc/SolidWorks-Flow/System/SystemArchitecture.md`; expected commit message: `docs(continuity): define turn-end atomic lock arbitration contract`)
2. [DONE] Git Commit: `docs(continuity): define turn-end atomic lock arbitration contract` (hash: b96c6485)
3. [DONE] Feat(core-arbitration): перенести проверку threshold/continuity decision перед unlock на границе `turn_completed` (без sequence `unlock -> relock`) (scope: `packages/core/src/remote-bridge/handlers/session-request-handler.ts`; expected commit message: `fix(core): decide continuity before turn-end unlock`)
4. [DONE] Git Commit: `fix(core): decide continuity before turn-end unlock` (hash: b58d7904)
5. [DONE] Feat(core-guard): добавить server-side guard для send в old session при `rollover pending` (queue/reject policy по контракту) (scope: `packages/core/src/remote-bridge/handlers/session-request-handler.ts`, `packages/core/src/remote-bridge/handlers/session-request-handler.types.ts`; expected commit message: `fix(core): guard old-session sends while rollover pending`)
6. [DONE] Git Commit: `fix(core): guard old-session sends while rollover pending` (hash: a0ce89e9)
7. [DONE] Fix(pm-stream): исключить transient unlock в PM snapshot между `turn_completed` и continuity-lock при pending decision (scope: `src/client/project-manager/components/sessions/token-usage-stream.ts`; expected commit message: `fix(pm): avoid transient unlock during continuity decision`)
8. [DONE] Git Commit: `fix(pm): avoid transient unlock during continuity decision` (hash: 7c0ebcf1)
9. [DONE] Fix(ui-lock): выровнять effective lock predicate в SessionView/InputPanel на период continuity decision pending (scope: `src/client/ui/src/session/session-view.tsx`, `src/client/ui/src/session/input-panel.tsx`; expected commit message: `fix(ui): keep input locked until continuity decision resolves`)
10. [DONE] Git Commit: `fix(ui): keep input locked until continuity decision resolves` (hash: 3a57a123)
11. [DONE] Test(core): добавить регрессионные тесты на отсутствие `unlock -> relock` и на send guard в old session (scope: `packages/core/src/remote-bridge/handlers/session-request-handler.test.ts`; expected commit message: `test(core): cover turn-end continuity lock atomicity`)
12. [DONE] Git Commit: `test(core): cover turn-end continuity lock atomicity` (hash: 2119f937)
13. [DONE] Test(pm-ui): добавить регрессионные тесты, что поле не становится enabled в transition window (scope: `src/client/project-manager/components/sessions/token-usage-stream.test.ts`, `src/client/ui/src/session/input-panel.test.tsx`; expected commit message: `test(ui): prevent transient unlock between turn end and continuity lock`)
14. [DONE] Git Commit: `test(ui): prevent transient unlock between turn end and continuity lock` (hash: 777e4be9)
15. [DONE] Docs(release): синхронизировать `README.md`, `CHANGELOG.md` и новый session report под итог Phase 101 (scope: `README.md`, `CHANGELOG.md`, `doc/Sessions/Archive/Session104.md`; expected commit message: `docs(release): prepare notes for turn-end lock atomicity release`)
16. [DONE] Git Commit: `docs(release): prepare notes for turn-end lock atomicity release` (hash: 56e80735)
17. [DONE] Release: выполнить `./scripts/build-all.sh` после закрытия всех задач Stream и чистого дерева (scope: repo-wide automated release files; expected commit message: `chore(release): build-all after turn-end lock atomicity`)
18. [DONE] Git Commit: `chore(release): build-all after turn-end lock atomicity` (hash: a24af8f2)
19. [DONE] Release: выполнить `./scripts/build-release.sh --use-current-version`, проверить VSIX/артефакты и зафиксировать пути в session report (scope: repo-wide release artifacts + docs; expected commit message: `chore(release): build vsix after turn-end lock atomicity`)
20. [DONE] Git Commit: `chore(release): build vsix after turn-end lock atomicity` (hash: 863fb0f4)

---

## Phase 102 — Continuity Unlock + ACK Normalization Hotfix (owner: Oleksandr, updated: 2026-02-07)

### Stream: fix target-session unlock regression + normalize continuity ACK + release
1. [DONE] Docs(design): зафиксировать hotfix-контракт по снятию lock после `continuity_lock=unlocked` и унификации internal ACK-фразы во всех continuity templates (scope: `doc/SolidWorks-Flow/SessionContinuity/Core/FlowNodeContinuity_TurnEnd_AtomicLock_Architecture.md`, `doc/SolidWorks-Flow/SessionContinuity/Core/FlowNodeContinuity_InputLock_Contract_Architecture.md`; expected commit message: `docs(continuity): define unlock resolution and ack normalization hotfix contract`)
2. [DONE] Git Commit: `docs(continuity): define unlock resolution and ack normalization hotfix contract` (hash: 6527c30e)
3. [DONE] Fix(pm-rollover): устранить залипание `blocked` в новой session после `continuity_lock=unlocked` при `rollover.phase=resume_sent` (scope: `src/client/project-manager/components/sessions/token-usage-stream.ts`; expected commit message: `fix(pm): clear rollover pending state after continuity unlock`)
4. [DONE] Git Commit: `fix(pm): clear rollover pending state after continuity unlock` (hash: 5b7dbc76)
5. [DONE] Fix(ui-lock): синхронизировать lock-предикат SessionView с terminal-семантикой rollover после unlock (без вечного pending по `resume_sent`) (scope: `src/client/ui/src/session/session-view.tsx`; expected commit message: `fix(ui): resolve effective lock after rollover unlock`)
6. [DONE] Git Commit: `fix(ui): resolve effective lock after rollover unlock` (hash: 1764a9cb)
7. [DONE] Fix(core-templates): перевести continuity ACK на `Ready to continue working.` во всех трёх flow continuity templates (источник релизной синхронизации templatesDir) (scope: `packages/core/src/flow-node-continuity/template-loader.ts`, `assets/flow/continuity/create-report-doc.md`, `assets/flow/continuity/create-report-code.md`; expected commit message: `fix(core): normalize continuity ack phrase across all templates`)
8. [DONE] Git Commit: `fix(core): normalize continuity ack phrase across all templates` (hash: a8cb9326)
9. [DONE] Fix(ui-filter): расширить фильтрацию internal continuity ACK (включая markdown-backtick вариант legacy token), чтобы служебная фраза не появлялась в диалоге (scope: `src/client/ui/src/session/virtual-conversation.tsx`; expected commit message: `fix(ui): suppress legacy continuity ack token variants in virtual conversation`)
10. [DONE] Git Commit: `fix(ui): suppress legacy continuity ack token variants in virtual conversation` (hash: abcd8201)
11. [DONE] Test(pm-ui): добавить регрессии на (a) unlock после `resume_sent + continuity_lock(unlocked)` и (b) suppression legacy/new ACK variants в virtual conversation (scope: `src/client/project-manager/components/sessions/token-usage-stream.test.ts`, `src/client/ui/src/session/input-panel.test.tsx`, `src/client/ui/src/session/virtual-conversation.test.tsx`; expected commit message: `test(ui): cover rollover unlock release and continuity ack suppression`)
12. [DONE] Git Commit: `test(ui): cover rollover unlock release and continuity ack suppression` (hash: 38652a43)
13. [DONE] Docs(release): синхронизировать `README.md`, `CHANGELOG.md` и новый session report под hotfix Phase 102 (scope: `README.md`, `CHANGELOG.md`, `doc/Sessions/Archive/Session105.md`; expected commit message: `docs(release): prepare notes for continuity unlock and ack hotfix`)
14. [DONE] Git Commit: `docs(release): prepare notes for continuity unlock and ack hotfix` (hash: d901b6d6)
15. [DONE] Release: выполнить `./scripts/build-all.sh` после закрытия всех задач Stream и чистого дерева (scope: repo-wide automated release files; expected commit message: `chore(release): build-all after continuity hotfix`)
16. [DONE] Git Commit: `chore(release): build-all after continuity hotfix` (hash: 5b380aaf)
17. [DONE] Release: выполнить `./scripts/build-release.sh --use-current-version`, проверить VSIX/артефакты и зафиксировать пути в session report (scope: repo-wide release artifacts + docs; expected commit message: `chore(release): build vsix after continuity hotfix`)
18. [DONE] Git Commit: `chore(release): build vsix after continuity hotfix` (hash: 2ba89f9b)

---

## Phase 103 — Core-first Immediate Input Lock Parity (owner: Oleksandr, updated: 2026-02-07)

### Stream: centralize immediate lock on send in Core + rollback on provider send error
1. [DONE] Docs(design): зафиксировать контракт Core-first мгновенного lock (`turn_state=running` до `adapter.sendMessage`) и rollback в `idle` при send-error; синхронизировать continuity/system docs (scope: `doc/SolidWorks-Flow/SessionContinuity/Core/FlowNodeContinuity_TurnEnd_AtomicLock_Architecture.md`, `doc/SolidWorks-Flow/System/SystemArchitecture.md`; expected commit message: `docs(continuity): define core-first immediate lock and send-error rollback contract`)
2. [DONE] Git Commit: `docs(continuity): define core-first immediate lock and send-error rollback contract` (hash: 8f008571)
3. [DONE] Feat(core-lock): централизовать мгновенную блокировку в `handleMessage` (emit `turn_state=running` до вызова `adapter.sendMessage`) для унификации поведения всех провайдеров (scope: `packages/core/src/remote-bridge/handlers/session-request-handler.ts`; expected commit message: `fix(core): emit immediate running state before provider send`)
4. [DONE] Git Commit: `fix(core): emit immediate running state before provider send` (hash: 0600aaac)
5. [DONE] Fix(core-rollback): на ошибке `adapter.sendMessage` выполнять rollback состояния (`turn_state=idle`) и сохранять корректный error-flow без stuck-lock (scope: `packages/core/src/remote-bridge/handlers/session-request-handler.ts`; expected commit message: `fix(core): rollback running state on provider send failure`)
6. [DONE] Git Commit: `fix(core): rollback running state on provider send failure` (hash: 6b318581)
7. [DONE] Test(core): добавить регрессии на (a) immediate lock до stream `turn_started` и (b) rollback в `idle` при provider send failure (scope: `packages/core/src/remote-bridge/handlers/session-request-handler.test.ts`; expected commit message: `test(core): cover immediate lock and send-error rollback`)
8. [DONE] Git Commit: `test(core): cover immediate lock and send-error rollback` (hash: a91814c4)
9. [DONE] Test(pm-ui): добавить интеграционные регрессии parity Claude/Codex по блокировке поля ввода сразу после submit (до первого provider stream marker) (scope: `src/client/project-manager/components/sessions/token-usage-stream.test.ts`, `src/client/ui/src/session/input-panel.test.tsx`; expected commit message: `test(ui): enforce provider-agnostic immediate input lock parity`)
10. [DONE] Git Commit: `test(ui): enforce provider-agnostic immediate input lock parity` (hash: 864d3119)
11. [DONE] Docs(release): синхронизировать `README.md`, `CHANGELOG.md` и новый session report под итог Phase 103 (scope: `README.md`, `CHANGELOG.md`, `doc/Sessions/Archive/Session108.md`; expected commit message: `docs(release): prepare notes for immediate input lock parity release`)
12. [DONE] Git Commit: `docs(release): prepare notes for immediate input lock parity release` (hash: fe7db5e5)
13. [DONE] Release: выполнить `./scripts/build-all.sh` после закрытия всех задач Stream и чистого дерева (scope: repo-wide automated release files; expected commit message: `chore(release): build-all after immediate lock parity`)
14. [DONE] Git Commit: `chore(release): build-all after immediate lock parity` (hash: 5a64cac5)
15. [DONE] Release: выполнить `./scripts/build-release.sh --use-current-version`, проверить VSIX/артефакты и зафиксировать пути в session report (scope: repo-wide release artifacts + docs; expected commit message: `chore(release): build vsix after immediate lock parity`)
16. [DONE] Git Commit: `chore(release): build vsix after immediate lock parity` (hash: 4d83fe05)
