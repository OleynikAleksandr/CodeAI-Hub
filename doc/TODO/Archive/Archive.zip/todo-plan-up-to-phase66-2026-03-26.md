# План разработки (Development TODO Plan)

## Правила выполнения (Execution Rules):
- **Required reading (прочитать перед каждым фиксом):** `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- Перед работой по этому scope открыть: `AGENTS.md`, `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`, `doc/Sessions/Archive/Session156.md`
- Каждая микро-задача оформляется парой пунктов: (1) реализация/изменения, (2) отдельный пункт `Git Commit: ...`
- Статусы: `TODO`, `IN_PROGRESS`, `DONE`, `BLOCKED`
- Каждая микро-задача должна затрагивать не более 3 файлов; если scope разрастается, stream нужно дробить заново
- Husky gates не обходить (`--no-verify` запрещен)
- Любые изменения логики/архитектуры синхронно отражать в документации `doc/` до коммита
- Перед закрытием stream выполнять таргетные проверки затронутых пакетов/клиентов
- После закрытия release stream: выполнить `./scripts/build-all.sh`, затем `./scripts/build-release.sh --use-current-version`, записать результаты в `doc/Sessions/`

---

## Phase 64 — Full gemini-cli-core@0.35.0 compatibility (owner: Oleksandr, updated: 2026-03-25)

### Problem statement
`@google/gemini-cli-core@0.35.0` внёс breaking changes в tool execution API:
1. `nonInteractiveToolExecutor` полностью удалён — наш legacy путь мёртв
2. `CoreToolScheduler` конструктор изменился: `config: Config` → `context: AgentLoopContext`
3. `AgentLoopContext` = `{ config, promptId, toolRegistry, messageBus, geminiClient, sandboxManager }`
4. Добавлены новые `GeminiEventType`: `ModelInfo`, `AgentExecutionStopped`, `AgentExecutionBlocked`

Результат: все tool calls Gemini провайдера падают с `TypeError: Cannot read properties of undefined (reading 'messageBus')`, сессия "зависает".

### Key finding
`Config` в 0.35.0 содержит deprecated getters для `toolRegistry`, `messageBus`, `geminiClient`, `sandboxManager`, `promptId`. Собираем `AgentLoopContext` из Config и передаём в CoreToolScheduler как `context`.

### Stream 1: Fix CoreToolScheduler API + remove legacy executor

1. [DONE] **Rewrite `gemini-tool-executor-facade.ts`** — полная адаптация к CoreToolScheduler@0.35.0:
   - Удалён `SchedulerConstructor` cast-тип — заменён на `SchedulerConstructor035` с `AgentLoopContextLike`
   - Удалён legacy branch (`modules.toolExecutor?.executeToolCall`) — в 0.35.0 его нет
   - В `execute()`: собирается `AgentLoopContext` из `config` (deprecated getters) + `promptId` из `request.prompt_id`
   - Передаётся `{ context, getPreferredEditor, onAllToolCallsComplete }` — убран `onEditorClose`
   (scope: `packages/Gemini_Module/src/session/gemini-tool-executor-facade.ts` — 1 файл)

2. [DONE] Git Commit: `fix(gemini): rewrite tool executor for CoreToolScheduler@0.35.0 AgentLoopContext API` (hash: 5734f1fe)

### Stream 2: Clean up dead legacy code in cli-bridge & cli-types

3. [DONE] **Remove `nonInteractiveToolExecutor` from `cli-bridge.ts` and `cli-types.ts`**:
   - `cli-types.ts`: удалён `toolExecutor`, `GeminiToolExecutionBackend`, `toolExecutionBackend`
   - `cli-bridge.ts`: удалён `findAndLoadOptionalModule`, `isModuleNotFoundError`, `resolveToolExecutionBackend()`, убраны поля из `loadGeminiModules()`
   - `types/index.ts`: удалён `toolExecutionBackend` из `GeminiCliBridgeMetadata`
   - Тесты обновлены: `cli-bridge.test.ts`, `gemini-tool-executor-facade.test.ts`

4. [DONE] Git Commit: `refactor(gemini): remove dead nonInteractiveToolExecutor legacy code` (hash: 21e4eef7)

### Stream 3: Handle new GeminiEventType values

5. [DONE] **Add handlers for new 0.35.0 events** in `message-processor.ts`:
   - `ModelInfo` — emit system event с информацией о модели
   - `AgentExecutionStopped` — emit warning с причиной
   - `AgentExecutionBlocked` — emit warning с причиной

6. [DONE] Git Commit: `feat(gemini): handle ModelInfo, AgentExecutionStopped, AgentExecutionBlocked events` (hash: c025e817)

### Stream 4: Targeted build & verification (Phase 64)

7. [DONE] **Targeted build** — `npm run build --workspace packages/Gemini_Module` — TS fix applied and build clean.
8. [TODO] **Functional test** — запустить Gemini сессию в PM, проверить:
   - tool calls (read_file, run_shell_command) выполняются
   - thoughts отображаются
   - content streaming работает

---

## Phase 65 — Gemini Thought Translator: real-time Russian translation via Flash (owner: Oleksandr, updated: 2026-03-25)

### Problem statement
Gemini (в отличие от Claude и Codex) не выдаёт промежуточные текстовые ответы пользователю. Thoughts приходят на английском, скрыты под плашкой. Пользователь 3-5 минут смотрит пустой экран диалога.

### Solution: Variant B — Gemini Flash translator
Каждый incoming Thought event параллельно (fire-and-forget) отправляется в `gemini-2.0-flash-lite` для перевода на русский. Результат показывается в диалоге как промежуточный ответ агента. Основной поток не блокируется.

Ключевые параметры:
- Thoughts приходят с интервалами 30-90 сек → latency Flash (1-2 сек) не проблема
- Промпт: ~30 токенов инструкции + ~100-200 токенов thought → ~250 токенов вход, ~150 выход
- Стоимость: практически нулевая (Flash-lite бесплатный tier)
- Graceful degradation: если Flash упал — мысль просто не переводится, основная сессия не страдает
- SDK `@google/genai` уже в зависимостях, API ключ у пользователя уже есть

### Stream 1: Create ThoughtTranslatorService

1. [DONE] **Create `thought-translator-service.ts`** (~70 строк):
   - GoogleGenAI клиент, модель gemini-2.0-flash-lite, промпт на английском
   - Fire-and-forget: логирует через reporter, null при сбое, 5 сек timeout

2. [DONE] Git Commit: `feat(gemini): add ThoughtTranslatorService for real-time Russian translation via Flash` (hash: TBD)

### Stream 2: Integrate translator into message-processor

3. [DONE] **Update `message-processor.ts`** — fire-and-forget `.then()` in handleThoughtEvent
4. [DONE] **Wire service in `gemini-session-manager.ts`** — capture GOOGLE_API_KEY before sanitize, pass to MessageProcessor
5. [DONE] Git Commit: `feat(gemini): integrate thought translation into message processor pipeline` (hash: TBD)

### Stream 3: Targeted build & verification (Phase 65)

6. [DONE] **Targeted build** — `npm run build --workspace packages/Gemini_Module` — clean after fixing biome import issues.
7. [TODO] **Functional test** — запустить Gemini сессию в PM, проверить:
   - Thoughts переводятся на русский и появляются в диалоге
   - Thinking-плашка по-прежнему отображает оригинал
   - При ошибке Flash (нет сети, невалидный ключ) — основная сессия не ломается
   - Latency перевода не задерживает основной поток

### Stream 4: Release build

8. [DONE] Update `README.md`, `CHANGELOG.md` for new version.
9. [DONE] Update `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` — ThoughtTranslatorService section added.
10. [DONE] Git Commit: `docs: update README, CHANGELOG, SystemArchitecture` (hash: 67c519f7)
11. [DONE] `./scripts/build-all.sh` → version 1.1.801, all providers/core/UI/launcher built.
12. [DONE] `./scripts/build-release.sh --use-current-version` → `codeai-hub-1.1.801.vsix` (1.5M).
13. [DONE] Git Commit: `chore(release): bump version to 1.1.801` (hash: 1a5d827b)
14. [DONE] Create `doc/Sessions/Archive/Session158.md`.

---

## Phase 66 — Gemini model registry update: remove 2.5, fix 3.1 Pro ID (owner: Oleksandr, updated: 2026-03-25)

### Problem statement
1. `gemini-3-pro-preview` deprecated 9 марта 2026, перенаправляется на `gemini-3.1-pro-preview`
2. Модели `gemini-2.5-*` устарели — убираем из UI и registry
3. `resolveThinkingConfig()` содержит ветку для `gemini-2.5-` которая больше не нужна

### Target state
Только 2 модели:
- `gemini-3.1-pro-preview` — Gemini 3.1 Pro (flagship reasoning, 1M context)
- `gemini-3-flash-preview` — Gemini 3 Flash (Pro-level at Flash speed/cost)

Default: `gemini-3.1-pro-preview`

### Stream 1: Update model registry + Settings UI types

1. [DONE] **Update `src/types/gemini-model-registry.ts`**: 2 models, default 3.1 Pro, family "gemini-3"
2. [DONE] Git Commit: `feat(gemini): update model registry — remove 2.5, add gemini-3.1-pro-preview` (hash: TBD)

### Stream 2: Update Gemini_Module thinking config

3. [DONE] Removed gemini-2.5 branch, widened prefix to `"gemini-3"` (covers 3-flash + 3.1-pro)
4. [DONE] Git Commit: `refactor(gemini): remove 2.5 thinking config branch` (hash: TBD)

### Stream 3: Targeted build + verification

5. [TODO] `npm run build --workspace packages/Gemini_Module` + `npm run build:webview` + `npm run typecheck:webview`
6. [TODO] Git Commit + build-all → build-release → VSIX
