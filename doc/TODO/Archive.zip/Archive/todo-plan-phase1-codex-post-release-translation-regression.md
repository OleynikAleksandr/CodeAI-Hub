# План разработки (Development TODO Plan)

## Context Pack For This Cycle
- **Planning source:** `doc/SolidWorks-WorkFlow/Plans/Codex_PostRelease_TranslationRegression_Architecture.md`
- **Read this context before implementation:**
  - `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
  - `doc/SolidWorks-WorkFlow/Modules/Codex.md`
  - `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md`
  - `doc/SolidWorks-WorkFlow/Modules/Localization.md`
  - `doc/SolidWorks-WorkFlow/Contracts/UserFacing_Text_Localization_Boundary.md`
  - `doc/SolidWorks-WorkFlow/Contracts/Codex_ResponseMode_Settings_Architecture.md`
- Только этот список является источником документов для восстановления контекста текущего execution cycle.

## Правила выполнения (Execution Rules):
- **Required reading (прочитать перед каждым фиксом):** `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- **TODO Plan** состоит из Phase (Фаз). В каждой Phase некоторое количество Stream (стрим), в каждом Stream некоторое количество подзадач.
- Каждая подзадача должна затрагивать не более 3 файлов.
- Каждая подзадача оформляется парой пунктов: (1) реализация/изменения, (2) `Git Commit: ...` (отдельной строкой).
- Если по факту разработки оказывается, что конкретная подзадача Stream затрагивает больше 3 файлов, задача должна быть разбита на более мелкие, а список задач в Stream переписан.
- **Gates (автоматически через Husky hooks):**
  - `git commit` → `.husky/pre-commit`: `./scripts/check-architecture.sh`, `npm run lint`, `npm run check:knip`, `npm run format:fix`
  - `git push` → `.husky/pre-push`: `npm run check:dup`, `npm run check:links`
- **Таргетные сборки** выполняем вручную только когда нужно проверить затронутый пакет/клиент, и обязательно перед закрытием Stream/Phase: `npm run build --workspace <package>`, `npm run build:webview`, `npm run typecheck:webview`.
- **Commit**: После зеленых гейтов — Git Commit с максимально релевантным описанием (код + доки) и апдейт `todo-plan.md` (дата, статус, хеш).
- **Real-time Документация**: любое изменение архитектуры/логики требует синхронного обновления связанной документации из `doc/` до коммита, чтобы измененные документы попали в тот же commit.

## Phase 1 — Codex translation regression forensic and fix (owner: Codex, updated: 2026-04-13)
### Stream: Post-release regression triage
1. [DONE] Correlate the latest failing workspace session for `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4`, confirm effective settings plus settings/core/sdk/rollout/unified-session evidence, and capture the root-cause hypothesis in the planning doc. scope: `doc/SolidWorks-WorkFlow/Plans/Codex_PostRelease_TranslationRegression_Architecture.md`, `doc/TODO/todo-plan.md`, runtime logs/artifacts; expected commit message: `docs: start codex post-release translation regression scope`
2. [DONE] Git Commit: `docs: start codex post-release translation regression scope` (hash: `3dbd24528`)
3. [DONE] Isolate and fix the PM-side workflow prompt path that dropped `Artifacts for the User` language back to default `en` when live settings cache was unavailable after restart/reconnect; keep regression coverage and SSOT in sync. scope: `src/client/project-manager/services/description-submit-service.ts`, `src/client/project-manager/services/description-submit-service.localization.test.ts`, `doc/SolidWorks-WorkFlow/Modules/Localization.md`; expected commit message: `fix: preserve workflow artifact language after pm restart`
4. [DONE] Git Commit: `fix: preserve workflow artifact language after pm restart` (hash: `568b56a35`)
5. [TODO] Reproduce the fixed PM prompt-pack path on a fresh Project Manager reconnect/cold-start against workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4` and decide whether the current scope should continue into a release hotfix build. scope: runtime verification only, no more than 3 touched files if follow-up changes are needed; expected commit message: `docs: close codex artifact language fallback scope`
6. [TODO] Git Commit: `docs: close codex artifact language fallback scope` (hash: TBD)
