# План разработки (Development TODO Plan)

## Context Pack For This Cycle
- **Planning source:** `doc/SolidWorks-WorkFlow/Plans/ThinkingTranslationOverlay_Architecture.md`
- **Read this context before implementation:**
  - `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
  - `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md`
  - `doc/SolidWorks-WorkFlow/Modules/Localization.md`
  - `doc/SolidWorks-WorkFlow/Contracts/Gemini_ThoughtTranslation.md`
  - `doc/SolidWorks-WorkFlow/Modules/Session_UI/README.md`
  - `doc/SolidWorks-WorkFlow/Modules/Session_UI/SessionStatusPanel.md`
  - `doc/SolidWorks-WorkFlow/Modules/Session_UI/SessionIdUsageBar.md`
  - `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- Только этот список является источником документов для восстановления контекста текущего execution cycle.

## Правила выполнения (Execution Rules):
- **Required reading (прочитать перед каждым фиксом):** `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- Каждая подзадача должна затрагивать не более 3 файлов.
- Каждая подзадача оформляется парой пунктов: реализация/изменения, затем отдельный пункт `Git Commit: ...`.
- После каждого закрытого пункта план обновляется сразу, даже если `doc/TODO` остаётся local-only.
- Husky hooks не обходим. Диагностические ручные команды используем только при необходимости.
- Перед закрытием релизного стрима выполнить `README.md` / `CHANGELOG.md` update на будущую версию, затем `./scripts/build-all.sh`, затем `./scripts/build-release.sh --use-current-version`.

## Phase 1 — Thinking Translation Overlay Foundations (owner: Codex, updated: 2026-04-13)
### Stream: Cycle Kickoff Docs
1. [DONE] Активировать execution cycle: локальный `todo-plan.md` + approved planning-doc + `Docs_Index`; scope: `doc/TODO/todo-plan.md`, `doc/SolidWorks-WorkFlow/Plans/ThinkingTranslationOverlay_Architecture.md`, `doc/SolidWorks-WorkFlow/Docs_Index.md`; expected commit: `docs: start thinking translation overlay cycle`
2. [DONE] Git Commit: `docs: start thinking translation overlay cycle` (hash: 5f4b36fdf)

### Stream: Unified Session Overlay Storage
3. [DONE] Добавить sidecar storage для persisted message translations в unified-session; scope: `packages/unified-session/src/session-translation-overlay-store.ts`, `packages/unified-session/src/index.ts`; expected commit: `feat: add unified session translation overlay store`
4. [DONE] Git Commit: `feat: add unified session translation overlay store` (hash: 7b7419e82)
5. [DONE] Добавить Core policy resolver для языка/engine и hash helper для source text; scope: `packages/core/src/config/provider-settings-snapshot.ts`, `packages/core/src/session-translation/session-translation-policy-resolver.ts`, `packages/core/src/session-translation/session-message-source-hash.ts`, `packages/core/src/remote-bridge/handlers/session-request-handler-applied-turn-config.ts`; expected commit: `feat: add translation overlay policy resolver`
6. [DONE] Git Commit: `feat: add translation overlay policy resolver` (hash: a23264e4b)

### Stream: Core Translation Pipeline
7. [DONE] Создать Core facade для scheduling translation overlays; scope: `packages/core/src/session-translation/session-translation-facade.ts`, `packages/core/src/session-translation/session-translation-dispatcher.ts`, `packages/core/src/remote-bridge/handlers/session-request-handler-runtime-core.ts`; expected commit: `feat: add core session translation facade`
8. [DONE] Git Commit: `feat: add core session translation facade` (hash: b91b950b9)
9. [DONE] Протянуть stable message identity в runtime append path; scope: `packages/core/src/session-manager/index.ts`, `packages/core/src/remote-bridge/handlers/session-request-handler-event-messages.ts`; expected commit: `feat: preserve dialog message ids for translation overlays`
10. [DONE] Git Commit: `feat: preserve dialog message ids for translation overlays` (hash: f3ead6061)
11. [DONE] Добавить новые bridge events для translation patches; scope: `packages/core/src/remote-bridge/session-stream-contracts.ts`, `packages/core/src/remote-bridge/types.ts`; expected commit: `feat: add session translation bridge events`
12. [DONE] Git Commit: `feat: add session translation bridge events` (hash: d8528b302)
13. [DONE] Persist translated overlays и добавить live patch broadcast; scope: `packages/core/src/unified-session/storage.ts`, `packages/core/src/remote-bridge/handlers/session-request-handler-event-messages.ts`, `packages/core/src/remote-bridge/handlers/session-request-handler-runtime-core.ts`; expected commit: `feat: persist translated message overlays`
14. [DONE] Git Commit: `feat: persist translated message overlays` (hash: 286738e80)

### Stream: Provider Source-Only Thinking Emits
15. [DONE] Убрать Gemini live translation wait path и оставить source emit; scope: `packages/Gemini_Module/src/session/gemini-session-manager.ts`, `packages/Gemini_Module/src/session/gemini-turn-runner.ts`; expected commit: `refactor: emit gemini thinking before translation`
16. [DONE] Git Commit: `refactor: emit gemini thinking before translation` (hash: 27b8cabe4)
17. [DONE] Упростить Codex reasoning path до source emits; scope: `packages/Codex_Module/src/messaging/codex-stream-event-router.ts`; expected commit: `refactor: emit codex reasoning before translation`
18. [DONE] Git Commit: `refactor: emit codex reasoning before translation` (hash: 0b99fcea0)
19. [DONE] Упростить Claude thinking path до source emits и оставить generic translation boundary отдельно; scope: `packages/Claude_Module/src/messaging/claude-stream-event-router.ts`; expected commit: `refactor: emit claude thinking before translation`
20. [DONE] Git Commit: `refactor: emit claude thinking before translation` (hash: 21c1a6d4b)

## Phase 2 — Overlay Projection And UI Delivery (owner: Codex, updated: 2026-04-13)
### Stream: Core History Projection
21. [DONE] Добавить Core projector для localized content и применить его при чтении runtime session history; scope: `packages/core/src/session-manager/index.ts`, `packages/core/src/session-translation/session-message-localization-projector.ts`, `packages/core/src/unified-session/storage.ts`; expected commit: `feat: project localized content into session history`
22. [DONE] Git Commit: `feat: project localized content into session history` (hash: 5a4c2d5d4)
23. [DONE] Отдавать localized history payloads для runtime и dialog history; scope: `packages/core/src/remote-bridge/handlers/http-api-session-routes.ts`, `packages/core/src/remote-bridge/handlers/dialog-history-service.ts`; expected commit: `feat: serve localized history payloads`
24. [DONE] Git Commit: `feat: serve localized history payloads` (hash: a9d2dbf62)

### Stream: Shared UI Contracts
25. [DONE] Расширить shared/UI message contracts под `localizedContent` и translation payload sanitizer; scope: `src/types/session.ts`, `src/client/ui/src/core-bridge/types.ts`, `src/client/ui/src/core-bridge/normalizers.ts`; expected commit: `feat: add localized session message contracts`
26. [DONE] Git Commit: `feat: add localized session message contracts` (hash: e501b9ff2)

### Stream: Runtime Overlay Updates
27. [DONE] Добавить UI facade для overlay patch apply в runtime snapshots; scope: `src/client/ui/src/session/session-message-localization-facade.ts`, `src/client/project-manager/components/sessions/session-stream.ts`, `src/client/project-manager/components/sessions/project-manager-runtime-session-view.tsx`; expected commit: `feat: apply translation overlays to runtime snapshots`
28. [DONE] Git Commit: `feat: apply translation overlays to runtime snapshots` (hash: 67fb47c03)

### Stream: Dialog Overlay Updates
29. [DONE] Перевести dialog history на canonical message ids и применить live translation patches; scope: `src/client/project-manager/components/sessions/project-manager-dialog-session-view-helpers.ts`, `src/client/project-manager/components/sessions/use-project-manager-dialog-core-events.ts`, `src/client/project-manager/components/sessions/use-project-manager-dialog-session-controller.ts`; expected commit: `feat: apply translation overlays to dialog history`
30. [DONE] Git Commit: `feat: apply translation overlays to dialog history` (hash: 784c8d91f)

### Stream: Display Rules
31. [DONE] Обновить dedupe/thinking render path на localized display content; scope: `src/client/project-manager/components/sessions/session-message-dedupe.ts`, `src/client/ui/src/session/dialog-panel-message-utils.ts`, `src/client/ui/src/session/dialog-panel.tsx`; expected commit: `fix: render localized thinking overlays consistently`
32. [DONE] Git Commit: `fix: render localized thinking overlays consistently` (hash: b7d66f772)

## Phase 3 — Verification, Docs, Release (owner: Codex, updated: 2026-04-13)
### Stream: Tests
33. [DONE] Добавить targeted tests для overlay projection/history/live patches и зафиксировать `packages/unified-session` test entry в `knip.json`; scope: `packages/unified-session/src/session-translation-overlay-store.test.ts`, `packages/core/src/session-translation/session-message-localization-projector.test.ts`, `src/client/ui/src/session/session-message-localization-facade.test.ts`, `knip.json`; expected commit: `test: cover thinking translation overlays`
34. [DONE] Git Commit: `test: cover thinking translation overlays` (hash: 617dabcb3)

### Stream: Packaging Safety
35. [DONE] Закрыть Claude translation packaging gap в release scripts; scope: `scripts/build-claude-module.sh`, `scripts/build-release.sh`; expected commit: `fix: validate claude translation runtime packaging`
36. [DONE] Git Commit: `fix: validate claude translation runtime packaging` (hash: a8f40e495)

### Stream: SSOT Sync
37. [DONE] Обновить system/module docs под Core-owned translation overlay contract; scope: `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`, `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md`, `doc/SolidWorks-WorkFlow/Modules/Localization.md`; expected commit: `docs: sync core translation overlay architecture`
38. [DONE] Git Commit: `docs: sync core translation overlay architecture` (hash: 87ab1f603)
39. [DONE] Обновить provider/contracts docs под source-first thinking + overlay merge; scope: `doc/SolidWorks-WorkFlow/Modules/Gemini.md`, `doc/SolidWorks-WorkFlow/Modules/Codex.md`, `doc/SolidWorks-WorkFlow/Contracts/Gemini_ThoughtTranslation.md`; expected commit: `docs: sync provider thinking overlay contract`
40. [DONE] Git Commit: `docs: sync provider thinking overlay contract` (hash: 029e75db9)
41. [DONE] Обновить Claude module SSOT и release-visible docs на будущую версию; scope: `doc/SolidWorks-WorkFlow/Modules/Claude.md`, `README.md`, `CHANGELOG.md`; expected commit: `docs: prepare thinking overlay release notes`
42. [DONE] Git Commit: `docs: prepare thinking overlay release notes` (hash: 890252dc8)

### Stream: Release Build
43. [DONE] Выполнить целевые сборки затронутых пакетов/клиентов перед release closeout; scope: verification only (`npm run build --workspace=@codeai-hub/unified-session`, `npm run build --workspace=@codeai-hub/core`, `npm run build --workspace=@codeai-hub/codex-module`, `npm run build --workspace=@codeai-hub/gemini-module`, `npm run build --workspace=@codeai-hub/claude-module`, `npm run build:webview`, `npm run typecheck:webview`); expected commit: `chore: verify thinking overlay release readiness`
44. [DONE] Git Commit: `chore: verify thinking overlay release readiness` (hash: 17be650b6)
45. [DONE] Собрать новый релиз по инструкции: `./scripts/build-all.sh`, затем `./scripts/build-release.sh --use-current-version`, зафиксировать version bumps и release artifacts; scope: release outputs + versioned manifests; expected commit: `chore: bump version via build-all.sh`
46. [DONE] Git Commit: `chore: bump version via build-all.sh` (hash: da286e39e)

## Closeout Notes
- `./scripts/build-all.sh` завершился успешно и поднял версию до `1.1.973`.
- `./scripts/build-release.sh --use-current-version` завершился успешно; собран `codeai-hub-1.1.973.vsix`.
- Planning scope закрыт отдельным tracked-коммитом `4208a1c35 docs(archive): close thinking translation overlay scope`; `ThinkingTranslationOverlay_Architecture.md` перенесён в `doc/SolidWorks-WorkFlow/Plans/Archive.zip`, `Docs_Index.md` очищен от active-ссылки.
