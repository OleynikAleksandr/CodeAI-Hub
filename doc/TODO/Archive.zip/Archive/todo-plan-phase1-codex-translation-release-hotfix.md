# План разработки (Development TODO Plan)

## Context Pack For This Cycle
- **Planning source:** `doc/SolidWorks-WorkFlow/Plans/Codex_TranslationEngine_ReleaseHotfix_Architecture.md`
- **Read this context before implementation:**
  - `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
  - `doc/SolidWorks-WorkFlow/Modules/Codex.md`
  - `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md`
  - `doc/SolidWorks-WorkFlow/Contracts/Codex_ResponseMode_Settings_Architecture.md`
  - `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- Только этот список является источником документов для восстановления контекста текущего execution cycle.

## Правила выполнения (Execution Rules):
- **Required reading (прочитать перед каждым фиксом):** `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- Каждая подзадача должна затрагивать не более 3 файлов или пакетов по активному стриму.
- Каждая подзадача оформляется парой пунктов: (1) реализация/изменения, (2) `Git Commit: ...` отдельной строкой.
- После каждого выполненного шага необходимо сразу обновлять этот `todo-plan.md`.
- Таргетная верификация для этого scope:
  - `./node_modules/.bin/tsx --test packages/Codex_Module/src/rollout/codex-rollout-live-sync.test.ts packages/Codex_Module/src/messaging/message-processor.replay.test.ts packages/Codex_Module/src/messaging/message-processor.empty-terminal.test.ts`
  - `npm run build --workspace @codeai-hub/codex-module`
- Финальный release stream обязан завершаться `./scripts/build-all.sh` и затем `./scripts/build-release.sh --use-current-version`.

## Phase 1 — Codex Release Hotfix (owner: Codex, updated: 2026-04-13)
### Stream: Scope Bootstrap
1. [DONE] Activate the planning scope in `Plans`/`Docs_Index` and replace the placeholder with this active `todo-plan.md`. Scope: `doc/SolidWorks-WorkFlow/Plans/Codex_TranslationEngine_ReleaseHotfix_Architecture.md`, `doc/SolidWorks-WorkFlow/Docs_Index.md`, `doc/TODO/todo-plan.md`. Expected commit: `docs: start codex spark release hotfix scope`
2. [DONE] Git Commit: `docs: start codex spark release hotfix scope` (hash: `4b2119099`)

### Stream: Codex Rollout Hotfix
3. [DONE] Finalize the rollout hotfix: remove provider-local rollout-thinking translation, keep Core overlay ownership, restore plain-text rollout final answers under `outputSchema`, and cover both regressions with unit tests. Scope: `packages/Codex_Module/src/rollout/codex-rollout-live-sync.ts`, `packages/Codex_Module/src/rollout/codex-rollout-live-sync.test.ts`, `doc/TODO/todo-plan.md`. Expected commit: `fix: repair codex rollout translation and final answer fallback`
4. [DONE] Git Commit: `fix: repair codex rollout translation and final answer fallback` (hash: `c976ff812`)

### Stream: SSOT Sync
5. [DONE] Sync Codex rollout/reasoning ownership and rollout final-answer fallback in SSOT docs. Scope: `doc/SolidWorks-WorkFlow/Modules/Codex.md`, `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`, `doc/TODO/todo-plan.md`. Expected commit: `docs: sync codex rollout hotfix ssot`
6. [DONE] Git Commit: `docs: sync codex rollout hotfix ssot` (hash: `4ac589c18`)

### Stream: Release Prep
7. [DONE] Prepare release-visible docs for future version `1.1.976` before rebuilding the package. Scope: `README.md`, `CHANGELOG.md`, `doc/TODO/todo-plan.md`. Expected commit: `docs: prepare release notes for 1.1.976`
8. [DONE] Git Commit: `docs: prepare release notes for 1.1.976` (hash: `45cf62815`)

### Stream: Release Build
9. [IN_PROGRESS] Run target verification, then `./scripts/build-all.sh` and `./scripts/build-release.sh --use-current-version`, and record the release result in session closeout. Scope: release manifests/versioned packages and release artifacts. Expected commit: `chore: bump version via build-all.sh`
10. [DONE] Git Commit: `chore: bump version via build-all.sh` (hash: `e8da0b8e4`)
