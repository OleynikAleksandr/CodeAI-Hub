# План разработки (Development TODO Plan)

## Context Pack For This Cycle
- **Planning source:** `doc/SolidWorks-WorkFlow/Plans/Codex_ThinkingTranslation_Diagnostics_Architecture.md`
- **Read this context before implementation:**
  - `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
  - `doc/SolidWorks-WorkFlow/Clusters/CoreOrchestrator.md`
  - `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md`
  - `doc/SolidWorks-WorkFlow/Modules/Codex.md`
  - `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- Только этот список является источником документов для восстановления контекста текущего execution cycle.

## Правила выполнения (Execution Rules):
- **Required reading (прочитать перед каждым фиксом):** `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- **TODO Plan** состоит из Phase (Фаз). В каждой Phase некоторое колличество - Stream (стрим), в каждом Стриме - некоторое кол-во подзадач.
- Каждая подзадача должна затрагивать не более 3 файлов.
- Каждая подзадача оформляется парой пунктов: (1) реализация/изменения, (2) `Git Commit: ...` (отдельной строкой).
- Если по факту разработки оказывается, что конкретная подзазача Stream затрагивает больше 3 файлов - такая задача должна быть разбита на более мелкие и список задач в Стриме переписывается.
- **Gates (автоматически через Husky hooks):**
  - `git commit` → `.husky/pre-commit`: `./scripts/check-architecture.sh`, `npm run lint`, `npm run check:knip`, `npm run format:fix`
  - `git push` → `.husky/pre-push`: `npm run check:dup`, `npm run check:links`
- **Таргетные сборки** выполняем вручную только когда нужно проверить затронутый пакет/клиент, и обязательно перед закрытием Stream/Phase: `npm run build --workspace <package>`, `npm run build:webview`, `npm run typecheck:webview`.
- **Commit**: После зеленых гейтов — Git Commit с максимально релевантным описанием (код + доки) и апдейт `todo-plan.md` (дата, статус, хеш).
- **Real-time Документация**: любое изменение архитектуры/логики требует синхронного обновления и `todo-plan.md` и релевантной документации `doc/` до коммита.

## Phase 1 — Codex thinking translation diagnostics (owner: Codex, updated: 2026-04-13)
### Stream: Scope bootstrap
1. [DONE] Оформить planning-doc и активный `todo-plan.md` для diagnostic scope — scope: `doc/SolidWorks-WorkFlow/Plans/Codex_ThinkingTranslation_Diagnostics_Architecture.md`, `doc/TODO/todo-plan.md`; ожидаемый commit message: `docs: start codex thinking translation diagnostics scope`
2. [DONE] Git Commit: `docs: start codex thinking translation diagnostics scope` (hash: `47558eef4`)

### Stream: Core instrumentation
3. [DONE] Добавить core-логи вокруг цепочки `thinking append -> translation dispatch/result -> overlay write -> broadcast patch` — scope: `packages/core/src/remote-bridge/handlers/session-request-handler-event-messages.ts`, `packages/core/src/session-translation/session-translation-facade.ts`, `packages/core/src/unified-session/storage.ts`; ожидаемый commit message: `chore: trace codex thinking translation pipeline`
4. [DONE] Git Commit: `chore: trace codex thinking translation pipeline` (hash: `63e2c6296`)
5. [DONE] Проверить таргетную сборку `@codeai-hub/core` и зафиксировать операторский trace-path для следующего repro: искать в `~/.codeai-hub/logs/core/core.log` последовательность `Unified session thinking message appended` -> `Thinking dialog message entered translation pipeline` -> `Session translation dispatch started` -> `Session translation completed|Session translation returned non-translated result` -> `Persisted session translation overlay` -> `Broadcasted dialog translation patch`.

### Stream: Release handoff
6. [DONE] Подготовить release notes для диагностического релиза `1.1.978` — scope: `README.md`, `CHANGELOG.md`; ожидаемый commit message: `docs: prepare 1.1.978 release notes`
7. [DONE] Git Commit: `docs: prepare 1.1.978 release notes` (hash: `3791d0da5`)
8. [DONE] Выполнить `./scripts/build-all.sh`, поднять версии до `1.1.978` и зафиксировать runtime manifests / package versions — scope: `package.json`, `package-lock.json`, `assets/*/manifest.json`, `packages/*/package.json`; ожидаемый commit message: `build: prepare 1.1.978 runtime artifacts`
9. [DONE] Git Commit: `build: prepare 1.1.978 runtime artifacts` (hash: `05bd06651`)
10. [DONE] Выполнить `./scripts/build-release.sh --use-current-version` и подготовить handoff-артефакты для следующей сессии:
    - VSIX: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub/codeai-hub-1.1.978.vsix`
    - Tarballs: `doc/tmp/releases/*1.1.978.tar.bz2`
    - Следующий шаг: manual repro в workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4` и анализ новых `core.log` записей по не переведённым `messageId`.
