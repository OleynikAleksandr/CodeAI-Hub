# План разработки (Development TODO Plan)

## Context Pack For This Cycle
- **Planning source:** `doc/SolidWorks-WorkFlow/Plans/StageConfirmationCard_Architecture.md`
- **Read this context before implementation:**
  - `doc/SolidWorks-WorkFlow/System/WorkflowSteps_Overview.md`
  - `doc/SolidWorks-WorkFlow/Clusters/Project_Manager.md`
  - `doc/SolidWorks-WorkFlow/Modules/Session_UI/SessionStatusPanel.md`
  - `doc/SolidWorks-WorkFlow/Modules/Session_UI/SessionIdUsageBar.md`
  - `doc/SolidWorks-WorkFlow/Contracts/EffectiveModelIdentity_And_Settings_SSOT.md`
  - `doc/SolidWorks-WorkFlow/Contracts/UserFacing_Text_Localization_Boundary.md`
- Только этот список является источником документов для восстановления контекста текущего execution cycle.

## Правила выполнения (Execution Rules):
- **Required reading (прочитать перед каждым фиксом):** `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`
- **TODO Plan** состоит из Phase (Фаз). В каждой Phase некоторое колличество - Stream (стрим), в каждом Стриме - некоторое кол-во подзадач.
- Каждая подзадача должна затрагивать не более 3 файлов.
- Каждая подзадача оформляется парой пунктов: (1) реализация/изменения, (2) `Git Commit: ...` (отдельной строкой).
- Если по факту разработки оказывается, что конкретная подзазача Stream затрагивает больше 3 файлов - такая задача должна быть разбита на более мелкие и список задач в Стриме переписывается.
- **Gates (автоматически через Husky hooks):**
  - `git commit` → `.husky/pre-commit`: `./scripts/check-architecture.sh`, `npm run lint`, `npm run check:knip`, `npm run format:fix`
  - `git push` → `.husky/pre-push`: `npm run check:dup`, `npm run check:links`
- **Таргетные сборки** выполняем вручную только когда нужно проверить затронутый пакет/клиент, и обязательно перед закрытием Stream/Phase: `npm run build --workspace <package>`, `npm run build:webview`, `npm run typecheck:webview`.
- **Commit**: После зеленых гейтов — Git Commit с максимально релевантным описанием (код + доки) и апдейт `todo-plan.md` (дата, статус, хеш).
- **Real-time Документация**: любое изменение архитектуры/логики требует синхронного обновления `todo-plan.md` и связанных документов из `doc/` до коммита.
- **Phase release**: финальный стрим обязан следовать `Release Build Checklist` из `AGENTS.md`.

## Phase 1 — Provider Override Start Path (owner: Codex, updated: 2026-04-13)
### Stream: Execution Bootstrap
1. [DONE] Зафиксировать active execution cycle по accepted planning-doc и обновить навигацию scope — scope: `doc/TODO/todo-plan.md`, `doc/SolidWorks-WorkFlow/Plans/StageConfirmationCard_Architecture.md`, `doc/SolidWorks-WorkFlow/Docs_Index.md`; ожидаемый commit message: `docs: start stage confirmation provider override cycle`
2. [DONE] Git Commit: `docs: start stage confirmation provider override cycle` (hash: `c261ada82`)

### Stream: Previous Step Provider Resolver
3. [DONE] Реализовать stage-aware inheritance для previous trunk provider и connected fallback — scope: `src/client/project-manager/services/workflow-provider-resolver.ts`, `src/client/project-manager/services/workflow-provider-resolver.test.ts`; ожидаемый commit message: `fix: inherit previous trunk provider for step start`
4. [DONE] Git Commit: `fix: inherit previous trunk provider for step start` (hash: `0575032da`)

### Stream: Confirmation Card Selector
5. [DONE] Добавить inline provider selector и явный provider forwarding в start path confirmation card — scope: `src/client/project-manager/components/shared/stage-confirmation-card.tsx`, `src/client/project-manager/components/shared/stage-confirmation-card.test.ts`; ожидаемый commit message: `feat: add provider override to stage confirmation card`
6. [DONE] Git Commit: `feat: add provider override to stage confirmation card` (hash: `826faa373`)

### Stream: Confirmation Card Localization
7. [DONE] Синхронизировать localized copy для provider override card — scope: `assets/localization/source/en/ui_labels.json`, `assets/localization/source/en/ui_helper_text.json`, `assets/localization/source/en/messages_for_the_user.json`; ожидаемый commit message: `docs: localize stage confirmation provider override copy`
8. [DONE] Git Commit: `docs: localize stage confirmation provider override copy` (hash: `850151c37`)

## Phase 2 — Runtime Sync and Documentation (owner: Codex, updated: 2026-04-13)
### Stream: Dialog Bootstrap Provider Sync
9. [DONE] Привязать dialog bootstrap к explicit provider intent для model/status и usage-limits surfaces нового step session — scope: `src/client/project-manager/components/sessions/use-project-manager-dialog-core-events.ts`, `src/client/project-manager/components/sessions/dialog-session-snapshot-replay.test.ts`; ожидаемый commit message: `fix: seed dialog bootstrap from chosen step provider`
10. [DONE] Git Commit: `fix: seed dialog bootstrap from chosen step provider` (hash: `95aadaec7`)

### Stream: Runtime Surface Regression Locks
11. [DONE] Зафиксировать тестами, что status bar и usage refresh продолжают следовать runtime provider path после step start — scope: `src/client/project-manager/components/sessions/project-manager-session-view.test.tsx`, `src/client/ui/src/session/session-id-bar.test.tsx`; ожидаемый commit message: `test: cover provider override runtime sync`
12. [DONE] Git Commit: `test: cover provider override runtime sync` (hash: `18fdae5bf`)

### Stream: Workflow and PM SSOT Sync
13. [DONE] Обновить trunk workflow и PM cluster docs под inline provider override contract — scope: `doc/SolidWorks-WorkFlow/System/WorkflowSteps_Overview.md`, `doc/SolidWorks-WorkFlow/Clusters/Project_Manager.md`; ожидаемый commit message: `docs: sync workflow provider override contract`
14. [DONE] Git Commit: `docs: sync workflow provider override contract` (hash: `f93af3237`)

### Stream: Session UI Module Sync
15. [DONE] Обновить factual docs для status panel и usage limits bar под chosen-provider start path — scope: `doc/SolidWorks-WorkFlow/Modules/Session_UI/SessionStatusPanel.md`, `doc/SolidWorks-WorkFlow/Modules/Session_UI/SessionIdUsageBar.md`; ожидаемый commit message: `docs: sync session ui provider override behavior`
16. [DONE] Git Commit: `docs: sync session ui provider override behavior` (hash: `34c892f2a`)

## Phase 3 — Release Build (owner: Codex, updated: 2026-04-13)
### Stream: Release Notes Prep
17. [DONE] Подготовить release notes и release-visible docs для следующей версии до build-all — scope: `README.md`, `CHANGELOG.md`, `doc/TODO/todo-plan.md`; ожидаемый commit message: `docs: prepare release notes for step provider override`
18. [DONE] Git Commit: `docs: prepare release notes for step provider override` (hash: `f7d1da976`)

### Stream: Build All Version Bump
19. [DONE] Запустить `./scripts/build-all.sh`, проверить сгенерированные version surfaces и зафиксировать bump — scope: `root release metadata`, `VS Code extension/package manifests`, `bundled provider distributions`; ожидаемый commit message: `chore: bump version via build-all.sh`
20. [DONE] Git Commit: `chore: bump version via build-all.sh` (hash: `51a6c8bf4`)

### Stream: Final Release Packaging
21. [DONE] Запустить `./scripts/build-release.sh --use-current-version`, проверить артефакт VSIX, обновить local closeout artifacts и подготовить session report — scope: `release validation surfaces`, `doc/TODO/todo-plan.md`, `doc/Sessions/Session005.md`; результат: `codeai-hub-1.1.972.vsix` успешно собран, release-testing перенесен на следующую сессию; ожидаемый commit message: `docs: archive provider override plan and ignore worklogs`
22. [DONE] Git Commit: `docs: archive provider override plan and ignore worklogs` (hash: `f93294928`)
