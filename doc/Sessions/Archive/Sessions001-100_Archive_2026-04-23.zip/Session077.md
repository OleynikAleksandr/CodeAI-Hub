# Session 77 — Development Tree Parser Stability + Artifacts Auto-Fit Zoom (1.2.40)

**Date:** 2026-04-21 12:45 CEST
**Branch:** main
**Version:** 1.2.40
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Пользователь на workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub claude` сообщил о нестабильном отображении Development Tree в левом sidebar PM на шаге `diagram_modules`: artefakt `product-parts/project-manager.md` имеет 2 cluster'а (`workflow-and-artifact-ui`, `session-workspace-ui`) и 1 standalone module (`cef-launcher`), правый Artifacts graph рисует композицию корректно, но sidebar то показывает 5 "standalone" модулей (4 из которых — это cluster-модули), то после серии expand/collapse возвращается к правильной структуре. Плюс Artifacts panel при уменьшении ширины окна уходит за правую границу — авто-подгонка не работает.
- Root cause диагностика первой проблемы — split на два независимых дефекта в `packages/core/src/remote-bridge/handlers/development-tree-snapshot.ts`: (1) module-level `NEXT_SECTION_RE = /^##\s+/gm` потреблялся через прямой `.exec(body.slice(1))` в `clampSectionBody`, и global regex singleton сохранял `lastIndex` между вызовами в long-lived Core процессе, давая hit/null/hit/null alternation на одном и том же body; (2) `MODULE_ROW_RE` non-greedy `(.+?)\s*\|\s*$` съедал 2-ю, 3-ю и 4-ю колонки в одну группу, поэтому 4-колоночные Simple Relations rows матчились и `from-id` попадал как standalone module id. Когда (1) выдавал null, `clampSectionBody` отдавал body целиком, и Simple Relations уходили в standalone-скан. Sidebar expand/collapse триггерили `/workflow-state` fetch и перещёлкивали alternation. Precedent-фикс 1.2.37 ограничил standalone body, но через тот же `.exec()` — отсюда регрессия нестабильности.
- Root cause второй проблемы — `DiagramEditorFacade` применял `transform: scale(${zoom})` только через Cmd/Ctrl+scroll пользователя, auto-fit отсутствовал. Intrinsic min-content ширина композиции (`productPartHeaderStyle: auto minmax(240px, 1fr)` + `ModuleCard.minWidth: 220` + `repeat(columns, 1fr)`) около 700-900 px; при меньшей ширине Artifacts panel композиция уходила за правую границу через `overflow: auto`.
- Phase 1 — Core DevTree parser stability: `development-tree-snapshot.ts` переписан так, что все `/g`-regex потребляются через `.matchAll()` (iterator не использует shared lastIndex) или factory-функции, возвращающие свежий regex-инстанс на каждый вызов; `clampSectionBody` переведён на `str.search(NEXT_SECTION_SEARCH_RE)` с non-global regex; `MODULE_ROW_RE` ужесточён до строго 2-column (`[^|\n]+` во второй колонке + якорь `\|[ \t]*$`), так что 4-колоночные Simple Relations rows физически не матчатся даже если clamp когда-либо опять соскользнёт.
- Phase 1 — Regression coverage: `development-tree-snapshot.test.ts` получил два новых теста: (a) 10-run idempotency guard на одном артефакте, (b) artifact с cluster-модулями в `From`-столбце Simple Relations не выдаёт фантомных standalone. Существующие 3 теста тоже проходят.
- Phase 1 — SSOT sync: `SystemArchitecture.md` §6.4 расширен invariant'ом про regex lastIndex safety в `development-tree-snapshot` (запрет прямого `.exec()/.test()` на module-level `/g`-regex) и про strict 2-column `MODULE_ROW_RE`.
- Phase 2 — Artifacts diagram auto-fit zoom: `DiagramEditorFacade` получил `autoFitScale` state через `ResizeObserver` на container + natural `scrollWidth` композиции. Effective render scale = `autoFitScale × userZoom`, где `autoFitScale = min(1, containerWidth / naturalWidth)` с нижним порогом `0.25`. Manual Cmd/Ctrl+scroll теперь overlay поверх auto-fit базы; Cmd/Ctrl+0 сбрасывает только user overlay, не auto-fit. Внутренняя композиция выставляет `width: max-content + min-width: 100%`, чтобы `scrollWidth` возвращал intrinsic natural size независимо от applied transform. Source-level regression тест на auto-fit API surface добавлен в `diagram-editor-facade.test.tsx`.
- Phase 2 — SSOT sync: `SystemArchitecture.md` §6.4 расширен auto-fit zoom contract'ом (effective = auto-fit × user-zoom, manual as overlay, natural width через `max-content`).
- Phase 3 — Release 1.2.40: README.md + CHANGELOG.md обновлены до запуска build-all.sh. `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.40.vsix` (~2.28 MB), все 7 tarball'ов в `doc/tmp/releases/` (claude/codex/gemini-module, codeai-hub-core, CodeAIHubLauncher, project-manager, vscode-webview).
- Cycle closeout: planning-doc и todo-plan заархивированы в `Plans/Archive/` и `TODO/Archive/todo-plan-phase3-devtree-parser-autofit-zoom.md`, `Docs_Index.md` обновлён с entry про `BUG-2026-04-21-02`, в `BugRegistry.md` добавлена запись `BUG-2026-04-21-02` с full forensics / root cause / fix / commits / guards, восстановлен пустой todo-plan stub.
- Два существующих source-level failing test'а в `diagram-editor-facade.test.tsx` (`auto-fill` string match и product-part hierarchy parser) остались нетронутыми как baseline-дефекты не текущего scope — зафиксировано в release notes. На pre-commit/pre-push гейты они не влияют (PM TSX тесты не запускаются в hooks).

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `4f43fd76d docs: open devtree parser stability + autofit zoom scope`
- `c1ede86b0 fix: stabilize development tree parser against regex lastIndex drift`
- `3661b315d test: cover development tree parser idempotency and relations leak guard`
- `63fdac691 docs: record development tree parser lastIndex safety invariant`
- `72097ad9a feat: auto-fit diagram canvas to artifacts panel width`
- `41591193a docs: record artifacts diagram auto-fit zoom contract`
- `f7b3d45e0 docs: prepare release notes for devtree parser + autofit zoom`
- `2f26ac882 build: release 1.2.40`
- `9adac5139 docs: archive devtree parser + autofit zoom cycle (1.2.40)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase3-devtree-parser-autofit-zoom.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/DiagramModules_DevTreeParser_And_AutoFitZoom_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
- Известный baseline-дефект не текущего scope: `diagram-editor-facade.test.tsx` содержит два source-level failing test'а (`auto-fill` string assertion не совпадает с актуальным facade кодом; parser test про product part hierarchy без flattening ownership). На pre-commit/pre-push гейты не влияют (PM TSX тесты вне hooks). Кандидат на отдельный cleanup-scope если будет найдена регрессия.
