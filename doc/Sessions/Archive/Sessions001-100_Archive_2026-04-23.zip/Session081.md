# Session 81 — Usage Limits Single-Probe Warmup (1.2.44)

**Date:** 2026-04-21 20:00 CEST
**Branch:** main
**Version:** 1.2.44
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Пользователь на user acceptance `1.2.43` подтвердил что continuation сессий работает у всех провайдеров, но лимиты у Claude и Codex появляются только после первого turn'а — до этого в reopened dialog виджет пустой или показывает фейковое `Session 0% / Weekly 0%`. Gemini работает.
- Обсуждение архитектуры usage_limits. Пользователь: никакой persistence на диск (shared across clients), refresh дважды в turn (start + end). Я возразил: start-of-turn probe бесполезен (cache от прошлого turn'а уже актуален), end-of-turn passive extraction бесплатна. Пользователь уточнил: лимиты пропали только в cold-cache окне между PM open и первым turn'ом.
- Опытная проверка Codex app-server через `~/.codeai-hub/logs/codex/sdk-codex-app-server-*.jsonl`: app-server сам пушит `account/rateLimits/updated` notification 7-8 раз за turn (`turn/started`, каждый `thread/tokenUsage/updated`, `turn/completed`), payload содержит `primary.usedPercent`, `secondary.usedPercent`, `windowDurationMins`, `resetsAt`, `planType`. Пассивный путь у Codex работает бесплатно.
- Опытная проверка Claude SDK через `~/.codeai-hub/logs/claude/sdk-claude-*.jsonl`: SDK эмитит `sdk:rate_limit_event` с `status`, `resetsAt`, `rateLimitType`, но **без `usedPercent`** — Anthropic отдаёт % только в HTTP headers `anthropic-ratelimit-unified-*`. Поэтому `ClaudeLiveHeadersReader` делает отдельный HTTP probe на `api.anthropic.com/v1/messages` с `max_tokens: 1`.
- Анализ: `scopeKey` уже account-scoped (`{providerId}:global` с `070139b9e`), значит один успешный probe наполняет payload для всех sessions провайдера разом. Корень проблемы — не в scopeKey, а в том что PM эмитит `binding_ready` refresh **на каждое открытие dialog'а**, и все эти refresh'и гонятся против paper-binding hydration из `1.2.39`: первый probe возвращает null (cache пустой), subsequent тоже (race не лечится повторами), виджет остаётся без цифр.
- Phase 1 — scopeKey rescope отменился (no-op после проверки).
- Phase 2 — single-probe warmup (`d9e7114a4`): новый `UsageLimitsWarmupTracker: Set<providerId>` в `SessionRequestHandler`. На `binding_ready` — если провайдер уже warmed, skip dispatch и fall back to cached replay. Другие lifecycle triggers (`turn_completed`, `reconnect`, `manual`, `provider_session_rebound`, `dialog_opened`, `session_opened`) не дедуплицируются. Для удержания `session-request-handler.ts` под 500-строковым лимитом тела `handleRefreshUsageLimits` вынесено в новый helper `session-request-handler-usage-limits-refresh.ts` + dedup logic + diagnostic logs в `session-request-handler-usage-limits-warmup.ts`. Regression test покрывает cold-cache failed warmup + turn_completed pass-through.
- Phase 3 — UI empty-cache fallback отменился (no-op после проверки): `usage-limits-stream.readBucket` уже возвращает null когда `percentUsed === null`, `hasUsageLimits` скрывает row целиком когда все bucket null, `renderLimitLabel` не рендерит процент для null bucket. Legitimate `Session 0% (Resets …)` в начале 5-часового окна остаётся как есть — это честный API response.
- Phase 4 — SSOT + BugRegistry (`de586e9e8`): `SystemArchitecture.md` §3 Invariant 1 расширен single-probe warmup policy. `BugRegistry.md` — запись `BUG-2026-04-21-06` с forensics / root cause / fix / commits / guards.
- Phase 5 — Release 1.2.44 (`9dbc987fb` + `5884812b1`): README.md + CHANGELOG.md под 1.2.44. `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.44.vsix` (~2.30 MB), все 7 tarball'ов в `doc/tmp/releases/`.
- Cycle closeout (`e0e765b5d`): planning-doc и todo-plan заархивированы, `Docs_Index.md` обновлён, восстановлен пустой todo-plan stub.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `c2ecb6b01 docs: open account-scoped usage limits warmup scope`
- `d9e7114a4 feat: limit usage-limits refresh to one warmup probe per provider`
- `de586e9e8 docs: record single-probe usage limits warmup invariant`
- `9dbc987fb docs: prepare release notes for single-probe usage limits warmup (1.2.44)`
- `5884812b1 build: release 1.2.44`
- `e0e765b5d docs: archive usage limits single-probe warmup cycle (1.2.44)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего hotfix-цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase5-usage-limits-warmup.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/Usage_Limits_AccountScoped_Warmup_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- User acceptance для 1.2.44 ожидается: после Core restart и открытия reopened dialog у Claude/Codex widget usage_limits показывает актуальные цифры без необходимости отправлять первое сообщение. Второе-третье-десятое открытие dialog'а того же провайдера не дёргает повторный HTTP probe.
- Известный deferred item: **rate_limit_error handler** на Core dispatch'е (перехват `rate_limit_error` от API, graceful display + restore prompt + кэш update из error headers) — обсуждён в planning-doc `Usage_Limits_AccountScoped_Warmup_Architecture.md` как Out of Scope, кандидат на отдельный cycle.
- Известный baseline-дефект не текущего scope: два source-level failing тестов в `diagram-editor-facade.test.tsx` (`auto-fill` + product-part hierarchy parser) — на pre-commit/pre-push гейты не влияют.
