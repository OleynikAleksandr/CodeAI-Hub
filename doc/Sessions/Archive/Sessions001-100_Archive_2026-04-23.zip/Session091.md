# Session 91 — PM Settings Ownership Planning

**Date:** 2026-04-22 15:58 (CEST)
**Branch:** main
**Version:** 1.2.52
**Execution Scope Status:** ACTIVE

---

# 1. Work Done in This Session

## Work summary
- Восстановлен контекст по правилам проекта: прочитаны `doc/Sessions/Session090.md`, базовый SSOT `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`, `doc/SolidWorks-WorkFlow/Docs_Index.md` и текущий `doc/TODO/todo-plan.md`; подтверждено, что предыдущий cycle закрыт, активного execution scope до этой сессии не было.
- С пользователем согласован новый scope: product-level `Settings` должны полностью переехать в `Project Manager`; `Core` должен стать единственным backend owner для settings flows; `VS Code extension` должен остаться distribution/install/update shell и лишиться права запускать `Core Runtime`.
- Уточнена runtime-модель: `Core` остаётся persistent single-instance background runtime; standalone `Project Manager` уже является bootstrap entrypoint при обычном desktop usage; закрытие PM не должно останавливать Core. Следовательно, новый scope касается ownership `Settings` и extension de-scope, а не полного переразведения lifecycle Core.
- Создан planning-doc `doc/SolidWorks-WorkFlow/Plans/ProjectManager_Settings_And_RuntimeOwnership_Architecture.md`. В нём зафиксированы: core-owned settings backend, PM-only settings UI, extension runtime de-scope, removal of extension core-start authority, reuse текущего `SettingsView` без redesign, dedicated PM settings window и placement кнопки `Open Settings` в footer зоне, где сейчас находится `Workflow Tree MVP`.
- Под этот planning-doc создан новый active `doc/TODO/todo-plan.md` с execution cycle `1.2.53 — Project Manager Settings Ownership + Extension Runtime De-Scope`. План разбит на четыре фазы: Core backend, PM settings window, extension de-scope + SSOT sync, release metadata/build. Последний stream — release rebuild по release checklist.

## Git commits
(ВАЖНО: при `Execution Scope Status: ACTIVE` следующая сессия обязана просмотреть каждый коммит через `git show --stat <hash>` и `git show <hash>`. В этой planning-only сессии новых git commits не создавалось.)
- Нет новых git commits; session была planning-only и закончилась созданием planning-doc + active todo-plan.

---

# 2. Instructions for Next Session

**Recovery Owner:** `doc/TODO/todo-plan.md`

## Plans for next session
- Продолжать активный execution scope по `doc/TODO/todo-plan.md`.
- Перед любым implementation fix использовать только context pack из активного `doc/TODO/todo-plan.md`; не возвращаться к `Docs_Index.md` как к primary source для этого cycle.
- Начать с `Phase 1 / Stream A`: core settings write transport (`settings:save/reset/saved/save-error/localization-sync-status`) и routing PM intents в Core.
- При реализации помнить два уже зафиксированных UI решения:
  - текущий `SettingsView` переносится в `Project Manager` без redesign;
  - `Settings` открываются как отдельное независимое окно PM, а кнопка `Open Settings` живёт в footer зоне рядом с текущей надписью `Workflow Tree MVP`.
- Последний stream цикла уже зарезервирован под release rebuild `1.2.53`; version bump руками не делать, использовать только release scripts из `todo-plan.md`.
