# Session 86 — CEF macOS Input + Quit Regression Fix And Release 1.2.48

**Date:** 2026-04-22 11:46 (CEST)
**Branch:** main
**Version:** 1.2.48
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Открыт и завершён execution cycle под релиз `1.2.48` — follow-up fix к CEF macOS bootstrap hardening из `1.2.46` (Session084).
- Диагностика user-reported регрессий после `1.2.46`: (a) Cmd+V / paste не работает в input standalone Project Manager, (b) SuperWhisper (синтетический Cmd+V через CGEvent) не попадает в input, (c) Dock right-click → Quit и Cmd+Q не закрывают launcher с первого клика. Все три — единый fallout от коммитов `de7c5ad37` и `b6b0cf3d1`.
- Root cause: (1) Перевод NSApp на `CodeAIHubApplication : NSApplication <CefAppProtocol>` убрал CEF-swizzle для `-[NSApplication sendEvent:]`. Наш `[super sendEvent:event]` прогоняет NSKeyDown через `[[NSApp mainMenu] performKeyEquivalent:]`. Edit menu с Cut/Copy/Paste/SelectAll и `target:nil` перехватывает Cmd+X/C/V/A по responder chain, но CEF web view не отвечает на `paste:` / `cut:` / `copy:` / `selectAll:` Cocoa-selectors, поэтому key event "съедается" и не доходит до Chromium как NSKeyDown. (2) Override `-[CodeAIHubApplication terminate:]` → `tryToTerminateApplication:` → `handler->CloseAllBrowsers(false)` (non-force) молча зависал quit, если `TryCloseBrowser()` возвращал false для любого browser'а.
- Fix: убран override `terminate:` + метод `tryToTerminateApplication:`; quit идёт стандартным AppKit маршрутом `terminate:` → `applicationShouldTerminate:`, delegate force-close-ит browsers через `CloseAllBrowsers(true)` и возвращает `NSTerminateCancel`; `LauncherHandler::OnBeforeClose` драйвит `CefQuitMessageLoop()` после последнего browser'а. Edit menu полностью удалён из `CreateApplicationMenu` — Chromium внутри CEF сам обрабатывает clipboard shortcuts на уровне render process. Shutdown-crash fix из `1.2.46` сохраняется через `CodeAIHubApplication <CefAppProtocol>` и `CefScopedSendingEvent` wrapper.
- SSOT синхронизирован: `Launcher_CEF.md` получил refined macOS bootstrap lifecycle boundary (override `terminate:` запрещён, Edit menu items запрещены, `CloseAllBrowsers(true)` — канонический force path); `SystemArchitecture.md` §3 Invariant 32 (1.2.46) переписан без `tryToTerminateApplication`, добавлен новый Invariant 33 (1.2.48) с permanent CEF acceptance matrix перед любым release. `BugRegistry.md` получил запись `BUG-2026-04-22-04` newest-first.
- Release metadata обновлены ДО `build-all.sh`: `README.md` Current Release → v1.2.48 + 1.2.46 передвинут в previous list; `CHANGELOG.md` получил секцию `## [1.2.48]`.
- Release собран полным pipeline: `./scripts/build-all.sh --version 1.2.48` (CEF launcher + Claude/Codex/Gemini modules + core + UI, auto version bump, tarballs), `./scripts/build-release.sh --use-current-version` (SDK exclusions verified, dev dependencies pruned, VSIX packaged). Финальный артефакт: `codeai-hub-1.2.48.vsix` (2.3M) в repo root. Tarballs в `~/.codeai-hub/releases/` и `doc/tmp/releases/`: CodeAIHubLauncher-macos-arm64-1.2.48, codeai-hub-core-darwin-arm64-1.2.48, claude/codex/gemini-module-1.2.48, vscode-webview-1.2.48, project-manager-1.2.48.
- Архивация: planning-doc `CEF_MacOS_Input_And_Quit_Regression_Architecture.md` перенесён в `Plans/Archive/`; todo-plan переименован в `todo-plan-phase1-cef-macos-input-quit-regression.md` и положен в `doc/TODO/Archive/`; `doc/TODO/todo-plan.md` возвращён к neutral no-active-scope stub; `Docs_Index.md` обновлён.

## Verification
- Husky pre-commit (`./scripts/check-architecture.sh`, `npm run lint`, `npm run check:knip`, `npm run format:fix`) зелёный на каждом из 7 коммитов.
- `./scripts/build-all.sh --version 1.2.48` (exit 0): pересобраны CEF launcher + Claude/Codex/Gemini modules + core + UI; linked `CodeAIHubLauncher.app/Contents/MacOS/CodeAIHubLauncher` включил свежие `app_main_mac.mm` и `codeai_hub_application_mac.mm`.
- `./scripts/build-release.sh --use-current-version`: Step 7 SDK exclusions verified, Step 7.5 local artefacts validated (claude/codex/gemini provider bundles load with bundled shared translation package, core runtime bundle loads localization-backed settings bridge), Step 9.5 VSIX runtime package surface verified, Step 10 package size 2.3M.
- Manual acceptance matrix из Invariant 33 **запланирована для retest пользователем** на свежем установленном `codeai-hub-1.2.48.vsix`: Cmd+V, SuperWhisper, Cmd+C/X/A, Dock right-click Quit, Cmd+Q, window close без crash, dock reopen.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `a97c5e9c5 fix(launcher-mac): route terminate through applicationShouldTerminate`
- `a6dd758b2 fix(launcher-mac): drop edit menu to unblock clipboard shortcuts`
- `a5c75c0f2 docs: sync CEF macOS input/quit contract`
- `0014874be docs: prepare 1.2.48 release metadata`
- `afc3a0b80 docs: update todo-plan progress for 1.2.48 streams A-D`
- `f7c6d9556 chore: release 1.2.48`
- `9e837b561 docs: record 1.2.48 release commit hash`
- `16d1623b2 docs: archive 1.2.48 input/quit regression scope`

## User feedback
- Пользователь описал регрессию как follow-up к моему (CEF bootstrap) рефакторингу из `1.2.46` и согласовал весь scope (fix + SSOT sync + release) в одном execution cycle.

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.

## User retest checklist for 1.2.48 (обязательно перед сдачей)
- Установить `codeai-hub-1.2.48.vsix`, открыть standalone Project Manager (CEF launcher).
- Cmd+V в input поле PM вставляет текст из системного буфера.
- SuperWhisper диктовка → транскрипт попадает в input поле PM.
- Cmd+C / Cmd+X / Cmd+A работают внутри PM input.
- Dock right-click → Quit закрывает launcher с первого клика.
- Cmd+Q из собственного app-menu закрывает launcher.
- Закрытие окна красным крестом не крашит процесс (regression guard из 1.2.46 остаётся).
- Dock reopen работает после закрытия последнего окна.

## Архивы текущего цикла
- Planning: `doc/SolidWorks-WorkFlow/Plans/Archive/CEF_MacOS_Input_And_Quit_Regression_Architecture.md`
- TODO: `doc/TODO/Archive/todo-plan-phase1-cef-macos-input-quit-regression.md`
- Релизный артефакт: `codeai-hub-1.2.48.vsix` (repo root) + tarballs в `doc/tmp/releases/`.
