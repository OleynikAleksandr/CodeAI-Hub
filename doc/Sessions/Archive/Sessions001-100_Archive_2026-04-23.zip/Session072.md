# Session 72 — UI And Reasoning Translation Engine Split Planning

**Date:** 2026-04-20 21:45 CEST
**Branch:** main
**Version:** 1.2.35
**Execution Scope Status:** ACTIVE

---

# 1. Work Done in This Session

## Work summary
- Согласован новый design scope: разделить общий translation engine на два независимых контура — `UI Translation Engine` и `Reasoning Translation Engine`.
- Подтверждён текущий invariant, который нельзя потерять в реализации: hidden `Thinking / Reasoning` не должен переводиться и не должен входить в translation queue.
- Подготовлен planning document:
  - `doc/SolidWorks-WorkFlow/Plans/UI_And_Reasoning_Translation_Engine_Split_Architecture.md`
- Стартовый docs commit для активного scope создан:
  - `373a94a0b docs: start ui and reasoning translation split scope`
- В planning doc зафиксированы ключевые product decisions:
  - rename текущего selector в `UI Translation Engine`;
  - новый selector `Reasoning Translation Engine`;
  - default `Google GTX Free` для новых reasoning defaults и новых fresh installs;
  - migration contract `legacy engineId -> uiEngineId`, новый `reasoningEngineId -> google-gtx`;
  - separate runtime marker `Reasoning`;
  - обязательная явная маркировка любого нового текста по ownership categories.
- Создан новый активный execution plan:
  - `doc/TODO/todo-plan.md`
- В active TODO разрезаны implementation phases для:
  - settings contract split;
  - save-impact classifier split;
  - Core reasoning routing;
  - provider-local runtime translation audit;
  - settings UI + localized source keys;
  - финального release stream с `build-all.sh` и `build-release.sh --use-current-version`.
- Код и runtime в этой сессии не менялись; сессия закончена на design/planning handoff.

## Git commits
(ВАЖНО: при `Execution Scope Status: ACTIVE` следующая сессия обязана просмотреть каждый коммит через `git show --stat <hash>` и `git show <hash>`.)
- `373a94a0b docs: start ui and reasoning translation split scope`

---

# 2. Instructions for Next Session

**Recovery Owner:** `doc/TODO/todo-plan.md`

## Plans for next session
- Продолжать активный execution scope строго по `doc/TODO/todo-plan.md`.
- Перед началом реализации прочитать:
  - `doc/SolidWorks-WorkFlow/Plans/UI_And_Reasoning_Translation_Engine_Split_Architecture.md`
  - `doc/SolidWorks-WorkFlow/Modules/Localization.md`
  - `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md`
  - `doc/SolidWorks-WorkFlow/Contracts/UserFacing_Text_Localization_Boundary.md`
  - `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
- Не терять contract decisions этого scope:
  - `uiEngineId` и `reasoningEngineId` разделяются;
  - hidden reasoning не переводить;
  - новый settings helper/warning copy должен быть локализован и размечен по ownership;
  - появляется отдельный runtime marker `Reasoning`, не смешиваемый с bundled UI categories;
  - reasoning engine change не должен запускать blocking localization sync.
- Финальный implementation cycle обязан завершиться release stream из active `todo-plan.md`.
