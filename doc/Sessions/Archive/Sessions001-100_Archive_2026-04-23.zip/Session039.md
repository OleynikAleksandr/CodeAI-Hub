# Session 39 — Claude x-High Reverts to Medium on PM Boot (1.2.0 → 1.2.1 → 1.2.2)

**Date:** 2026-04-16 20:55 CEST
**Branch:** main
**Version:** 1.2.2
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## 1.1. Как возник scope

Пользователь поставил 1.1.999 (live bubble merge), убедился что плашки ассистента склеиваются. Затем заметил что Claude effort `x-High`, который он сохранил в Settings, при запуске Project Manager возвращается в `medium`. В момент проверки `~/.codeai-hub/settings/settings.json` effort уже был `medium` — переписан без явного действия пользователя.

## 1.2. Диагностический путь (два инструментальных релиза)

Сразу прыгать в код не стали — вопрос "кто именно пишет settings.json" требовал прямого наблюдения. Выпустили два диагностических билда.

### 1.2.0 — persist/load/save trace

Добавили структурированный лог через `getExtensionLogger()` в `~/.codeai-hub/logs/extension/extension.log`:
- `settings_debug_load_snapshot` — `rawEffort` / `normalizedEffort` / `backfillReasons` при каждом `loadSettingsSnapshot`.
- `settings_debug_persist_snapshot` — полный snapshot claude.thinking + **stack trace** при каждом `persistSettingsSnapshot`.
- `settings_debug_save_incoming` / `_save_normalized` в `handleSaveRequest`.

**Побочный фикс**: `scripts/build-all.sh` раньше делал только `increment_patch`; пользователь хотел сразу 1.2.0. Добавили `--version <semver>` опцию.

Результат retest'а 1.2.0:
```
18:24:35.830 persist_snapshot effort=xhigh   ← пользовательский Save
[16 секунд тишины]
20:24:51      settings.json на диске = medium
```

Persist трейса нет, но файл переписан. Значит writer **обходит** `persistSettingsSnapshot`, либо async log stream потерял trailing запись при deactivate.

### 1.2.1 — fs.watchFile watcher

Добавили polling-наблюдатель `fs.watchFile` на `settings.json` (300 ms), стартует в `extension.activate`, стопится до `disposeExtensionLogger` в `deactivate`. Любое изменение mtime/size логируется как `settings_debug_watcher_change` независимо от того, кто пишет.

Retest 1.2.1 не дал чистого watcher-лога — extension-host не активировался после переустановки до перезапуска VSCode. Зато пользователь прислал **два скриншота settings.json** — до и после запуска PM. В "до" порядок полей в `providers.claude` совпадал с extension-side `normalizeClaudeSettings` (`thinking → autoUpdate → defaultModel → sessionContinuity → thinkingDisplaySyncEnabled`). В "после" — **другой порядок** (`thinking → thinkingDisplaySyncEnabled → autoUpdate → defaultModel → sessionContinuity`). Это почерк другого нормалайзера.

## 1.3. Root cause

Grep по Core: `packages/core/src/remote-bridge/handlers/settings-request-handler-claude-thinking.ts` содержал собственный hardcoded whitelist:

```ts
const CLAUDE_THINKING_EFFORTS = new Set(["low", "medium", "high", "max"]);
// xhigh отсутствовал
```

И собственную legacy anchor таблицу (`low:2000, medium:4000, high:10000, max:32000` — тоже без xhigh).

Full flow:
1. User сохранил `xhigh` → extension `parseSettingsSnapshot` → xhigh валиден (ui/extension registry знает xhigh) → persist. Диск: `xhigh`.
2. User запустил PM → PM через websocket → Core `SettingsRequestHandler.handleLoad()`.
3. Core прочитал settings.json → `normalizeClaudeThinkingSettings({value: rawClaude.thinking, ...})`:
   - `typeof "xhigh" === "string"` → true
   - `CLAUDE_THINKING_EFFORTS.has("xhigh")` → **false**
   - → `resolveLegacyClaudeThinkingEffort("xhigh")` → `Number("xhigh")` = NaN → `DEFAULT_CLAUDE_THINKING_EFFORT = "medium"`
4. `changed = true` → `persistDefaultSettingsSnapshot(settingsPath, settings)` записал medium обратно на диск с Core-specific порядком полей.

Это duplicate normalizer, который **не был обновлён** в Session 037 (1.1.998) вместе с xhigh. Четыре канонических места держать в lockstep:
1. `src/types/claude-model-registry.ts` (`CLAUDE_THINKING_EFFORT_SET`) — обновлено в 1.1.998.
2. `src/extension-module/settings/claude-settings.ts` (`normalizeClaudeThinkingEffort`) — обновлено в 1.1.998.
3. `packages/core/src/config/provider-defaults-resolver.ts` (`CLAUDE_THINKING_EFFORTS`) — обновлено в 1.1.998.
4. `packages/core/src/remote-bridge/handlers/settings-request-handler-claude-thinking.ts` — **пропущено до сегодня**.

## 1.4. Фикс (1.2.2)

- Добавлен `"xhigh"` в Core whitelist + `{ effort: "xhigh", maxTokens: 20_000 }` в legacy anchor таблицу (20000 — между high=10000 и max=32000, как уже принято в `provider-defaults-resolver.ts` Session 037).
- Comment у Set указывает на три других канонических файла.
- Убран весь debug tracing 1.2.0 / 1.2.1: удалён `settings-file-watcher.ts`, дебаг-логи в `settings-storage.ts` и `settings-message-handler.ts`, связки в `extension.ts`.

## 1.5. SSOT sync

**SystemArchitecture.md Invariant 27 добавлен** — документирует four-way parity требование: settings.json нормализуется двумя независимыми слоями (Extension + Core), и любой effort/thinking level, принимаемый одним слоем но не другим, молча переписывается к Core default на следующем PM boot. Список четырёх канонических файлов, которые нужно обновлять одним коммитом.

**Modules/Claude.md, Codex.md, Gemini.md** — в каждом добавлен matching инвариант-пункт со ссылкой на Invariant 27. Для Codex/Gemini сейчас Core handler spread'ит их `reasoningByModel` / `thinkingLevelByModel` без per-level whitelist, но предостерегает: если будущий `settings-request-handler-codex-reasoning.ts` или `-gemini-thinking.ts` sibling заведёт свой hardcoded set, его надо держать в lockstep.

## 1.6. Инструментарий сессии — побочные артефакты

- **`--version` в build-all.sh** (commit `5d16da236`): скрипт теперь принимает explicit semver для не-patch bump'а, иначе остаётся auto-increment-patch поведение. Использовали для 1.2.0 (1.1.999 → 1.2.0).

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `6e2afc621 chore: add settings persist/load debug trace to extension log`
- `434fdd0d5 docs: prepare 1.2.0 diagnostic release notes`
- `5d16da236 build: accept explicit --version in build-all.sh for non-patch bumps`
- `e3769bc75 chore: build 1.2.0 diagnostic release assets`
- `beccae06b chore: add settings.json fs watcher to catch external writers`
- `7f7d114df docs: prepare 1.2.1 watcher diagnostic release notes`
- `3822fa5fb chore: build 1.2.1 diagnostic release assets`
- `c4153f3a8 fix: accept xhigh in core settings-request-handler claude normalizer`
- `24fcb59d2 chore: remove 1.2.0/1.2.1 settings debug instrumentation`
- `0bedd7d86 docs: prepare 1.2.2 fix release notes`
- `21112769b chore: build 1.2.2 release assets`

Все гейты (check-architecture.sh, ultracite, knip, typecheck webview, core build) зелёные на каждом commit'е.

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` (важно: Invariant 27 — cross-boundary thinking/reasoning normalizer parity).
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## 2.1. Состояние на конец сессии

- Активный execution scope **отсутствует**. Эта сессия шла без формального planning-doc + todo-plan (по запросу пользователя "без всяких планов"), поэтому ни `doc/SolidWorks-WorkFlow/Plans/`, ни `doc/TODO/Archive/` добавок от этой сессии нет. Активный `doc/TODO/todo-plan.md` в режиме "no active scope" (наследуется от Session 038 closeout).
- VSIX `codeai-hub-1.2.2.vsix` (2.2M) лежит в корне, ждёт retest'а.
- Tarballs для 1.2.2 в `doc/tmp/releases/`: `claude-module`, `codex-module`, `gemini-module`, `codeai-hub-core-darwin-arm64`, `project-manager`, `vscode-webview`, `CodeAIHubLauncher-macos-arm64`.
- Дерево чистое.

## 2.2. Retest v1.2.2 — RESULT: PASS

**Подтверждено пользователем 2026-04-16 21:00 CEST.** После установки 1.2.2 пользователь повторил сценарий: Settings → x-High → Save → запуск Project Manager → проверка `~/.codeai-hub/settings/settings.json`. `providers.claude.thinking.effort` остаётся `"xhigh"`, к `medium` больше не сбрасывается. Регрессия из 1.1.998 устранена. Релиз запушен в `origin/main` после подтверждения.

### Чек-лист (для будущих сессий, если фикс понадобится перепроверить)

1. **Основной фикс.** Установи 1.2.2, перезапусти VSCode. Settings → Claude → Reasoning effort = `x-High` → Save. Запусти Project Manager. Прочитай `~/.codeai-hub/settings/settings.json` — `providers.claude.thinking.effort` должен остаться `"xhigh"`. Если опять `"medium"` — регрессия не устранена, надо смотреть дальше (возможно, ещё один writer).
2. **Info-card.** Session info bar под Opus теперь должен показать `Opus (xhigh)` после первого turn'а с новой applied identity. До первого turn'а будет `Opus (medium)` — это правильное поведение (applied identity старого turn'а, см. memory `feedback-applied-vs-settings-surface.md`).
3. **Regression check для 1.1.999.** Проверь что live text bubble merge всё ещё работает: длинный Claude turn с несколькими sentence'ами подряд должен рисоваться одной растущей карточкой, не серией плашек.
4. **Regression check для 1.1.998.** Live text всё ещё приходит без пауз на `Write/Edit`; thinking на Opus 4.7 по-прежнему видимый при effort `xhigh`.

## 2.3. Если retest выявит проблемы

- **`xhigh` снова сбрасывается в `medium`.** Настоящий писатель может быть где-то ещё. В 1.2.0 / 1.2.1 debug уже снят; для повторной диагностики нужно либо вернуть `fs.watchFile` watcher в отдельный scope, либо `dtrace` / `fs_usage` уровня ОС (`sudo fs_usage -w -f filesys | grep settings.json`).
- **В Core есть ещё unfiltered normalizer.** Grep по `CLAUDE_THINKING_EFFORTS` в `packages/core/**` должен возвращать ровно два matches: `provider-defaults-resolver.ts` и `settings-request-handler-claude-thinking.ts`. Если больше — проверить, чтобы каждый содержал `xhigh`.
- **Settings UI показывает xhigh, но на диске другое.** Проверить что UI Settings view не имеет auto-save при onChange — `useSettingsState` должен триггерить persist только через explicit Save button.

## 2.4. Plans for next session

- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT (важны Invariants 25, 26, 27).
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.

## 2.5. Процессные заметки

- **Без formal planning-doc** эта сессия всё же привела к рабочему фиксу и SSOT sync'у. Однако CLAUDE.md §3-4 остаются базовым контрактом: для следующего content-scope (не post-release hotfix) сначала planning-doc → agreement → todo-plan → execution.
- **Progress tracking.** Использовал TodoWrite оперативно, real-time progress отмечал в голове сессии; todo-plan.md не трогался потому что не было активного execution cycle (наследие из Session 038 closeout). В будущем: если scope достаточно крупный для phases/streams — оформляем todo-plan, даже короткий.
- **Диагностический релиз как легитимный инструмент.** 1.2.0/1.2.1 не приносили features, только логирование. Это рабочий подход когда root cause не удаётся локализовать по статическому анализу. Cleanup обязателен в том же execution cycle, что и фикс — иначе diagnostic logs остаются production bloat.
