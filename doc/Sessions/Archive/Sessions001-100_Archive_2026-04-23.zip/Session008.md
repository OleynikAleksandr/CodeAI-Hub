# Session 008 — Codex Translation Engine Release Hotfix

**Date:** 2026-04-13 18:59 (CEST)
**Branch:** main
**Version:** 1.1.976
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- User reported a release regression in `1.1.975` after selecting `Localization > Translation Engine = OpenAI Codex · GPT-5.3 Codex Spark` inside workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4`.
- Investigation was completed against Core logs, Codex SDK logs, raw provider rollout logs, and persisted unified-session transcripts.
- Confirmed root cause A: Codex rollout thinking was translated twice, once provider-local in `packages/Codex_Module/src/rollout/codex-rollout-live-sync.ts` and once again by the Core-owned thinking translation overlay pipeline.
- Confirmed root cause B: rollout `final_answer` plain text was discarded in `outputSchema` mode when structured-output parsing returned no `assistantText`, even though the provider had already emitted a valid final answer in raw rollout logs.
- Completed the hotfix in `packages/Codex_Module/src/rollout/codex-rollout-live-sync.ts` and `packages/Codex_Module/src/rollout/codex-rollout-live-sync.test.ts`:
  - removed provider-local rollout-thinking translation;
  - kept Core overlays as the single thinking-translation owner;
  - restored plain-text final assistant fallback for rollout `final_answer` under `outputSchema`;
  - removed the obsolete `packages/Codex_Module/src/messaging/codex-thought-translation-adapter.ts`.
- Synced the implemented behavior into SSOT:
  - `doc/SolidWorks-WorkFlow/Modules/Codex.md`
  - `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
- Prepared release-visible docs for `1.1.976` in `README.md` and `CHANGELOG.md`.
- Rebuilt the full release pipeline successfully:
  - targeted verification: `./node_modules/.bin/tsx --test packages/Codex_Module/src/rollout/codex-rollout-live-sync.test.ts packages/Codex_Module/src/messaging/message-processor.replay.test.ts packages/Codex_Module/src/messaging/message-processor.empty-terminal.test.ts`
  - targeted build: `npm run build --workspace @codeai-hub/codex-module`
  - unified build: `./scripts/build-all.sh`
  - release packaging: `./scripts/build-release.sh --use-current-version`
- Produced the new VSIX package: `codeai-hub-1.1.976.vsix`.
- Archived the planning scope into `doc/SolidWorks-WorkFlow/Plans/Archive.zip`, restored `doc/TODO/todo-plan.md` to placeholder state, and returned the workspace to a no-active-scope state.

## Post-release validation findings
- User manually tested `codeai-hub-1.1.976.vsix` immediately after the rebuild in workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4`.
- Observed improvement versus `1.1.975`:
  - behavior is better than before;
  - at least part of Codex thinking is now translated;
  - the turn no longer fails in the exact same fully-broken way as the previous release.
- New unresolved defects reported after testing `1.1.976`:
  - only part of thinking/reasoning is translated; some visible thinking chunks remain English;
  - visible delay is still too large, despite the intended source-first contract where original English should appear immediately and translation should arrive later as an overlay patch;
  - the real assistant answer was observed in English, which strongly suggests that the translation path is touching more than just thinking and may be translating already-localized user-facing assistant text in the wrong direction.
- User expectation for the next session:
  - keep source-first behavior for thinking;
  - do not block visible delivery on translation;
  - do not translate ordinary assistant answers through the thinking overlay path;
  - investigate why some chunks are skipped while others are translated.
- Important note: these `1.1.976` testing findings were reported at the very end of the session and were **not** investigated yet in code or logs during this session.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `4b2119099 docs: start codex spark release hotfix scope`
- `c976ff812 fix: repair codex rollout translation and final answer fallback`
- `4ac589c18 docs: sync codex rollout hotfix ssot`
- `45cf62815 docs: prepare release notes for 1.1.976`
- `e8da0b8e4 chore: bump version via build-all.sh`
- `557e47eca docs(archive): close codex release hotfix scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
- Приоритетный следующий scope уже понятен: post-release investigation for `codeai-hub-1.1.976.vsix` after the user's validation findings above.
- Первый шаг следующей сессии после чтения базового SSOT:
  - зафиксировать новый planning scope под post-release Codex translation regression;
  - открыть свежие диагностические артефакты для workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4`.
- Первые логи и артефакты, которые нужно смотреть в следующей сессии:
  - `~/.codeai-hub/logs/core/core.log`
  - `~/.codeai-hub/logs/codex/sdk-codex-*.jsonl`
  - `~/.codeai-hub/providers/codex/home/sessions/**/rollout-*.jsonl`
  - `~/.codeai-hub/sessions/-Users-oleksandroliinyk-VSCODE-CodeAI-Hub-codex-5-4/**`
- Наиболее вероятные стартовые code-paths для расследования:
  - `packages/core/src/session-translation/session-translation-facade.ts`
  - `packages/core/src/session-translation/session-translation-dispatcher.ts`
  - `packages/core/src/remote-bridge/handlers/session-request-handler-event-messages.ts`
  - `packages/Codex_Module/src/messaging/codex-stream-event-router.ts`
  - `packages/Codex_Module/src/rollout/codex-rollout-live-sync.ts`
- Новая рабочая гипотеза, которую нужно проверить первой:
  - translation overlay path может быть слишком широким и задевать не только `thinking`, но и обычный assistant-output;
  - либо source/target language resolution в конкретном runtime path работает неверно и часть уже-русского текста отправляется в engine как будто его тоже нужно переводить.
