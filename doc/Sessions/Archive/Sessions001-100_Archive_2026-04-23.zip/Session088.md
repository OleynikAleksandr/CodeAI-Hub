# Session 88 — CEF macOS Shutdown Crash Mitigation And Release 1.2.50

**Date:** 2026-04-22 14:35 (CEST)
**Branch:** main
**Version:** 1.2.50
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- User retest на 1.2.49 уточнил ключевую деталь `BUG-2026-04-22-01`: crash `NSApplication unrecognized selector` **детерминирован** только при клике по красной NSWindow close кнопке (путь `LauncherWindowDelegate::CanClose` → `browser->GetHost()->TryCloseBrowser()` → Chromium async browser-teardown), и **не** воспроизводится при Cmd+Q / Dock Quit (которые идут через `-[NSApplication stop:]` и обходят buggy Chromium teardown callback).
- Crash report analysis (`CodeAIHubLauncher-2026-04-22-141145.ips`): exception arguments `["NSApplication", "%s", "0x13800190d80"]` — literal `"%s"` format specifier означает `objc_msgSend` called с NULL/corrupted `SEL`. OS `macOS 26.3.1`, Chromium 141 в нашем CEF (`141.0.10+chromium-141.0.7390.123`) отправляет AppKit-private selector, который больше не существует. Это чистая Chromium ↔ macOS 26 incompat, proper fix требует CEF/Chromium upgrade.
- Открыт и закрыт execution cycle `1.2.50` — targeted mitigation через `NSUncaughtExceptionHandler` без каких-либо изменений NSApplication class, window-close flow, Info.plist, delegate (осознанное не-повторение ошибок 1.2.46/1.2.48).
- Stream A: в `packages/cef-launcher/src/platform/mac/app_main_mac.mm` добавлен namespace-local `InstallCodeAIHubUncaughtExceptionHandler()` + `CodeAIHubUncaughtExceptionHandler`. Вызывается из `main()` сразу после `CefScopedLibraryLoader::LoadInMain()`, до `CefExecuteProcess`. Previous handler сохраняется через `NSGetUncaughtExceptionHandler()`; наш handler ловит `NSInvalidArgumentException` где reason содержит `unrecognized selector sent to instance` и `NSApplication`, логирует в stderr `CodeAIHubLauncher: suppressed NSApplication unrecognized selector: ...` и возвращается без propagation. Любое другое uncaught exception forward'ится в previous handler, чтобы не прятать реальные bugs. Планинг-док `CEF_MacOS_Shutdown_Crash_Mitigation_Architecture.md` создан и принят (Accepted) — 83 строки.
- Stream B: SSOT синхронизирован. `SystemArchitecture.md` §3 Invariant 32 расширен mitigation note (1.2.50 NSUncaughtExceptionHandler + pending CEF upgrade). `Launcher_CEF.md` получил новый subsection "Shutdown-crash mitigation (1.2.50)" с root cause / mitigation / trade-off. `BugRegistry.md` `BUG-2026-04-22-01` переведён из DEFERRED в MITIGATED с полным narrative (window-close only trigger, Chromium 141 ↔ macOS 26 incompat, handler implementation, commit hash, explicit note про deferred proper fix). Rollback history 1.2.46 → 1.2.48 → 1.2.49 сохранена как context.
- Stream C: release metadata — `README.md` Current Release → v1.2.50 с описанием refined crash trigger, mitigation и explicit preservation of 1.2.49 behaviour. 1.2.49 передвинут в previous (без regression метки, т.к. он остаётся paste/SuperWhisper fix baseline). `CHANGELOG.md` получил секцию `## [1.2.50]` с Fixed / Added / Known deferred issue / Not touched / Docs subsections.
- Stream D: release build — `./scripts/build-all.sh --version 1.2.50` (CEF launcher slinked с свежим `app_main_mac.mm`, 228/228 objects без `codeai_hub_application_mac.mm` как в 1.2.49). `./scripts/build-release.sh --use-current-version` — SDK exclusions verified, local artefacts validated, VSIX runtime surface verified. Финальный артефакт `codeai-hub-1.2.50.vsix` (2.3M) в root репозитория. Tarballs в `doc/tmp/releases/` и `~/.codeai-hub/releases/`: CodeAIHubLauncher-macos-arm64-1.2.50, codeai-hub-core-darwin-arm64-1.2.50, claude/codex/gemini-module-1.2.50, vscode-webview-1.2.50, project-manager-1.2.50.
- Stream E: планинг-док `CEF_MacOS_Shutdown_Crash_Mitigation_Architecture.md` перемещён в `Plans/Archive/`; todo-plan → `doc/TODO/Archive/todo-plan-phase1-cef-macos-shutdown-crash-mitigation.md`; `doc/TODO/todo-plan.md` возвращён к neutral no-active-scope stub; `Docs_Index.md` получил описание mitigation scope.

## Verification
- Husky pre-commit зелёный на каждом из 5 коммитов.
- `./scripts/build-all.sh --version 1.2.50` exit 0; CEF launcher slinked с new exception handler code.
- `./scripts/build-release.sh --use-current-version` exit 0: Step 7 SDK exclusions verified, Step 7.5 local artefacts validated, Step 9.5 VSIX runtime surface verified, Step 10 package size 2.3M.
- Manual acceptance matrix — user retest на installed `codeai-hub-1.2.50.vsix`:
  - Cmd+V paste / SuperWhisper / Cmd+C/X/A / меню Edit / Cmd+Q / Dock Quit / dock reopen — всё работает как в 1.2.49 (без регрессий).
  - **Main criterion:** клик по красной NSWindow close кнопке больше не показывает "CodeAI Hub Project Manager quit unexpectedly" dialog. Launcher closes clean.
  - Если exception срабатывает — в stderr / Console log должна быть запись `CodeAIHubLauncher: suppressed NSApplication unrecognized selector: ...` (признак работы handler'а).

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `953fb31fc fix(launcher-mac): suppress NSApplication unrecognized selector crash on window close`
- `b8a141e00 docs: sync 1.2.50 shutdown crash mitigation contract`
- `1574e5dea docs: prepare 1.2.50 release metadata`
- `95cea454c chore: release 1.2.50`
- `3b9b8002e docs: archive 1.2.50 shutdown crash mitigation scope`

## User feedback
- 2026-04-22: user retest 1.2.49 подтвердил восстановление clipboard/voice input и уточнил crash trigger — детерминирован только на красной NSWindow close кнопке, не на Cmd+Q / Dock Quit. Пользователь запросил targeted fix, который не трогает clipboard functionality и ничего другого, что работает. В ходе обсуждения я корректировался: изначально предлагал combo Вариант 1 (NSUncaughtExceptionHandler) + Вариант 2 (Info.plist sudden-termination keys); после уточнения user'а про window-close-only trigger мне стало понятно что Info.plist keys вероятно irrelevant (они про auto-termination в фоне), и я предложил focused Вариант 1. Пользователь подтвердил этот refined plan.

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.

## User retest checklist for 1.2.50 (обязательно)
- Установить `codeai-hub-1.2.50.vsix`, открыть standalone Project Manager.
- **Без регрессий 1.2.49:** Cmd+V, SuperWhisper, Cmd+C/X/A, меню Edit, Cmd+Q, Dock Quit, dock reopen работают.
- **Main criterion:** клик по красной NSWindow close кнопке больше не вызывает "quit unexpectedly" dialog.
- **Signal handler работает:** если crash всё-таки был бы — в stderr/Console log присутствует запись `CodeAIHubLauncher: suppressed NSApplication unrecognized selector: ...`. Если crash dialog всё ещё появляется — сохранить crash report и escalate, proper fix (CEF upgrade) нужен отдельным cycle.

## Deferred follow-up (если проблема возникает снова)
- **CEF/Chromium upgrade:** BUG-2026-04-22-01 в MITIGATED state, но proper fix остаётся deferred. Upgrade до CEF версии с Chromium 142+ или 143+, который понимает macOS 26 selector semantics — большой scope, требует download/rebuild CEF binary, API compat check, riskly regression на других platforms. Отдельный execution cycle когда user готов к более крупной работе.

## Архивы текущего цикла
- Planning: `doc/SolidWorks-WorkFlow/Plans/Archive/CEF_MacOS_Shutdown_Crash_Mitigation_Architecture.md`
- TODO: `doc/TODO/Archive/todo-plan-phase1-cef-macos-shutdown-crash-mitigation.md`
- Релизный артефакт: `codeai-hub-1.2.50.vsix` (repo root) + tarballs в `doc/tmp/releases/`.
