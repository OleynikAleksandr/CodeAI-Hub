# Session 49 — 1.2.18 Release State + Experiment Orchestration Handoff

**Date:** 2026-04-19 07:25 CEST
**Branch:** `main`
**Version:** `1.2.18`
**Execution Scope Status:** ACTIVE

---

# 1. Work Done in This Session

## Work summary
- Зафиксирован реальный post-`Session048` state active umbrella-scope `1.2.18`: кодовая реализация и release-build на `main` завершены, но process closeout в `Phase 3 / Stream 3 / WAVE-6` ещё не закоммичен в `main`.
- На `main` уже вошёл основной implementation/release chain для umbrella cycle:
  - Claude orphan-suffix fix + tests,
  - Codex final-answer dedupe fix + tests,
  - PM optimistic stop/resend reconcile,
  - PM usage ownership refactor + tests,
  - PM background polling throttling,
  - Core/provider replay-first usage telemetry,
  - SSOT sync,
  - release notes,
  - release commit `1.2.18`.
- Текущее грязное дерево `main` отражает именно незакрытый closeout-хвост umbrella-cycle:
  - `doc/BugRegistry.md`
  - `doc/SolidWorks-WorkFlow/Docs_Index.md`
  - `doc/TODO/todo-plan.md`
  - 4 planning-doc в `doc/SolidWorks-WorkFlow/Plans/`
- Проведён baseline experiment `v2` в отдельных worktree:
  - `solo-v2`: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-solo-v2`
  - `parallel-v2`: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v2`
- Итоги `v2`:
  - `solo-v2`: success, `4102s`, `usage.sessions: 1`, `usage.subagents: 0`, `usage.totalTokens: 45,246,980`, `usage.freshFootprintTokens: 893,828`, `finalHead: 88ae320f6`
  - `parallel-v2`: success, `3937s`, `usage.sessions: 7`, `usage.subagents: 6`, `usage.totalTokens: 74,346,616`, `usage.freshFootprintTokens: 2,208,632`, `finalHead: 78c26a176`
  - `parallel-v2` оказался быстрее `solo-v2` на `165s` (около `4.0%`), но значительно дороже по токенам.
- Ключевой вывод по `v2`: это полезный, но не окончательный тест. В `parallel-v2` был процессный дефект orchestration contract: общий принцип `microtask + commit` конфликтовал с конкретным делегирующим prompt, из-за чего child flow мог сначала вернуть результат без собственного commit, а commit discipline догонялась позже.
- Для исправления этого дефекта подготовлен `parallel-v3` experiment workspace:
  - `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v3`
  - ветка `codex/exp-parallel-v3-1.2.17`
  - latest valid recovery report там: `doc/Sessions/Session045.md`
  - active execution packet там: `doc/TODO/todo-plan.md`
- Суть `parallel-v3`: каждая eligible `EXEC:PARALLEL` задача обязана идти по схеме `sandbox git worktree -> child commit -> root cherry-pick`; orchestration helper лежит в `scripts/parallel-sandbox-manager.js`, telemetry — в `scripts/experiment-tracker.js`.
- Важная housekeeping-правка: ошибочно созданный experiment-handoff `Session046.md` внутри `parallel-v3` удалён, чтобы не подменять workspace-specific implementation recovery. Для запуска новой сессии в `parallel-v3` правильным latest report остаётся `Session045.md`.

## Git commits
(ВАЖНО: при `Execution Scope Status: ACTIVE` следующая сессия обязана просмотреть каждый коммит через `git show --stat <hash>` и `git show <hash>`.)
- `d642f51e1 refactor(pm): remove mount-driven usage refresh ownership`
- `b243c09a9 fix(codex): dedupe rollout final answer emission`
- `336cfadfc fix(claude): make final live text finalization order-safe`
- `8d95ac49c fix(pm): reconcile optimistic stop-resend user messages`
- `0ba4b9eee fix(pm): repair usage refresh refactor typecheck`
- `2cd698b57 fix(pm): throttle workflow polling for background clients`
- `2cd5130a5 test(codex): guard rollout final answer dedupe`
- `0633a9ea5 test(claude): guard order-safe live text finalization`
- `34cd74baf test(pm): guard optimistic stop-resend reconciliation`
- `4050cb970 docs: sync provider and PM duplication contracts`
- `2cfb18b9a fix(pm): throttle background artifact polling`
- `c845a5c24 test(pm): guard display-only usage ownership`
- `537837d91 fix(pm): suppress idle dialog refresh churn`
- `b2f58abb4 fix(providers): deliver usage telemetry on turn completion`
- `0c538fe70 fix(core): make usage telemetry replay-first on reopen`
- `f49cdaed2 test(core): guard replay-first usage telemetry`
- `966094008 docs: sync session contracts for duplication and replay fixes`
- `3438f5a6b docs: sync PM telemetry and polling invariants`
- `12ac1909e docs: prepare 1.2.18 release notes for duplication and PM refresh fixes`
- `6ed8280b8 fix(repo): restore knip runtime entrypoints`
- `aed1607b9 test(pm): fix dialog snapshot replay custom event typing`
- `4841a78bf chore: bump version to 1.2.18`

---

# 2. Instructions for Next Session

**Recovery Owner:** `doc/TODO/todo-plan.md`

## Plans for next session
- Сначала восстановить active `main` scope по `doc/TODO/todo-plan.md`. В `main` незакрытым остаётся только `Phase 3 / Stream 3 / WAVE-6` closeout umbrella-cycle `1.2.18`.
- После чтения этого report следующая сессия обязана просмотреть все commit из списка выше, потому что `main` всё ещё в статусе `ACTIVE`.
- Если пользователь хочет продолжать именно experiment-track, то orchestration context брать из этого `Session049`, а execution workspace открывать отдельно:
  - `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v3`
- При переходе в `parallel-v3` восстановление делать не по этому report, а по workspace-local packet:
  - `doc/Sessions/Session045.md`
  - `doc/TODO/todo-plan.md`
  - `git show --stat bbeb8dd90 && git show bbeb8dd90`
  - `git show --stat 9c0aa2ee7 && git show 9c0aa2ee7`
- Для сравнения experiment baseline использовать готовые tracker summary:
  - `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-solo-v2/doc/tmp/experiments/solo-v2-1.2.18/summary.txt`
  - `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v2/doc/tmp/experiments/parallel-v2-1.2.18/summary.txt`
- В `parallel-v3` нельзя подменять implementation recovery экспериментальными summary-отчётами в духе orchestration handoff. `parallel-v3` должен хранить только свой workspace-specific execution context.
- Если следующая сессия решит сначала закрыть `main`-closeout, а не запускать `parallel-v3`, нужно:
  - архивировать umbrella planning path,
  - закрыть `BUG-2026-04-18-03..06`,
  - перенести исполненный `todo-plan` в `doc/TODO/Archive/`,
  - сбросить active `doc/TODO/todo-plan.md` в empty placeholder.
