# Session 47 — Claude + Codex Duplication + PM Performance Design Intake

**Date:** 2026-04-18 12:23 CEST
**Branch:** main
**Version:** 1.2.17 (released; follow-up regression under investigation)
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Выполнено forensic-расследование follow-up дефекта на ретесте `1.2.17`: после финального Claude ответа unified session могла сохранить отдельную лишнюю assistant bubble `ell.`.
- Сопоставлены три источника истины: unified session JSONL, native Claude session JSONL и SDK trace. Подтверждено, что native provider output и SDK output чистые, а повреждение возникает уже в нашем post-SDK Claude routing/finalization path.
- Подтверждён root cause уровня дизайна: current Claude live text finalization order-sensitive и допускает dual finalization одного text block через `live text` path и `regular assistant flush`.
- Создан planning-doc `doc/SolidWorks-WorkFlow/Plans/Claude_LiveText_OrderSafe_Finalization.md` с problem statement, confirmed evidence, целевым single-owner finalization contract, target files и regression guards.
- Выполнено forensic-расследование двух Codex duplication bug class в одной dialog session:
  - transient duplicate user bubble после `Stop` + fast resend;
  - persisted duplicate final assistant answer.
- Подтверждено разделение root cause по слоям:
  - user duplicate не записывается в unified session truth и исчезает после workspace switch, значит живёт в PM optimistic/hydration path;
  - assistant duplicate записывается в unified session и вызван dual terminal emission в Codex rollout path (`final_answer` + `task_complete`).
- Создан planning-doc `doc/SolidWorks-WorkFlow/Plans/Codex_Dialog_Duplication_StopResend_And_FinalAnswer.md` с двумя bug classes, confirmed evidence, root cause per layer, target files и regression guards.
- Выполнено forensic-расследование PM/core performance degradation при нескольких одновременно открытых workspace/session в Project Manager.
- Подтверждено, что primary evidence сейчас указывает не на доказанную утечку provider one-turn процессов, а на повторяющийся PM/core background churn:
  - repeated `pm.dialog.bootstrap.resolved` / `pm.refreshUsageLimits.requested` по тем же completed sessions;
  - mount-driven `SessionIdBar` usage refresh;
  - dialog history/list rereads;
  - workflow/artifact polling, умножающийся на несколько PM clients;
  - expensive provider-side usage rereads, особенно в Codex rollout path.
- Согласована design direction для будущего fix cycle:
  - `usageLimits` должны обновляться по жёстким event trigger'ам `session open/bootstrap` и `turn_completed`;
  - `tokenUsage` / context window должны гидратироваться из replay/cache при open и обновляться по `turn_completed`;
  - UI mount/re-render больше не должен владеть автоматическим refresh.
- Создан planning-doc `doc/SolidWorks-WorkFlow/Plans/ProjectManager_MultiWorkspace_Performance_And_EventDriven_UsageRefresh.md` с confirmed evidence, root cause, trigger matrix и target files.
- `doc/SolidWorks-WorkFlow/Docs_Index.md` обновлён, чтобы все три новых planning scope были discoverable в следующей сессии.
- Новый execution cycle не открывался; `doc/TODO/todo-plan.md` не создавался, кодовые правки не выполнялись.

## Git commits
(REFERENCE ONLY: planning-only сессия; содержательных git commit в этой сессии не создавалось.)
- none

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем, стартует ли follow-up fix по одному из новых scope, по нескольким scope вместе или по всем трём scope одним execution cycle.
- Для Claude scope агент обязан открыть `doc/SolidWorks-WorkFlow/Plans/Claude_LiveText_OrderSafe_Finalization.md`.
- Для Codex scope агент обязан открыть `doc/SolidWorks-WorkFlow/Plans/Codex_Dialog_Duplication_StopResend_And_FinalAnswer.md`.
- Для PM/core performance scope агент обязан открыть `doc/SolidWorks-WorkFlow/Plans/ProjectManager_MultiWorkspace_Performance_And_EventDriven_UsageRefresh.md`.
- Следующая сессия должна использовать эти три planning-doc как planning inputs и после согласования scope нарезать новый `doc/TODO/todo-plan.md`.
- После выбора scope агент обязан синхронизировать соответствующие Bug Registry entry и только потом формировать новый `doc/TODO/todo-plan.md`.
- До появления нового `doc/TODO/todo-plan.md` навигационной опорой служат `doc/SolidWorks-WorkFlow/Docs_Index.md` и все три planning-doc.

## Документы для чтения перед созданием нового todo-plan
- `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
- `doc/SolidWorks-WorkFlow/Clusters/Project_Manager.md`
- `doc/SolidWorks-WorkFlow/Clusters/CoreOrchestrator.md`
- `doc/SolidWorks-WorkFlow/Modules/Claude.md`
- `doc/SolidWorks-WorkFlow/Modules/Codex.md`
- `doc/SolidWorks-WorkFlow/Modules/UI_Bundles.md`
- `doc/SolidWorks-WorkFlow/Contracts/SessionUI_Behavior.md`
- `doc/SolidWorks-WorkFlow/Contracts/Dialogs_And_Continuity_Routing.md`
- `doc/SolidWorks-WorkFlow/Contracts/WorkspaceRuntime.md`
- `doc/SolidWorks-WorkFlow/Contracts/SessionContinuity.md`
- `doc/SolidWorks-WorkFlow/Contracts/FacadeClassDiagram_DesignAndMaintenance.md`

## Notes
- Этот intake intentionally остановлен на design stage: без кодовой реализации, без build/release шагов и без нового bugfix cycle.
- Claude defect является follow-up regression после релиза `1.2.17`, но пока не оформлен в отдельный execution scope.
- Codex intake тоже остановлен на planning stage: transient PM/UI duplicate и persisted rollout duplicate подтверждены, но кодовый цикл ещё не открыт.
- PM/core performance intake тоже остановлен на planning stage: background churn и желаемый event-driven trigger contract подтверждены на уровне дизайна, но кодовый цикл ещё не открыт.
