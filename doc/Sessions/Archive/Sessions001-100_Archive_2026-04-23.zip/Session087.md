# Session 87 — CEF macOS Bootstrap Full Rollback And Release 1.2.49

**Date:** 2026-04-22 12:13 (CEST)
**Branch:** main
**Version:** 1.2.49
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- User retest 1.2.48 подтвердил: Cmd+V / paste и SuperWhisper по-прежнему не работают в input Project Manager. Моя narrow fix из Session086 (удаление Edit menu + стандартный `applicationShouldTerminate:` path) был теоретически разумен, но не попал в реальный paste-breaker.
- Пользователь запросил **полный rollback CEF macOS bootstrap refactor** (коммиты `de7c5ad37`, `b6b0cf3d1`, `a97c5e9c5`, `a6dd758b2`) — и acceptance trade-off: редкий `NSApplication unrecognized selector` crash-on-quit возвращается как deferred known issue, потому что сломанный clipboard + voice input — более серьёзная боль, чем редкий crash. Usage-limits fixes из 1.2.45 / 1.2.47 сохраняются.
- Открыт и закрыт execution cycle `1.2.49` с коротким Accepted planning-doc `CEF_MacOS_Bootstrap_Rollback_Architecture.md`.
- Stream A: удалены `codeai_hub_application_mac.{h,mm}`, `app_main_mac.mm` восстановлен в состоянии коммита `70ac9a6ac` (predecessor of `de7c5ad37`), убраны соответствующие entries из `packages/cef-launcher/CMakeLists.txt` (`PLATFORM_SOURCES` + `set_source_files_properties`).
- Stream B: SSOT rollback. `SystemArchitecture.md` §3 Invariant 32 переписан как rollback note; Invariant 33 (1.2.48) удалён. `Launcher_CEF.md` macOS Bootstrap Lifecycle Boundary редуцирована до plain-NSApp contract + deferred shutdown-crash acceptance guardrail. `BugRegistry.md` переоткрыл `BUG-2026-04-22-01` как DEFERRED с rollback note (historical 1.2.46 fix-карточка сохранена); `BUG-2026-04-22-04` переведён в FIXED (via rollback in 1.2.49) с final resolution note.
- Stream C: release metadata — `README.md` Current Release → v1.2.49; 1.2.48 и 1.2.46 явно помечены как reverted. `CHANGELOG.md` получил секцию `## [1.2.49]` с subsections Reverted / Fixed / Known deferred issue / Docs.
- Stream D: release build — `./scripts/build-all.sh --version 1.2.49` (CEF launcher 228/228 объектов против 229 в 1.2.48, что подтверждает успешное удаление `codeai_hub_application_mac.mm` из build), `./scripts/build-release.sh --use-current-version` (Step 7 SDK exclusions verified, Step 7.5 local artefacts validated, Step 9.5 VSIX runtime surface verified). Финальный артефакт — `codeai-hub-1.2.49.vsix` (2.3M) в root репозитория. Tarballs в `doc/tmp/releases/` и `~/.codeai-hub/releases/`: CodeAIHubLauncher-macos-arm64-1.2.49, codeai-hub-core-darwin-arm64-1.2.49, claude/codex/gemini-module-1.2.49, vscode-webview-1.2.49, project-manager-1.2.49.
- Stream E: планинг-док `CEF_MacOS_Bootstrap_Rollback_Architecture.md` перенесён в `Plans/Archive/`, todo-plan → `doc/TODO/Archive/todo-plan-phase1-cef-macos-bootstrap-rollback.md`, `doc/TODO/todo-plan.md` возвращён к neutral no-active-scope stub, `Docs_Index.md` получил описание rollback scope.

## Verification
- Husky pre-commit зелёный на каждом из 5 коммитов.
- `./scripts/build-all.sh --version 1.2.49` exit 0; CEF launcher slinked с restored baseline, без `codeai_hub_application_mac.mm` object.
- `./scripts/build-release.sh --use-current-version` exit 0: Step 7 SDK exclusions verified, Step 7.5 local artefacts validated, Step 9.5 VSIX runtime surface verified, Step 10 package size 2.3M.
- Manual acceptance matrix — user retest на installed `codeai-hub-1.2.49.vsix`: Cmd+V + SuperWhisper + Cmd+C/X/A + Dock right-click Quit + Cmd+Q + window close + dock reopen (deferred shutdown-crash может очень редко повторяться как known acceptable).

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `8557b598b revert(launcher-mac): drop CefAppProtocol shell and restore plain NSApplication bootstrap`
- `9a1f8071b docs: revert CEF macOS bootstrap SSOT to 1.2.45 baseline`
- `940b39af3 docs: prepare 1.2.49 release metadata`
- `324af5cf7 chore: release 1.2.49`
- `cecb707a8 docs: archive 1.2.49 rollback scope`

## User feedback
- 2026-04-22: user retest `1.2.48` подтвердил, что paste/SuperWhisper/Cmd+V всё ещё сломаны; пользователь корректно указал, что Edit menu в standalone PM вообще не отображался и моя гипотеза Session086 не попала в корень. Пользователь запросил полный rollback CEF refactor и согласовал весь scope в одном execution cycle.

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.

## User retest checklist for 1.2.49 (обязательно)
- Установить `codeai-hub-1.2.49.vsix`, открыть standalone Project Manager (CEF launcher).
- **Главный критерий:** Cmd+V в input поле PM вставляет текст из системного буфера; SuperWhisper диктовка → транскрипт попадает в input; Cmd+C / Cmd+X / Cmd+A работают.
- Dock right-click → Quit / Cmd+Q — закрывают launcher (поведение plain NSApplication, 1.2.45 baseline).
- Accepted trade-off (НЕ регрессия): редкий `NSApplication unrecognized selector` crash-on-quit может очень редко повторяться. Это deferred known issue `BUG-2026-04-22-01`, требующий отдельного investigation scope.

## Возможный follow-up (если пользователь захочет вернуться к macOS shutdown crash)
- `BUG-2026-04-22-01` re-opened. Любая новая попытка hardening обязана до merge пройти полный acceptance matrix clipboard+quit+reopen (см. `SystemArchitecture.md` §3 Invariant 32) и не может опираться на CefAppProtocol subclass без подтверждения, что Cmd+V продолжает работать.

## Архивы текущего цикла
- Planning: `doc/SolidWorks-WorkFlow/Plans/Archive/CEF_MacOS_Bootstrap_Rollback_Architecture.md`
- TODO: `doc/TODO/Archive/todo-plan-phase1-cef-macos-bootstrap-rollback.md`
- Релизный артефакт: `codeai-hub-1.2.49.vsix` (repo root) + tarballs в `doc/tmp/releases/`.
