# Session 007 — Translation Engine Selector + Codex Runtime

**Date:** 2026-04-13 18:21 (CEST)
**Branch:** main
**Version:** 1.1.975
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Expanded `Localization > Translation Engine` from the single `Google GTX Free` path to a three-option selector: `Google GTX Free`, `OpenAI Codex · GPT-5.4 Mini`, and `OpenAI Codex · GPT-5.3 Codex Spark`.
- Added production Codex-backed translation runtimes in `packages/translation`, including isolated translation-only home bootstrap, CLI path resolution, and canonical shared engine IDs.
- Propagated `translationEngineId` through Core applied turn config and wired Codex, Claude, and Gemini provider runtime paths so live user-facing translation respects the selected engine.
- Updated localization settings UI, approved dictionaries, and SSOT docs for Shared Runtime Translation, Localization, and System architecture to reflect the new selectable engines.
- Completed targeted builds for `@codeai-hub/translation`, `@codeai-hub/localization`, `@codeai-hub/core`, `@codeai-hub/codex-module`, `@codeai-hub/claude-module`, `@codeai-hub/gemini-module`, plus `npm run typecheck:webview`.
- Updated release-visible documents for `1.1.975`, successfully ran `./scripts/build-all.sh` and `./scripts/build-release.sh --use-current-version`, and produced `codeai-hub-1.1.975.vsix`.
- Closed planning scope `Localization_TranslationEngine_CodexModels_Architecture.md`, moved it into `doc/SolidWorks-WorkFlow/Plans/Archive.zip`, and returned the workspace to a no-active-scope state.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `12dc26549 docs: start codex translation engine scope`
- `cdb5676d0 feat: add codex translation runtime engines`
- `2a17f93fb feat: propagate translation engine id through core`
- `2772fa867 feat: store codex translation engine config`
- `58a1736e6 feat: wire codex translation engine selection`
- `4ad5ddeb0 feat: store claude translation engine config`
- `6918b1056 feat: wire claude translation engine selection`
- `ca96751f9 feat: store gemini translation engine config`
- `0cfe9765b feat: wire gemini translation engine selection`
- `a5723cd2e feat: add translation engine selector options`
- `608d85460 docs: add translation engine option copy`
- `cf48df68e docs: sync codex translation engine architecture`
- `b7e0af32b docs: prepare release notes for 1.1.975`
- `2196e92a7 chore: bump version via build-all.sh`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
