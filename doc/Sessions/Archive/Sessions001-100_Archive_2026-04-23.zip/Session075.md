# Session 75 — Legacy Codex SDK Module Removal (1.2.38)

**Date:** 2026-04-21 10:45 CEST
**Branch:** main
**Version:** 1.2.38
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Проведён precise audit всего репозитория на упоминания legacy `packages/Codex_Module/`. Результат: пакет полностью orphaned с релиза `1.2.22` — ноль активных импортов в Core, ноль runtime fallback логики от app-server к legacy, build scripts уже работают исключительно с `Codex_AppServer_Module`, `.vscodeignore` уже исключает legacy из VSIX. Единственные hard-зависимости на пакет — `knip.json` workspaces entry и несколько SSOT-упоминаний в активных документах.
- Phase 1 — Legacy Removal: физически удалён `packages/Codex_Module/` (~60 TypeScript-файлов + dist + node_modules), убрана запись `packages/Codex_Module` из `knip.json` workspaces, убрана строка `packages/Codex_Module/**` из `.vscodeignore`, полностью перегенерирован `package-lock.json` через `rm package-lock.json && npm install` (вычищен `@codeai-hub/codex-module` и transitive `@openai/codex-sdk@0.53.0`).
- Phase 1 — SSOT sync: обновлены `Modules/Codex.md` (legacy fallback bullet удалён, раздел `Внешний контракт` переписан под app-server as canonical single implementation при сохранении стабильного installer artifact name), `System/SystemArchitecture.md` §4 provider-modules bullet упрощён, `Contracts/Formal_Module_Cluster_Facade_Architecture.md` mermaid-диаграмма переведена на `Codex_AppServer_Module`.
- Phase 1 — Contract paths: `ProviderFailure_Recovery_And_ProviderSwitch.md` и `EffectiveModelIdentity_And_Settings_SSOT.md` перенаправлены с удалённых файлов `packages/Codex_Module/src/sdk/codex-sdk-manager.ts` и `packages/Codex_Module/src/messaging/codex-applied-turn-config.ts` на actual app-server эквивалент `packages/Codex_AppServer_Module/src/app-server/codex-app-server-facade.ts` с явным упоминанием `CODEX_APPLIED_TURN_CONFIG_KEY`.
- Phase 2 — Release 1.2.38: README.md + CHANGELOG.md обновлены под целевую версию до запуска build-all.sh (Removed / Unchanged / Docs секции, акцент на стабильности external installer contract). `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.38.vsix` (~2.37 MB), tarball'ы в `doc/tmp/releases/`. Follow-up: обнаружена auto-append логика в `scripts/build-release.sh` для legacy `Codex_Module/**` и `@codeai-hub/codex-module`, которая возвращала мёртвые строки обратно в .vscodeignore после каждого run'а — удалена.
- Verified: `unzip -l codeai-hub-1.2.38.vsix | grep -i codex_module` возвращает 0 entries, то есть legacy пакет отсутствует в собранном VSIX.
- Cycle closeout: planning-doc и todo-plan заархивированы, `Docs_Index.md` обновлён, восстановлен пустой todo-plan stub под следующий scope.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `e67a967df docs: start legacy codex module removal scope`
- `05b702072 chore: remove legacy Codex SDK module`
- `4c7d30310 docs: retire legacy Codex module from canonical SSOT`
- `0604b445c docs: retarget codex contract references at app-server module`
- `72af7cd3f docs: prepare legacy codex module removal release notes (1.2.38)`
- `59db47521 build: release 1.2.38`
- `0c8de64b3 build: stop auto-appending legacy Codex_Module to .vscodeignore`
- `b87a72bc1 docs: archive legacy codex module removal cycle (1.2.38)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase3-legacy-codex-module-removal.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/LegacyCodexModule_Removal_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
