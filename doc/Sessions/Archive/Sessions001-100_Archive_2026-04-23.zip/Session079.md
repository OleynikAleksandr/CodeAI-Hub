# Session 79 — Provider Stale-Binding Auto-Recovery (1.2.42)

**Date:** 2026-04-21 15:35 CEST
**Branch:** main
**Version:** 1.2.42
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Пользователь на релизе `1.2.41`, workspace `CodeAI-Hub claude`, stage `diagram_modules` обнаружил: отправка первого сообщения после cold-start в reopened Claude диалог тихо проваливалась — UI не блокируется "Agents is working…", нет turn running indicator, нет error toast, JSONL не обновляется. Провели анализ core.log вокруг 14:27:47 CEST — полная цепочка видна: Core получил message → resolved session → dispatch → `ClaudeSDKManager.sendMessage` → generic `Error("Session <id> not found")` → classifier `session_binding_recoverable / retryable: true` → silent drop.
- Root cause: 1.2.39 materializer корректно журналирует paper-binding с `providerSessionStatus: "ready"`, но dispatch считает этот флажок за "provider hydrated". Фактически ready означает "journaled", но provider-модульный state (Claude SDK Manager in-memory Map / Codex app-server handshakedThreadIds / Gemini session map) пуст после Core process restart. Gemini этот класс багов закрыл в `1.2.8` через typed `GeminiSessionStaleBindingError` + one-shot `invalidateProviderBinding + ensureSessionReadyForSend + resend` retry в `SessionRequestHandlerMessageDispatch.dispatchUserMessage`. Claude и Codex этот detector не имели — generic Error'ы на этом пути молча поглощались.
- После обсуждения пользователь выбрал Вариант 1 (retry на стороне dispatch — симметрично Gemini), явно отклонив Вариант 2 (eager resume всех reopened dialogs в materializer) из-за cold-start стоимости N×M.
- Planning-doc `Provider_StaleBinding_AutoRecovery_Architecture.md` зафиксировал scope, root cause split, fix по Gemini-precedent и 4 фазы.
- Phase 1 — Claude: новый `ClaudeSessionStaleBindingError` с `code: "CLAUDE_SESSION_STALE_BINDING"` и `providerSessionId`; `ClaudeSDKManager.sendMessage` (line 157) бросает typed error вместо generic; Core dispatch detector обобщён на `ReadonlySet<string>` кодов. Contract test пининг shape. Knip unused-export warning закрыт удалением неиспользуемых helpers — оставлен только класс (minimal surface).
- Phase 2 — Codex: новый `CodexSessionStaleBindingError`; в `CodexAppServerFacade` добавлен `handshakedThreadIds: Set<string>`, заполняется в `createSession` / `resumeSession`, вычищается в `closeSession`. `sendMessage` проверяет membership ДО `turn/start` JSON-RPC и бросает typed error если handshake с текущим app-server child process не был выполнен. Этот guard не полагается на error content от app-server (который недетерминирован), а гарантируется на Core-facade слое. Contract test.
- Phase 3 — SSOT + BugRegistry: `SystemArchitecture.md` §3 Invariant 1 расширен — `ready` paper-binding означает "journaled", НЕ "provider hydrated"; adapter обязан throw'ить typed stale-binding error; generic `Error` недопустим (classifier `retryable` без wired retry = silent drop). `BugRegistry.md` — запись `BUG-2026-04-21-04` с forensics / root cause / fix / commits / guards.
- Phase 4 — Release 1.2.42: README.md + CHANGELOG.md обновлены ДО build-all.sh. `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.42.vsix` (~2.28 MB), все 7 tarball'ов в `doc/tmp/releases/`.
- Cycle closeout: planning-doc и todo-plan заархивированы, `Docs_Index.md` обновлён, восстановлен пустой todo-plan stub.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `e3f087752 docs: open provider stale-binding auto-recovery scope`
- `783deba31 feat: auto-recover claude session binding on stale-send failure`
- `e4e117e6e test: pin claude stale-binding error contract`
- `c65e5172f feat: auto-recover codex session binding on stale-send failure`
- `e588dda80 test: pin codex stale-binding error contract`
- `f3266a443 docs: record provider stale-binding auto-recovery invariant`
- `0d24d60cc docs: prepare release notes for provider stale-binding auto-recovery (1.2.42)`
- `1e948e9c1 build: release 1.2.42`
- `fa73943e4 docs: archive provider stale-binding auto-recovery cycle (1.2.42)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase4-provider-stale-binding-autorecovery.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/Provider_StaleBinding_AutoRecovery_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- User acceptance для 1.2.42 ожидается: workspace `CodeAI-Hub claude`, stage `diagram_modules` — после установки VSIX и Core restart первый user message должен пройти через one-shot retry без silent drop.
- Известный baseline-дефект не текущего scope: два source-level failing тестов в `diagram-editor-facade.test.tsx` (`auto-fill` + product-part hierarchy parser) — на pre-commit/pre-push гейты не влияют, кандидат на отдельный cleanup-scope.
