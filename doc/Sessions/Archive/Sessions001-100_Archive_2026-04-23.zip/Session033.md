# Session 33 — Description Workspace Switch Release 1.1.995

**Date:** 2026-04-16 15:40 CEST
**Branch:** main
**Version:** 1.1.995
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Устранён повторяющийся баг Project Manager при смене workspace из активной Description-сессии: main area больше не принимает stale workflow snapshot прошлого workspace и не переоткрывает чужой `Final_Description.md` в новом workspace.
- Добавлен regression guard в Description startup path и обновлён таргетный тест `use-main-area-workflow-state`, чтобы derivation артефактов и session state происходили только для текущего `workspaceSlug/workspacePath`.
- Подготовлены release notes для `1.1.995`, выполнены `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version`, собран VSIX `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub/codeai-hub-1.1.995.vsix`, свежие tarball-артефакты обновлены в `doc/tmp/releases/` и `~/.codeai-hub/releases/`.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `ce089164c fix: guard description startup against stale workspace snapshots`
- `f33375fce docs: prepare 1.1.995 release notes`
- `f6ceae5b4 chore: build 1.1.995 release assets`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
