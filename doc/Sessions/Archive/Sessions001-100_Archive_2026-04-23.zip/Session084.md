# Session 84 — CEF macOS Bootstrap Hardening And Release 1.2.46

**Date:** 2026-04-22 09:53 (CEST)
**Branch:** main
**Version:** 1.2.46
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Opened and completed a dedicated execution scope for `CEF macOS` launcher hardening after investigating the intermittent Project Manager shutdown crash from the Apple diagnostic report.
- Reworked the mac launcher bootstrap to follow the official CEF sample more closely: the launcher now runs through a custom `NSApplication <CefAppProtocol>` and delegate-driven lifecycle instead of the previous simplified `sharedApplication` path.
- Added the new mac bootstrap seam into the launcher build, kept existing browser/window ownership inside `LauncherApp`, and synchronized the canonical launcher/system SSOT with the new invariant.
- Recorded the launcher crash bug as fixed in `doc/BugRegistry.md`, while leaving the two newly discovered usage-limits regressions (`Codex` missing `resetsAt` on cold-open and `Claude` delayed first cold-open refresh) as open backlog entries only. The user-requested reverse chronological order in `BugRegistry.md` was preserved.
- Prepared release metadata, ran the targeted launcher guard build, completed `./scripts/build-all.sh`, created the release commit for `1.2.46`, and successfully packaged `codeai-hub-1.2.46.vsix` in the repository root.
- Archived the completed planning/todo artifacts, restored `doc/TODO/todo-plan.md` to the neutral no-active-scope stub, and updated `doc/SolidWorks-WorkFlow/Docs_Index.md` with the archived CEF scope.
- Verification passed for `./scripts/build-cef-launcher.sh --force --launcher-version 1.2.45`, `./scripts/build-all.sh`, and `./scripts/build-release.sh --use-current-version`.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `e4df54f94 docs: open CEF mac bootstrap hardening scope`
- `de7c5ad37 feat: add CEF-compatible mac application shell`
- `b6b0cf3d1 fix: align mac launcher bootstrap with CEF sample`
- `402ed621d docs: sync CEF mac bootstrap contract`
- `cdb11f1ca docs: record CEF mac launcher crash fix`
- `2d36e7f21 docs: prepare 1.2.46 release metadata`
- `d5ff09ac7 docs: reorder bug registry by freshness`
- `029050b2b chore: release 1.2.46`
- `29ad54797 docs: archive CEF mac bootstrap hardening scope (1.2.46)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
- Архивы текущего цикла:
  - Planning: `doc/SolidWorks-WorkFlow/Plans/Archive/CEF_MacOS_BootstrapHardening_Architecture.md`
  - TODO: `doc/TODO/Archive/todo-plan-phase1-cef-macos-bootstrap-hardening.md`
