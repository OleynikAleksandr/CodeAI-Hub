# Session 026 — Settings And Project Manager Bootstrap Bugfix Release

**Date:** 2026-04-15 20:36 (CEST)
**Branch:** main
**Version:** 1.1.988
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Fixed the localization bootstrap regression that blocked first render for both VS Code `Settings` webview and standalone `Project Manager` when `anthropic-claude-haiku-4-5` was selected for localized helper/help bundles.
- Made Core `/api/v1/localization/bootstrap` cache-first instead of forcing strict rematerialization on every GET.
- Split settings loading into two phases: persisted settings snapshot first, localization runtime second.
- Removed startup-time bootstrap waiting from `Settings` and `Project Manager` entrypoints.
- Built and packaged a new release: `codeai-hub-1.1.988.vsix`.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `19a9e52ca fix: make localization bootstrap cache-first`
- `3605a8059 fix: unblock settings and project manager startup`
- `cc59d5328 docs: prepare 1.1.988 release notes`
- `444056e2a chore: build 1.1.988 release assets`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
