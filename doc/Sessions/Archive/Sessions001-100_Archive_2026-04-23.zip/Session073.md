# Session 73 — UI And Reasoning Translation Engine Split (1.2.36)

**Date:** 2026-04-20 23:10 CEST
**Branch:** main
**Version:** 1.2.36
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Расширен scope предыдущего planning-дока: reasoning превратился из runtime-only marker в полноценную пятую user-facing category с собственным target language и собственным `Reasoning Translation Engine` selector, независимо от `Messages for the User` и от UI engine.
- Phase 1 — Settings Contract Split: persisted shape расщеплён на `uiEngineId` + `reasoningEngineId` + `categories.reasoning`; legacy `engineId` мигрируется в `uiEngineId` и удаляется из persisted state; `reasoningEngineId` по умолчанию `google-gtx`; `reasoningLanguage` на первом апгрейде наследует значение от `messagesForTheUser` (без регрессии в день 1). Save-impact classifier расщеплён: UI поля остаются strict, reasoning поля стали runtime-only non-blocking.
- Phase 2 — Runtime Routing: Core `SessionTranslationPolicyResolver` переключён на `reasoningEngineId` + `reasoningLanguage`; applied turn-config envelope расширен новыми полями с сохранением legacy aliases; Claude/Codex/Gemini provider-local adapters теперь предпочитают новые поля envelope'а с legacy fallback.
- Phase 3 — Settings UI And Localized Copy: в Settings добавлены два независимых engine selector'а (`UI Translation Engine` и `Reasoning Translation Engine`) и пятая карточка `Reasoning` с собственным language selector; локализованные ключи добавлены в approved English dictionaries (`ui_labels.json`, `ui_helper_text.json`); SSOT (Localization.md, Shared_RuntimeTranslation_Module.md, UserFacing_Text_Localization_Boundary.md, SystemArchitecture.md) синхронизированы.
- Phase 4 — Verification And Release: targeted builds (`@codeai-hub/core`, `@codeai-hub/localization`, webview build+typecheck) прошли без регрессий; release docs подготовлены под 1.2.36; `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.36.vsix` (2.3 MB), tarball'ы в `doc/tmp/releases/`.
- Regression coverage: добавлены четыре теста в `session-translation-policy-resolver.test.ts` (split routing, reasoning language decoupling от `Messages for the User`, legacy-migration fallback); `session-request-handler.test.ts` фикстуры обновлены под новый envelope.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `373a94a0b docs: start ui and reasoning translation split scope`
- `040b3e5ad docs: widen split scope to fifth user-facing reasoning category`
- `0454642f5 feat: split ui and reasoning translation settings contract`
- `9c0d5fa04 feat: separate ui and reasoning localization save impact`
- `3ceccb0ab feat: route live reasoning through dedicated engine and language`
- `c569c312b feat: propagate dedicated reasoning translation metadata`
- `903b73761 fix: align provider live reasoning translation with dedicated engine and language`
- `ee3df2857 test: cover dedicated reasoning translation contract`
- `1c11db130 feat: wire split translation engine and reasoning language state`
- `878c1b538 feat: add dedicated reasoning translation engine control`
- `f64817521 feat: add dedicated reasoning language settings card`
- `377fed6c3 feat: localize split translation engine and reasoning card copy`
- `2462a4e13 docs: record reasoning category ownership split`
- `e5804c733 docs: prepare reasoning split release notes`
- `3c7acfd13 build: refresh webview bundle for reasoning split`
- `59d9155dd build: release 1.2.36`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase4-ui-reasoning-translation-split.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/UI_And_Reasoning_Translation_Engine_Split_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
