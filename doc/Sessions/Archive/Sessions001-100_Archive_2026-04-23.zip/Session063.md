# Session 63 — Release 1.2.28 For Dialog Localized Autoscroll

**Date:** 2026-04-20 13:32 CEST
**Branch:** main
**Version:** 1.2.28
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Подготовлены release-facing docs для `1.2.28`: `README.md` и `CHANGELOG.md` теперь описывают UI-фикс, при котором поздний русский `localizedContent` для последней visible thinking/assistant bubble повторно триггерит bottom-lock autoscroll.
- Выполнен полный release pipeline для `1.2.28`: `./scripts/build-all.sh` успешно поднял unified version и пересобрал provider/core/ui/launcher tarballs, затем `./scripts/build-release.sh --use-current-version` успешно собрал VSIX.
- Финальная упаковка прошла с ключевыми checkpoint-ами `Step 7: Verifying SDK exclusions`, `Removing dev dependencies before packaging`, `✅ Package created`.
- Готовый VSIX: `codeai-hub-1.2.28.vsix`; свежие tarballs лежат в `doc/tmp/releases/` и `~/.codeai-hub/releases/`.
- Post-release verification подтверждена пользователем: релиз `1.2.28` проверен вручную, заявленный autoscroll fix работает как ожидалось.
- Release scope полностью закрыт: planning-doc перенесён в `doc/SolidWorks-WorkFlow/Plans/Archive/`, `Docs_Index.md` обновлён, активный `doc/TODO/todo-plan.md` архивирован как `doc/TODO/Archive/todo-plan-1.2.28-dialog-panel-localized-last-bubble-autoscroll-release.md`, на его месте восстановлен placeholder.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `4dbeda83c docs: prepare 1.2.28 release notes`
- `f5cb71b75 build: release 1.2.28`
- `ba6c44f26 docs: close 1.2.28 release scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
