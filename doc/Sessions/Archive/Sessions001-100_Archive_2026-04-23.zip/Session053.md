# Session 53 — Codex Reasoning Streaming Investigation

**Date:** 2026-04-19 13:40 CEST
**Branch:** `main`
**Version:** `1.2.21`
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Исследован текущий Codex live-reasoning path без изменений кода: сопоставлены UI merge contract, SDK event stream, native rollout JSONL и локально установленный `codex-cli` / `@openai/codex-sdk`.
- Практически подтверждено, что в текущем app-path (`thread.runStreamed(...)` -> patched `codex exec --experimental-json`) reasoning у Codex не удалось получить как incremental `item.updated`: в тестах reasoning либо приходил terminal-only через `item.completed`, либо полностью скрывался при `model_reasoning_summary = "none"`.
- Практически проверены доступные runtime knobs: `show_raw_agent_reasoning`, `model_reasoning_summary = auto|none|detailed`, `model_reasoning_effort = xhigh`, а также прямой прогон через установленный `@openai/codex-sdk`. Ни один из этих вариантов не дал Claude-подобного progressive SDK reasoning stream.
- Отдельно подтверждено по native rollout, что provider-native `agent_reasoning` сохраняется раздельными фрагментами, а не всегда одним агрегированным блоком; именно native path сейчас остаётся самым надёжным источником для последовательного live-thinking поведения.
- По официальной документации `codex app-server` зафиксирован второй потенциальный маршрут: у app-server protocol есть специальные reasoning delta notifications (`item/reasoning/summaryTextDelta`, `item/reasoning/summaryPartAdded`) и встроенный auth surface для обоих режимов входа: `chatgpt` и `apiKey`. Это делает реалистичным отдельный Codex transport-module / provider-adapter поверх `codex app-server`, а не поверх текущего terminal-oriented SDK/CLI path.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- Нет содержательных git-коммитов: сессия была исследовательской и не меняла кодовую базу.

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Если потребуется чинить Codex thinking delivery, рассматривать два практических маршрута:
- Вариант A: `native rollout as canonical live-thinking source` с ранней активацией rollout routing, отдельным active-turn poller и Claude-подобным readable buffer/pacing поверх native `agent_reasoning`.
- Вариант B: спроектировать и отдельно исследовать новый Codex transport-module / provider-adapter на базе `codex app-server` protocol, чтобы проверять reasoning delta notifications (`item/reasoning/summaryTextDelta`, `item/reasoning/summaryPartAdded`) напрямую, не опираясь на текущий terminal-oriented SDK/CLI path.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служат `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` и `doc/SolidWorks-WorkFlow/Docs_Index.md`.
