# Session 50 — V3 Experiment Launch Handoff (Solo + Parallel)

**Date:** 2026-04-19 08:05 CEST
**Branch:** `main`
**Version:** `1.2.18`
**Execution Scope Status:** ACTIVE

---

# 1. Work Done in This Session

## Work summary
- Эта сессия не меняла код `main`; её задача — зафиксировать orchestration-context для следующей сессии, в которой нужно тестировать `v3` experiment pair: `solo-v3` и `parallel-v3`.
- `main` по-прежнему содержит незакрытый process closeout umbrella-cycle `1.2.18`: в active `doc/TODO/todo-plan.md` остался `Phase 3 / Stream 3 / WAVE-6`, а грязное дерево `main` состоит из planning/closeout документов:
  - `doc/BugRegistry.md`
  - `doc/SolidWorks-WorkFlow/Docs_Index.md`
  - `doc/TODO/todo-plan.md`
  - `doc/SolidWorks-WorkFlow/Plans/Claude_Codex_PM_FollowUp_Umbrella_Architecture.md`
  - `doc/SolidWorks-WorkFlow/Plans/Claude_LiveText_OrderSafe_Finalization.md`
  - `doc/SolidWorks-WorkFlow/Plans/Codex_Dialog_Duplication_StopResend_And_FinalAnswer.md`
  - `doc/SolidWorks-WorkFlow/Plans/ProjectManager_MultiWorkspace_Performance_And_EventDriven_UsageRefresh.md`
- Baseline `v2` уже завершён и используется как сравнение:
  - `solo-v2`: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-solo-v2/doc/tmp/experiments/solo-v2-1.2.18/summary.txt`
    - success, `4102s`, `usage.sessions: 1`, `usage.subagents: 0`, `usage.totalTokens: 45,246,980`, `usage.freshFootprintTokens: 893,828`, `finalHead: 88ae320f6`
  - `parallel-v2`: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v2/doc/tmp/experiments/parallel-v2-1.2.18/summary.txt`
    - success, `3937s`, `usage.sessions: 7`, `usage.subagents: 6`, `usage.totalTokens: 74,346,616`, `usage.freshFootprintTokens: 2,208,632`, `finalHead: 78c26a176`
  - Итог `v2`: `parallel-v2` быстрее `solo-v2` на `165s`, но заметно дороже по токенам; результат полезен, но не финален из-за дефекта orchestration contract в `parallel-v2`.
- `solo-v3` готов как чистый baseline workspace:
  - path: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-solo-v3`
  - branch: `codex/exp-solo-v3-1.2.17`
  - latest report: `doc/Sessions/Session045.md`
  - status: worktree чистый, кодовая реализация ещё не начиналась
- `parallel-v3` подготовлен как исправленный multi-agent workspace:
  - path: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v3`
  - branch: `codex/exp-parallel-v3-1.2.17`
  - latest report: `doc/Sessions/Session045.md`
  - active owner: `doc/TODO/todo-plan.md`
  - ключевой контракт `v3`:
    - child tasks запускаются только в отдельных sandbox `git worktree`
    - child model по умолчанию: `gpt-5.3-codex-spark`
    - `reasoning_effort` child worker-а: `xhigh`
    - `spawn_agent` должен идти с `fork_context: false`
    - child sandbox получает не branch-level `AGENTS.md`, а минимальный child-only policy file
    - основной агент интегрирует только через `git cherry-pick <child-hash>`
- Для `parallel-v3` уже подготовлены локальные файлы, которые пользователь намерен закоммитить прямо в том workspace до старта теста:
  - `AGENTS.md`
  - `doc/Sessions/Session045.md`
  - `doc/TODO/todo-plan.md`
  - `scripts/parallel-sandbox-manager.js`
  - `scripts/parallel-sandbox-child-agents-template.md`
  - `scripts/parallel-sandbox-spawn-template.md`
- Практический smoke-test `parallel-v3` уже подтверждён:
  - `prepare -> inspect -> remove` выполнен успешно;
  - sandbox создаётся в `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v3-sandboxes/...`;
  - `parallel-sandbox-manager.js prepare ...` возвращает `agentsMode: "sandbox-child"`;
  - внутри sandbox `AGENTS.md` действительно подменяется на child-only template;
  - sandbox после `prepare` чистый.

## Git commits
(ВАЖНО: при `Execution Scope Status: ACTIVE` следующая сессия обязана просмотреть каждый коммит через `git show --stat <hash>` и `git show <hash>`.)
- `d642f51e1 refactor(pm): remove mount-driven usage refresh ownership`
- `b243c09a9 fix(codex): dedupe rollout final answer emission`
- `336cfadfc fix(claude): make final live text finalization order-safe`
- `8d95ac49c fix(pm): reconcile optimistic stop-resend user messages`
- `0ba4b9eee fix(pm): repair usage refresh refactor typecheck`
- `2cd698b57 fix(pm): throttle workflow polling for background clients`
- `2cd5130a5 test(codex): guard rollout final answer dedupe`
- `0633a9ea5 test(claude): guard order-safe live text finalization`
- `34cd74baf test(pm): guard optimistic stop-resend reconciliation`
- `4050cb970 docs: sync provider and PM duplication contracts`
- `2cfb18b9a fix(pm): throttle background artifact polling`
- `c845a5c24 test(pm): guard display-only usage ownership`
- `537837d91 fix(pm): suppress idle dialog refresh churn`
- `b2f58abb4 fix(providers): deliver usage telemetry on turn completion`
- `0c538fe70 fix(core): make usage telemetry replay-first on reopen`
- `f49cdaed2 test(core): guard replay-first usage telemetry`
- `966094008 docs: sync session contracts for duplication and replay fixes`
- `3438f5a6b docs: sync PM telemetry and polling invariants`
- `12ac1909e docs: prepare 1.2.18 release notes for duplication and PM refresh fixes`
- `6ed8280b8 fix(repo): restore knip runtime entrypoints`
- `aed1607b9 test(pm): fix dialog snapshot replay custom event typing`
- `4841a78bf chore: bump version to 1.2.18`

---

# 2. Instructions for Next Session

**Recovery Owner:** `doc/TODO/todo-plan.md`

## Plans for next session
- После чтения этого report следующая сессия обязана просмотреть все commit из списка выше, потому что `main` остаётся в статусе `ACTIVE`.
- Если задача следующей сессии — именно запуск `v3` эксперимента, а не closeout `main`, использовать `main` только как orchestration-context и summary point.
- Для baseline-run открыть отдельный workspace:
  - `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-solo-v3`
  - восстановление делать по `doc/Sessions/Session045.md`, затем по branch-local `doc/TODO/todo-plan.md`
- Для parallel-run открыть отдельный workspace:
  - `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub-parallel-v3`
  - восстановление делать по `doc/Sessions/Session045.md`, затем по branch-local `doc/TODO/todo-plan.md`
- Перед запуском `parallel-v3` убедиться, что пользователь закоммитил там локальные sandbox-prep изменения. Если они ещё не закоммичены, не стартовать experiment run до фиксации состояния в том workspace.
- Для `parallel-v3` дополнительно проверить наличие следующих файлов:
  - `scripts/parallel-sandbox-manager.js`
  - `scripts/parallel-sandbox-child-agents-template.md`
  - `scripts/parallel-sandbox-spawn-template.md`
- В `parallel-v3` оркестратор обязан:
  - использовать `gpt-5.3-codex-spark` + `xhigh` для child worker-ов;
  - вызывать `spawn_agent` с `fork_context: false`;
  - перед каждой делегацией создавать sandbox через `node scripts/parallel-sandbox-manager.js prepare <run-id> <slot> HEAD`;
  - запускать child worker только если `prepare` вернул `agentsMode: "sandbox-child"`;
  - строить task prompt по `scripts/parallel-sandbox-spawn-template.md`;
  - интегрировать child результаты только через `git cherry-pick <child-hash>`.
- После завершения обоих `v3` прогонов вернуться в `main` и сравнить:
  - время,
  - total/fresh tokens,
  - число саб-агентов,
  - дисциплину commit chain,
  - качество процесса и точки отказа.
- Если пользователь вместо эксперимента захочет закрыть `main`-scope, тогда продолжать `Phase 3 / Stream 3 / WAVE-6` из активного `doc/TODO/todo-plan.md`.

## Suggested launch prompts
- Для `solo-v3`:
  - `Выполняй active experiment packet этой ветки. Это baseline-scenario: работай строго одним агентом, без spawn_agent и без параллельного делегирования. Доведи scope до релизной сборки и в финале отчитай время и токены по tracker.`
- Для `parallel-v3`:
  - `Выполняй active experiment packet этой ветки. Я явно разрешаю и требую использовать spawn_agent для всех EXEC:PARALLEL задач, которые проходят screening по write-scope. Для каждой такой задачи основной агент обязан сначала создать отдельный sandbox git worktree, дождаться подтверждения agentsMode=\"sandbox-child\", затем запустить child worker на gpt-5.3-codex-spark с reasoning_effort=xhigh и fork_context=false. Саб-агент обязан завершить задачу реальным git commit с указанным commit subject, а основной агент интегрирует результат только через cherry-pick готового commit hash. Если фактический spawn_agent count останется 0 или делегированная задача завершится без child commit hash, считай эксперимент недействительным и остановись с соответствующим отчётом.`
