# Session 020 — Localization Incremental Sync And Thinking Visibility Scope Closeout (Phases 3.3–5)

**Date:** 2026-04-15 19:30 (CEST)
**Branch:** main
**Version:** 1.1.985
**Execution Scope Status:** COMPLETED
**Release artefact:** `codeai-hub-1.1.985.vsix` (2.1 MB, 1908 files) в корне репозитория. Tarballs — в `doc/tmp/releases/` и `~/.codeai-hub/releases/`.

---

# 1. Work Done in This Session

## Work summary
- Восстановлен контекст по `Session019` (Execution Scope Status: ACTIVE): прочитан базовый SSOT `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`, активный `doc/TODO/todo-plan.md`, planning-doc `doc/SolidWorks-WorkFlow/Plans/Localization_IncrementalSync_And_ThinkingVisibility_Architecture.md` (сейчас заархивирован), весь Context Pack (Localization, Shared_RuntimeTranslation, Claude, Codex, Gemini, UserFacing_Text_Localization_Boundary) и коммиты сессии 019 (`dc4f9e6fa … 8e0eb1bfe`), с акцентом на emission-time gate для translation (`8e0eb1bfe`).
- **Phase 3 (Thinking Visibility) закрыта.** Оставшаяся задача `Phase 3.3` разбита на микро-подзадачи 3.3a–3.3d по правилу ≤3 файлов:
  - **3.3a** — добавлен immutable `visibilityAtEmission` на `SessionMessage` в `packages/core/src/session-manager/index.ts`, публичный helper `resolveThinkingVisibilityForProvider` в `packages/core/src/session-translation/session-translation-facade.ts`, и emission-time resolving в `packages/core/src/remote-bridge/handlers/session-request-handler-event-messages.ts`.
  - **3.3b** — UI wire contract: поле `visibilityAtEmission` в `src/types/session.ts`, `ServerSessionMessage` (`src/client/ui/src/core-bridge/types.ts`) и bridge `sanitizeMessage` (`src/client/ui/src/core-bridge/normalizers.ts`).
  - **3.3c** — введён `shouldHideThinkingMessage` в `src/client/ui/src/session/helpers.ts`, заменены replay-time filters в `session-view-helpers.tsx` и `virtual-conversation-message-utils.ts` на emission-time check (forward-only re-enable).
  - **3.3d** — зафиксирован System-level invariant 23 в `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` (emission-time thinking visibility).
- **Phase 3.5** — синхронизированы provider SSOT (`Claude.md`, `Codex.md`, `Gemini.md`) с новым правилом forward-only visibility.
- **Phase 4** — добавлены regression tests: `localization-settings-impact-classifier.test.ts` (4 кейса: provider-only / engine / glossary / single-category), `localization-selective-sync-planner.test.ts` (4 кейса: no-impact / all_non_english / affected_only / UI Labels two-bundle fan-out), расширен `thinking-display-policy.test.tsx` emission-time кейсами (hidden stays hidden, visible stays visible). Под release gate потребовался fix readonly типов в тестах (`9a2d81318`).
- **Phase 5 — Release 1.1.985 собран.** README/CHANGELOG обновлены под будущую версию до `build-all.sh`; `./scripts/build-all.sh` поднял версии, пересобрал провайдеров/core/launcher/UI. `./scripts/build-release.sh --use-current-version` отработал полностью: architecture gate → lint → knip → типизация → tests → SDK exclusions → prod-deps prune → VSIX. Scope закрыт через `docs: close incremental localization sync scope`: `todo-plan.md` → `doc/TODO/Archive.zip` (`todo-plan-phase5-localization-incremental-sync.md`), planning-doc → `doc/SolidWorks-WorkFlow/Plans/Archive.zip`, `Docs_Index.md` обновлён.
- Все изменения прошли таргетные сборки (`@codeai-hub/core`, `@codeai-hub/localization`, `build:webview`, `typecheck:webview`, `build:project-manager`) и husky gates.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки; следующая сессия не обязана читать все коммиты по умолчанию.)
- `058e9d3b6 feat: persist emission-time thinking visibility`
- `050bfd626 feat: carry emission-time visibility through session bridge`
- `8917737d0 fix: keep hidden thinking forward-only after re-enable`
- `f1cd54c10 docs: record emission-time thinking visibility invariant`
- `032323876 docs: sync thinking visibility and translation contract`
- `cabea4f4a test: cover incremental localization sync and thinking visibility`
- `12d7ca195 docs: prepare release 1.1.985 notes`
- `631c9ea0d docs: record release 1.1.985 prep commit hash`
- `0a9c79c34 chore: bump version via build-all.sh`
- `9a2d81318 fix: close localization incremental sync regressions`
- `d6cdada2b docs: close incremental localization sync scope`

---

# 2. Testing Instructions (Release 1.1.985)

Эта секция рассчитана на запуск с нулевым контекстом в следующей сессии. Она содержит всё необходимое, чтобы установить релиз, проверить user-facing acceptance criteria и записать результат.

## 2.1. Prerequisites
- OS: macOS (Darwin arm64). Релизные tarballs собраны под эту платформу; под Windows/Linux потребуется пересборка (`./scripts/build-all.sh` на целевой машине).
- Установлен VS Code.
- Установлены глобально provider CLI/SDK (`claude`, `codex`, `gemini`); они не входят в VSIX — это обязательное требование из `build-release.sh`.
- Предыдущая версия расширения `codeai-hub` (если стоит) должна быть удалена перед установкой новой.
- Перед любыми тестами желательно очистить runtime state предыдущего релиза, чтобы cold-start сценарии действительно стартовали с нуля:
  - `~/.codeai-hub/localization/cache/browser-runtime-bootstrap.json` — persisted browser bootstrap snapshot.
  - `~/.codeai-hub/localization/catalogs/**` — materialized bundles.
  - `~/.codeai-hub/settings/settings.json` — user settings. Сохраните бэкап, если хотите вернуться к текущей конфигурации.

## 2.2. Install the release
1. Из корня репозитория `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub/` убедитесь, что файл существует: `ls -la codeai-hub-1.1.985.vsix` (ожидаем ~2.1 MB).
2. Установить в VS Code одним из способов:
   - CLI: `code --install-extension /Users/oleksandroliinyk/VSCODE/CodeAI-Hub/codeai-hub-1.1.985.vsix --force`
   - UI: VS Code → Extensions → `...` menu → `Install from VSIX...` → выбрать файл.
3. Перезапустить VS Code после установки.
4. Сверка версии: VS Code → Extensions → CodeAI Hub → панель должна показывать `1.1.985`. Дополнительно можно проверить в terminal VS Code: `cat ~/.vscode/extensions/*codeai-hub*/package.json | grep '"version"'`.
5. Tarballs для CEF launcher / core / providers должны подтянуться автоматически из `~/.codeai-hub/releases/` при первом запуске; если нет — скопировать вручную или запустить `Launch Web Client` из VS Code Command Palette.

## 2.3. Acceptance criteria matrix (from the archived planning doc)

Список взят из `doc/SolidWorks-WorkFlow/Plans/Archive.zip → Localization_IncrementalSync_And_ThinkingVisibility_Architecture.md §7`. Проверяется строго «вручную» на живом Project Manager + Settings.

1. **AC-1 — Provider-only save пропускает localization overlay.** Сценарий: Settings → изменить только provider setting (например, Claude → `Thinking in dialog` или Codex → `Reasoning in dialog`, любой response-policy toggle) → Save. Ожидаемо: overlay `Synchronizing localization` не появляется, Settings не входит в busy, Project Manager + создание новой сессии не блокируются.
2. **AC-2 — Provider-only save не блокирует PM send.** Сценарий: во время сохранения из AC-1 попытаться открыть PM и отправить новое сообщение в существующий dialog. Ожидаемо: сообщение отправляется немедленно, PM не остаётся в busy placeholder.
3. **AC-3 — Engine change rebuilds только не-английские approved-группы.** Сценарий: Settings → Translation engine поменять (`Google GTX Free` ↔ `OpenAI Codex · GPT-5.4 Mini`). Одна или несколько approved-групп должны быть в не-English. Ожидаемо: strict overlay появляется, busy copy говорит про rebuild затронутых bundles, по факту пересобираются только non-English группы из (`UI Labels`, `UI Helper Text`, `Messages for the User`, `Artifacts for the User`). English-группы остаются carry-forward (не пересобираются). Диагностика: `ls -la ~/.codeai-hub/localization/catalogs/**/*.json` до/после save — mtime меняется только у non-English bundles.
4. **AC-4 — Single-group language change rebuilds только этой группы bundles.** Сценарий: Settings → сменить язык только `Messages for the User` (`en` → `ru`) → Save. Ожидаемо: rebuild только `system_feedback` bundle; UI Labels / UI Helper Text / Artifacts bundles не пересобираются. Сценарий повторить для `UI Labels` (должно пересобраться два bundle — `ui_interface` + `workflow_terms`), `UI Helper Text` (`user_guidance`), `Artifacts for the User` (`interactive_templates`).
5. **AC-5 — Helper copy явно упоминает Thinking/Reasoning.** Сценарий: Settings → Localization card → description секции `Messages for the User`. Ожидаемо: текст содержит «...visible Thinking and Reasoning bubbles...» (ровно этот оборот был добавлен в Phase 2, осталось проверить, что он дошёл до bundled webview). Аналогично проверить helper под Settings.
6. **AC-6 — Hidden thinking не переводится.** Сценарий: Claude → выключить `Thinking in dialog` (или Gemini → выключить `Thinking in dialog`; Codex использует `Reasoning in dialog` и сам не эмитит summaries при off, поэтому AC-6 для Codex проверяется косвенно — просто отсутствием reasoning события). Открыть dialog, отправить prompt, провоцирующий thinking. Ожидаемо: в логах `~/.codeai-hub/logs/core/*.jsonl` (или в network overlay payload) не появляется translation dispatch для hidden thinking message, и в UI не рендерится thinking-bubble.
7. **AC-7 — Re-enable внутри сессии forward-only.** Сценарий: в long-running dialog (или новая pilot-сессия, куда отправить один turn при toggle=off, потом второй при toggle=on):
   - Шаг 1: Claude `Thinking in dialog = off`. Отправить message, дождаться ответа. Убедиться, что thinking бабблы не появляются.
   - Шаг 2: Переключить `Thinking in dialog = on` без закрытия dialog.
   - Шаг 3: Отправить второе сообщение. Дождаться ответа.
   - Ожидаемо: видимым становится ТОЛЬКО thinking второго turn-а; thinking первого turn-а, который был hidden at emission, остаётся скрытым и НЕ backfill-ится. Scroll назад по dialog — никаких новых thinking плашек у первого ответа.
8. **AC-8 — Toggle off при видимом-at-emit thinking оставляет его видимым.** Сценарий (зеркальный AC-7):
   - Шаг 1: Claude `Thinking in dialog = on`. Отправить message — thinking виден.
   - Шаг 2: Переключить `Thinking in dialog = off`.
   - Шаг 3: Scroll назад к первому turn-у.
   - Ожидаемо: thinking первого turn-а остаётся видимым (т.к. emission-time решение было «visible»). Новый thinking (если начать ещё turn после off) не появится.
9. **AC-9 — Legacy messages без visibilityAtEmission.** Сценарий: открыть существующий dialog, который был создан ДО 1.1.985 (persisted JSONL без `visibilityAtEmission`). Ожидаемо: fallback-поведение — видимость определяется текущим toggle, как до фикса. Это бэкап для не сломанной совместимости.
10. **AC-10 — Gemini parity.** Повторить AC-6/AC-7/AC-8 для Gemini (`Thinking in dialog`). Поведение идентично Claude.
11. **AC-11 — Codex reasoning остаётся provider-owned.** Сценарий: Codex → `Reasoning in dialog = off` → Save → отправить message. Ожидаемо: overlay localization не появляется (AC-1), reasoning summaries физически не приходят (это провайдерный гейт `model_reasoning_summary = "none"` в `~/.codeai-hub/providers/codex/home/config.toml`), в UI никаких thinking/reasoning плашек нет.

## 2.4. Regression scenarios (не должны сломаться)

Эти сценарии были стабильны в 1.1.984 и должны остаться работоспособными.
- **R-1 — Initial settings save (cold start, все English).** После удаления `~/.codeai-hub/localization/cache/browser-runtime-bootstrap.json` и перезапуска — первый save `en → en` не вешает busy overlay.
- **R-2 — Engine + multiple non-English groups save.** Большой save сразу меняет engine и один language — должен корректно отработать `engine` classification (trumps categories), пересобрать all_non_english.
- **R-3 — Project Manager main-area не превращается в пустой shell после busy → ready.** Invariant 22 должен сохраниться: после strict sync PM рендерит обычный workflow tree, hook order стабилен.
- **R-4 — Live thinking translation для visible messages.** AC-7 шаг 3 — second turn thinking должен переводиться на выбранный `Messages for the User` язык (если он не English). Это косвенно проверяет, что emission-time gate не сломал happy path перевода.
- **R-5 — Reasoning one-block translation (из 1.1.984).** Каждое reasoning сообщение даёт одно translation request, не `2-5`. Проверяется в `~/.codeai-hub/logs/core/*.jsonl` по количеству `Session translation queued` на один message id.

## 2.5. Diagnostic paths
- **Core logs:** `~/.codeai-hub/logs/core/*.jsonl` — искать `Session translation skipped before dispatch` + `skipReason: "thinking_visibility_disabled"` (AC-6), `Session translation queued` + `Session translation completed` (R-4/R-5).
- **Settings snapshot:** `~/.codeai-hub/settings/settings.json` — проверить, что persisted flags совпадают с UI-toggle after save (`providers.claude.thinkingDisplaySyncEnabled`, `providers.gemini.thinkingDisplaySyncEnabled`, `providers.codex.reasoningSummaryEnabled`, `general.localization.engineId`, `general.localization.categories.*`).
- **Localization bundles:** `ls -la ~/.codeai-hub/localization/catalogs/**/*.json` — mtime показывает, какие bundles реально пересобирались (AC-3, AC-4).
- **Browser bootstrap:** `~/.codeai-hub/localization/cache/browser-runtime-bootstrap.json` — читается UI при cold-start.
- **Provider-home для Codex:** `~/.codeai-hub/providers/codex/home/config.toml` — поле `model_reasoning_summary` должно совпадать с `reasoningSummaryEnabled` после save (AC-11).
- **Session transcript JSONL:** `~/.codeai-hub/unified-session/<workspace>/<provider>/<sessionId>.jsonl` — в новых сообщениях 1.1.985 thinking-записи должны нести поле `visibilityAtEmission: "visible"` или `"hidden"`. Это прямой способ подтвердить Phase 3.3a stamping. Legacy (pre-1.1.985) записи поля не имеют.

## 2.6. Rollback
- Если критичная регрессия — удалить 1.1.985 (`code --uninstall-extension <publisher>.codeai-hub`) и установить предыдущий VSIX. Текущий стабильный предыдущий релиз: `1.1.984` (commit `3ecd58d1c build: prepare release 1.1.984 artifacts`). Tarballs 1.1.984 также лежат в `~/.codeai-hub/releases/`.
- В git: `git log --oneline -1 3ecd58d1c` для верификации.
- **Важно:** все persisted localization/caches/settings после 1.1.985 могут содержать поле `visibilityAtEmission`, которое 1.1.984 просто игнорирует (поле опциональное, парсер не строгий). Откат должен пройти без миграции, но для чистоты теста лучше удалить `~/.codeai-hub/localization/cache/browser-runtime-bootstrap.json` перед возвратом на 1.1.984.

## 2.7. Reporting format
После прогона всех AC-* и R-* зафиксировать результат:
- В новой сессии обсудить с пользователем новый scope (следующий execution cycle) или создать hotfix scope, если какой-то AC провалился.
- Если всё зелёное — отдельный commit/сессия не нужны; достаточно устного/чат-подтверждения.
- Если что-то красное — завести новый planning-doc `doc/SolidWorks-WorkFlow/Plans/Localization_IncrementalSync_<Hotfix>_Architecture.md` с минимальным scope под обнаруженный баг и открыть новый `doc/TODO/todo-plan.md`.

---

# 3. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует. Релиз `1.1.985` готов к ручному тестированию по §2.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT (с акцентом на invariant 22 про Localization blocking UI и invariant 23 про emission-time thinking visibility — это контракт, который сейчас тестируется).
- Затем агент обязан согласовать с пользователем, что именно происходит в сессии:
  - **Ветка A — ручное тестирование по §2.** Пройти AC-1 … AC-11 и R-1 … R-5, зафиксировать результат.
  - **Ветка B — новый scope.** Если тестирование не планируется прямо сейчас, запросить у пользователя новое задание, открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы и сформировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/` перед созданием `doc/TODO/todo-plan.md`.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
- Готовый релиз: `codeai-hub-1.1.985.vsix` в корне, tarballs — в `doc/tmp/releases/` и `~/.codeai-hub/releases/`.
