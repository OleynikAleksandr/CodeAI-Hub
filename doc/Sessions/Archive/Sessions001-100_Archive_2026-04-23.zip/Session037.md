# Session 37 — Claude Live Text And Opus 4.7 Thinking Visibility

**Date:** 2026-04-16 19:00 CEST
**Branch:** main
**Version:** 1.1.998
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## 1.1. Почему сессия вообще случилась (контекст retest'а v1.1.997)

Предыдущая сессия (Session 36) закрыла дефект `Stop crashes core` и заложила архитектуру live thinking (`ClaudeThinkingLiveBuffer` + `ClaudeThinkingStreamHandler`), собрала v1.1.997. Пользователь установил сборку и при первом же длинном turn'е (description-агент с `Write Final_Description.md`) получил ~5-минутную тишину в диалоге.

Пользователь прислал три файла для сравнения и попросил разобраться:
1. Native Claude JSONL: `~/.codeai-hub/providers/claude/home/.claude/projects/-Users-oleksandroliinyk-VSCODE-CodeAI-Hub-claude/a5d2e9a8-014e-4dba-aa93-0920bb7a6427.jsonl`
2. Наш SDK diagnostic log: `~/.codeai-hub/logs/claude/sdk-claude-a5d2e9a8-014e-4dba-aa93-0920bb7a6427.jsonl`
3. Наша unified session JSONL: `~/.codeai-hub/sessions/-Users-oleksandroliinyk-VSCODE-CodeAI-Hub-claude/claudeCodeCli/claude-28ba3917-ef0b-48e5-ae3e-642b16946da7-description.jsonl`

Диагностика показала: 47 строк в native, 94 в SDK log, только 7 в unified. Timeline: user message 15:30:17 → первый assistant text bubble в unified 15:35:27. **5 минут задержки.**

## 1.2. Что выяснилось при сопоставлении трёх файлов

- `15:33:28.6` — Claude прислал в SDK `text[165c]` "I'll read the questionnaire, create the first readable draft..." с messageId `ZWLZiHtoMJzx`.
- `15:35:27.1` — Claude прислал `tool_use:Write` на том же messageId.
- Между ними Claude стримил `input_json_delta` для body `Final_Description.md` (2284 символа).
- В unified session text появился ровно в 15:35:27 — в момент, когда роутер получил `message_delta.stop_reason="tool_use"` и вызвал `flushPendingAssistantText("tool_use_preamble")`.

То есть pending buffer в `claude-stream-event-router.ts` держал видимый text всё время стриминга tool_use аргументов. Этот pending path существовал для поддержки локального провайдерного перевода (`ClaudeThoughtTranslationAdapter.translateUserFacingText`) pre-tool assistant text, но у нас в этом turn'е semanticRole был `"thinking"` (messageId совпал с `thinkingMessageIdBySession`), перевод не делался — pending просто ждал впустую.

## 1.3. Ключевой ложный вывод сначала и почему он произошёл

Первое что я сказал пользователю: «в SDK log 0 `content_block_delta` событий, значит SDK их не шлёт, значит Phase 2.1 live thinking не работает». Это было **неверно**. Правда оказалась в `shouldSkipClaudeSDKMessageLog` в [claude-stream-event-router.ts](packages/Claude_Module/src/messaging/claude-stream-event-router.ts) — наш собственный diagnostic logger специально фильтрует `content_block_delta`, чтобы log не раздувался. Delta события до роутера **доходили** всегда. Следующая сессия должна помнить: **отсутствие `content_block_delta` в `sdk-claude-*.jsonl` — это by design, не сигнал о проблеме.**

## 1.4. Эмпирические probe-прогоны Claude Agent SDK

Запустил research без изменений в коде. Все артефакты — в `/tmp/claude-streaming-probe/` (ephemeral, /tmp может потерять их после перезагрузки):
- `probe.mjs` → `summary.json` — 6 конфигов (A-F) на opus-4-5/-sonnet-4-5/-haiku-4-5
- `probe2.mjs` → `summary2.json` — 3 конфига (G-I) на opus-4-7 (включая workflow-like с tool_use)
- `probe3.mjs` → `summary3.json` — 8 конфигов (J-Q), матрица effort × display на Opus 4.7 и 4.6
- `probe4.mjs` → `summary4.json` — 7 прогонов (R1-R7) с reasoning-heavy prompt для проверки high vs max + summarized

Главные количественные находки:

**a) Альтернативы SDK-опции `includePartialMessages`.**
Без флага — 0 `content_block_delta`. С флагом — 22-37 delta per turn. Наше приложение уже ставит в `true` ([claude-sdk-manager.ts:268](packages/Claude_Module/src/sdk/claude-sdk-manager.ts:268)) — менять не нужно.

**b) `text_delta` приходит всегда.** Все модели (Opus 4.5/4.6/4.7, Sonnet 4.5, Haiku 4.5), любые effort — выдают text_delta каждые ~300-500мс, 18-37 фрагментов на turn, первая дельта через 2-5 секунд от query. Это главный канал видимого прогресса для пользователя.

**c) `thinking_delta` на Opus 4.7 — ТОЛЬКО при `thinking.display: "summarized"`.**
Иначе Opus 4.7 отдаёт только `signature_delta` (encrypted opaque proof, 0 chars plain text). Это НОВОЕ поведение SDK `@anthropic-ai/claude-agent-sdk@0.2.111`. В старом `@anthropic-ai/claude-code@2.1.111` такой опции не было — plain-text thinking шёл по дефолту.

**d) Effort уровни в SDK.**
Union из типов: `'low' | 'medium' | 'high' | 'xhigh' | 'max'`. Из JSDoc: `'xhigh' — Deeper than high (Opus 4.7 only; falls back to 'high' elsewhere)`, `'max' — Maximum effort (select models only)`. Порядок: `low < medium < high < xhigh < max`. Это и был "High Max" о котором слышал пользователь. **`xhigh` НЕ выше `max`** — между `high` и `max`.

**e) High vs Max + summarized для Opus 4.7.**
Сначала я ошибочно заявил, что только `max` открывает thinking — результат на коротком prompt'e. На reasoning-heavy prompt'e (логическая задача с 3 ящиками) все 7 конфигов с `display:"summarized"` дали `thinking_delta` — 5-11 штук независимо от effort. То есть достаточно `high + summarized`. Разница между effort на Opus 4.7 — глубина reasoning, не видимость.

**f) Aliases и версии.**
`opus` резолвится в `claude-opus-4-7` (поле `resolvedModel` у assistant messages). В UI же был прописан хард-код `Opus 4.5`. Это расхождение — ошибка.

## 1.5. Архитектурные решения, принятые с учётом находок

**Решение 1 — live text_delta ingestion.** Аналогично Phase 2.1 для thinking, нужен буфер + handler для text. Это закрывает 2-минутную тишину для любой модели (thinking опаковый или нет — неважно). Новый файл `claude-text-live-buffer.ts` (flush threshold 96, сentence boundary) и расширение handler'а.

**Решение 2 — rename `ClaudeThinkingStreamHandler` → `ClaudeContentStreamHandler`.** Он стал владельцем и thinking, и text buffer'а. Также добавлен tracking `activeBlockKindBySession` — потому что `content_block_stop` не несёт type, и handler должен знать, какой buffer flush'ить. Компромисс — один active block в момент (Anthropic API не interleaving'ит разные блоки).

**Решение 3 — `thinking.display: "summarized"` как always-on при enabled thinking.** Безопасный default: для Sonnet/Haiku/old Opus поведение не меняется (plain-text thinking уже был); для Opus 4.7 открывается видимость. Отдельного UI toggle не добавляли — не стали плодить лишнюю ручку. Обсуждали как вариант (D в моей рекомендации), но пришли к `A+C` которые покрывают всё.

**Решение 4 — `xhigh` как 5-й уровень effort.** Добавлен в union, registry, descriptor, LEGACY token anchor (20000 между high 10000 и max 32000), UI label resolver `"x-High"`, i18n ключи в approved dicts (`ui_helper_text.json`: `xhigh_label`, `xhigh_description`).

**Решение 5 — дедупликация финального assembled text.** Симметрично thinking dedupe из Session 036. `handleAssistantMessageInternal` теперь прогоняет extracted text через `consumeFinalText`. Три случая: `hasMaterializedText=true` И полностью покрыто → skip (нет dual-emit); `hasMaterializedText=true` И tail/divergent → emit как live-bubble; `hasMaterializedText=false` → legacy pending flow (для non-live моделей/путей). `hasMaterializedText` читается **до** `consumeFinalText` потому что последний очищает buffer.

**Решение 6 — `pendingAssistantTextBySession` оставлен в коде.** Не удаляли полностью — он всё ещё нужен для legacy path когда live не сработал (например, если модель почему-то отдаст целый assistant message без delta fragments). Также для локального провайдерного перевода pre-tool non-thinking text.

**Решение 7 — убрать версии из displayName.** `Sonnet 4.5` → `Sonnet`, `Opus 4.5` → `Opus`, `Haiku 4.5` → `Haiku`. Description каждого alias пояснает auto-resolve. Label `Anthropic Claude · Haiku 4.5` в localization engine selector **оставлен** — это не alias, это engine id `anthropic-claude-haiku-4-5` (конкретная версия — часть identity).

**Решение 8 — architectural splits ради 500-line rule.** Выделены:
- `claude-text-live-buffer.ts` — 130 строк (новый)
- `claude-content-stream-handler.ts` — 158 строк (rename + расширение)
- `claude-structured-output-helpers.ts` — 102 строки (partitionVariantBArtifacts, appendQuestionsToSuggestedResponse, normalizeStructuredOutputMessage)
- `claude-stream-event-router.live-text.test.ts` — 276 строк (чтобы не раздувать основной test файл)

Router упал с 575 (pre-refactor ожидаемого размера) до 426.

## 1.6. Итоговая раскладка execution cycle

13 git commits, 6 phases:

**Phase 1 — Live text ingestion (3 commits):**
- `506d80ec3` feat: add claude text live buffer
- `5b1e307eb` feat: stream claude text deltas (rename handler + wire text path + new emitter helper)
- `4d3b8e9db` fix: dedupe finalized claude assistant text

**Phase 2 — Thinking display switch (1 commit):**
- `44293929c` fix: enable summarized thinking display for claude

**Phase 3 — xhigh effort end-to-end (2 commits):**
- `9b0e7f187` feat: accept xhigh claude reasoning effort (core union + registry)
- `67bc3e162` feat: surface xhigh effort in claude settings (UI label + i18n)

**Phase 4 — Drop version numbers (1 commit):**
- `7cdab45a9` chore: remove version numbers from claude model labels

**Phase 5 — SSOT sync (1 commit):**
- `e443c60b8` docs: sync claude live text and effort ssot (invariant 25 renamed/extended, new invariant 26)

**Phase 6 — Release build (2 commits + 2 closeout):**
- `160a8f823` docs: prepare claude live text release notes
- `30f989ebd` chore: build 1.1.998 release assets
- `8d15fd0e5` chore: finalize todo plan progress for 1.1.998 release
- `306c72e40` docs: archive claude live text execution scope

Intake коммит: `4d140b929 docs: open claude live text and thinking visibility execution scope`.

Все гейты (check-architecture.sh, ultracite, knip, typecheck webview, typecheck Claude_Module, lint) зелёные на каждом commit'е. 28/28 messaging тестов зелёные.

## 1.7. Процессные заметки (чтобы не повторять ошибки)

- **Пропускал обновление todo-plan.md в риалтайме** на Phase 1.1 и Phase 1.2 — пользователь одёрнул. После этого обновлял todo-plan одновременно с каждым commit'ом. Следующая сессия: обновлять **сразу после каждого коммита**, хеш вписывать, статус DONE/IN_PROGRESS правильно — это часть рабочего контракта.
- **Ultracite formatter несколько раз выбрасывал мои новые импорты** как unused (т.к. они добавлялись до использования). Лечение: добавлять импорт и сразу первое использование в одном edit, либо импортировать после первого использования.
- **Biome lint rule `noExportedImports`** не даёт делать `import X + export {X}` в одном файле — только `export {X} from "./path"`. Работал с этим в `claude-structured-output-helpers.ts`.
- **`git mv` + commit отдельно** — чисто для rename-only операций. Потом уже коммитить content changes.
- **`test.skip()`** — удобный инструмент для разделения Phase 1.2 и Phase 1.3 коммитов (кладёшь скелет тестов заранее, потом включаешь).

## 1.8. Что обсуждали, но НЕ сделали (открытые вопросы для будущего)

- **Опциональный toggle `Show thinking in dialog`** (`display: "summarized"` vs `"omitted"`) как отдельная ручка в Settings. Отложено — сейчас `summarized` всегда.
- **API `thinking: { type: "enabled", budgetTokens: N, display: "summarized" }`** как режим «принудительного» thinking с детерминированным token budget'ом. Сейчас всегда `adaptive` — модель сама решает, думать или нет, что объясняет flaky-результаты в probe'ах (5 vs 10 thinking_delta на одном конфиге).
- **Per-model effort capability discovery runtime.** `ModelInfo.supportedEffortLevels` в SDK types уже есть — в будущем можно подсвечивать в UI, какие effort уровни реально применимы к выбранной модели (например, `max` только для select models, `xhigh` только Opus).
- **Переписать JSON-wire контракт dialog messages** с полями `live: true/false` — добавил `metadata.live = true` в `emitClaudeAssistantLiveText`, но consumer это пока не использует. В будущем можно отличать live-fragments от финальных в UI.
- **Provider-local translation для live text.** Сейчас live text-сегменты эмитятся в source language, перевод идёт через Core-owned overlay (как для thinking). Это архитектурно чище, но ломает прежний `thoughtTranslator` path для pre-tool non-thinking text. Если потребуется — восстановить через translation-per-segment.

---

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `4d140b929 docs: open claude live text and thinking visibility execution scope`
- `506d80ec3 feat: add claude text live buffer`
- `5b1e307eb feat: stream claude text deltas`
- `4d3b8e9db fix: dedupe finalized claude assistant text`
- `44293929c fix: enable summarized thinking display for claude`
- `9b0e7f187 feat: accept xhigh claude reasoning effort`
- `67bc3e162 feat: surface xhigh effort in claude settings`
- `7cdab45a9 chore: remove version numbers from claude model labels`
- `e443c60b8 docs: sync claude live text and effort ssot`
- `160a8f823 docs: prepare claude live text release notes`
- `30f989ebd chore: build 1.1.998 release assets`
- `8d15fd0e5 chore: finalize todo plan progress for 1.1.998 release`
- `306c72e40 docs: archive claude live text execution scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` (важны новые invariants 25 и 26, см. §1.5).
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## 2.1. Состояние на конец сессии
- Активный execution scope **отсутствует** — Phase 1-6 закрыты, todo-plan и planning-doc архивированы.
- VSIX `codeai-hub-1.1.998.vsix` (2.2M, 1974 файла) лежит в корне проекта, ждёт retest'а.
- Tarballs для 1.1.998 в `doc/tmp/releases/`: `claude-module`, `codex-module`, `gemini-module`, `codeai-hub-core-darwin-arm64`, `project-manager`, `vscode-webview`, `CodeAIHubLauncher-macos-arm64`.
- Дерево чистое, всё закоммичено (`git log --oneline -1` → `306c72e40 docs: archive claude live text execution scope`).

## 2.2. Чек-лист retest v1.1.998 (что ждём)
1. **Live text.** Длинный Claude turn с `Write` большого файла (2000+ chars content). Текст «I'll read...» / «Сейчас сделаю...» должен начать печататься в диалоге в течение 1-2 секунд после старта assistant message, не ждать окончания tool_use. Прежней 2-минутной паузы быть не должно.
2. **Thinking на Opus 4.7.** `Settings → Claude → Thinking in dialog = on`, effort `high`. Turn с reasoning. Thinking bubbles должны появляться постепенно, пока Claude думает. Если не появляются — проверить прежде всего, действительно ли в запросе к SDK идёт `thinking.display: "summarized"` (можно добавить debug log в `buildQueryOptions` если нужно).
3. **x-High effort.** Settings → Claude → Reasoning effort — 5 радио: `low`, `medium`, `high`, **`x-High`**, `max`. Подпись у x-High: `"Deeper-than-high reasoning on Opus; falls back to high on other models"`. Выбор и save должны отработать, потом должен реально пойти `effort: "xhigh"` в SDK.
4. **Model labels.** Settings → Claude → Default model — карточки должны быть `Sonnet` / `Opus` / `Haiku` **без цифр**. Если видно `Opus 4.5` — значит UI не пересобрался полностью.
5. **Stop регрессия.** Проверить что `Stop` по-прежнему не роняет core (регрессия Session 036). Live text и Stop должны сосуществовать.
6. **Translation overlays.** Если включена локализация (например, русский на Haiku translation engine), live text bubbles должны локализовываться так же как thinking bubbles — через Core-owned overlay, per-bubble.

## 2.3. Если retest обнаружит проблемы
- **Live text не приходит, но в SDK реально идут text_delta.** Проверить: (a) `ClaudeContentStreamHandler.handleDelta` в [claude-content-stream-handler.ts](packages/Claude_Module/src/messaging/claude-content-stream-handler.ts); (b) `ClaudeTextLiveBuffer` flush threshold (96) — возможно, segments меньше и ждут `content_block_stop`. Можно временно снизить threshold до 40-50 для короткого диалога.
- **Text печатается, но потом дублируется финальным bubble.** Проверить `handleAssistantMessageInternal` в [claude-stream-event-router.ts](packages/Claude_Module/src/messaging/claude-stream-event-router.ts) — `hasMaterializedText` читается до `consumeFinalText`? Buffer очищается корректно?
- **Thinking на Opus 4.7 всё ещё опаковый.** Первое — grep `display.*summarized` в запросе в SDK (debug). Второе — проверить что `thinking.enabled=true` в settings.json.
- **xhigh в UI есть, но save не работает.** Проверить `CLAUDE_THINKING_EFFORTS` Set в [provider-defaults-resolver.ts](packages/core/src/config/provider-defaults-resolver.ts) — нормализатор должен пропускать `"xhigh"`.

## 2.4. Probe-инфраструктура (если нужно повторить SDK research)
- `/tmp/claude-streaming-probe/probe*.mjs` — 4 скрипта, покрывают включение флагов, thinking.display, effort matrix.
- Запуск: `cd /tmp/claude-streaming-probe && node probeN.mjs`. Использует глобально установленный `@anthropic-ai/claude-agent-sdk` из `~/.npm-global/lib/node_modules/@anthropic-ai/claude-agent-sdk/sdk.mjs` и provider-home `~/.codeai-hub/providers/claude/home` (auth OAuth токен уже лежит там).
- Результаты в `summary*.json` + `*.jsonl` timelines. `/tmp` эфемерный — может не сохраниться после перезагрузки. При необходимости переизобрести — см. структуру пробок в коммите `4d140b929` planning-doc §2.2.

## 2.5. Плохой путь для next session
- Не начинать fix без согласования scope. Если retest выявит проблему — сначала planning-doc в `Plans/`, потом todo-plan.
- Не забыть обновить displayName в `packages/ui/project-manager/dist/app.js` — это dist, он пересоберётся при build, но в момент retest пользователь может увидеть старое, если запустит без reload.
- **Не доверять `sdk-claude-*.jsonl` как полному снимку** — `content_block_delta` там отфильтрованы by design (см. §1.3). Для полной картины стрима — probe или добавить временный debug log.

## 2.6. Plans for next session (формальный блок)
- Активный execution scope отсутствует — Phase 1-6 закрыты, todo-plan архивирован.
- VSIX `codeai-hub-1.1.998.vsix` ожидает пользовательской установки и retest.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope (фидбэк по 1.1.998 retest или новая задача).
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
