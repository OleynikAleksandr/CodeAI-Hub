# Session 028 — Haiku Translation Runtime Hardening Release

**Date:** 2026-04-16 08:17 (CEST)
**Branch:** main
**Version:** 1.1.990
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Fixed the Haiku translation runtime so localization/help bundles and live reasoning use an explicit translate-only prompt instead of sending raw source text as a bare provider request.
- Restored the dedicated Haiku translation runtime path under `translation-runtime-haiku`, keeping native Claude JSONL persisted in the intended translation-only project bucket while reusing provider-home auth/bootstrap.
- Added in-flight dedupe for duplicate reasoning translation jobs keyed by `engineId + targetLanguage + sourceHash`, preventing live/replay duplicate requests from queueing twice behind the single-worker dispatcher.
- Synced SSOT and release docs, updated the bug registry entry for the Haiku translation regression, and built a new release package: `codeai-hub-1.1.990.vsix`.
- Verified with targeted builds/tests for `@codeai-hub/claude-module` and `@codeai-hub/core`, then completed `./scripts/build-all.sh` and `./scripts/build-release.sh --use-current-version`.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `7ec2d0a48 fix: harden haiku translation runtime`
- `8624a514c docs: prepare 1.1.990 release notes`
- `21dd161ef chore: build 1.1.990 release assets`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
