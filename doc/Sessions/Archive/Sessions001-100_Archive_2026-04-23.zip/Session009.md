# Session 009 — Codex Post-Release Translation Regression Hotfix

**Date:** 2026-04-13 19:55 (CEST)
**Branch:** main
**Version:** 1.1.977
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Opened and completed the post-release investigation for the Codex translation regression reported after switching `Localization -> Translation engine` to `OpenAI Codex · GPT-5.3 Codex Spark` in workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4`.
- Proved that the English final answer and English artifact were caused by a PM-side prompt-pack fallback bug, not by the thinking overlay path:
  - good run `a11f34d0-6fa9-4c0e-9150-43198b5bd237` / provider session `019d87ca-4d7c-7692-8a13-f62f6a608612` carried `Artifacts for the User = ru`;
  - bad run `12171ad8-19ef-443d-b7ab-97044bb9b9d7` / provider session `019d87cb-d308-75f2-b4e6-bad7f3e0e405` carried `Artifacts for the User = en`.
- Fixed the PM-side workflow prompt assembly so `Artifacts for the User` falls back to the persisted browser localization bootstrap snapshot instead of silently degrading to `en` when live settings cache is unavailable after reconnect/cold-start.
- Hardened the isolated Codex translation runtime bootstrap so translation-only Codex homes resolve auth/cache from provider home first and fall back to legacy `~/.codex` artifacts when needed.
- Fixed the Codex reasoning delta identity contract so streamed thinking chunks no longer reuse one provider item id across multiple visible delta messages; this preserves translation overlays across live, replay, and history paths instead of letting later translations overwrite earlier thinking fragments.
- Fixed a full-repo compile blocker in the PM bootstrap fallback typing path so the `1.1.977` release build can complete under the full `npm run compile` and release script gates.
- Synced the finalized behavior into SSOT:
  - `doc/SolidWorks-WorkFlow/Modules/Localization.md`
  - `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md`
  - `doc/SolidWorks-WorkFlow/Docs_Index.md`
- Archived the completed planning document into `doc/SolidWorks-WorkFlow/Plans/Archive.zip` and archived the completed local `todo-plan` into `doc/TODO/Archive.zip`.
- Verification completed:
  - `./node_modules/.bin/tsx --test packages/translation/src/codex-translation-runtime-home-facade.test.ts packages/Codex_Module/src/messaging/codex-stream-event-router.reasoning-ids.test.ts packages/Codex_Module/src/messaging/message-processor.test.ts src/client/project-manager/services/description-submit-service.localization.test.ts src/client/project-manager/services/workflow-step-start-service.gating.test.ts src/client/project-manager/services/prompt-pack-builder.virtual-simulation.test.ts`
  - `npm run build --workspace=@codeai-hub/translation`
  - `npm run build --workspace=@codeai-hub/codex-module`
  - `npm run build:project-manager`
  - `npm run compile`
  - `./scripts/build-all.sh`
  - `./scripts/build-release.sh --use-current-version`
- Release outputs produced successfully:
  - VSIX: `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub/codeai-hub-1.1.977.vsix`
  - tarballs: `doc/tmp/releases/*1.1.977.tar.bz2`

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `3dbd24528 docs: start codex post-release translation regression scope`
- `568b56a35 fix: preserve workflow artifact language after pm restart`
- `6a3d0afc8 fix: harden codex translation runtime bootstrap`
- `cc0add665 fix: preserve codex thinking translation chunks`
- `e51b7a7a3 docs: prepare 1.1.977 release notes`
- `337ec89fa build: prepare 1.1.977 release artifacts`
- `b5ec46ab2 fix: unblock release compile for localization fallback`
- `fb5c1ab26 docs(archive): close codex translation regression scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Active execution scope is closed.
- The next agent must first read `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` as the base SSOT.
- Then the next agent must align with the user on the next scope.
- After that the next agent must open `doc/SolidWorks-WorkFlow/Docs_Index.md`, choose the relevant documents for the new scope, and only then create a new planning document.
- Until a new planning document and a new active `doc/TODO/todo-plan.md` exist, `doc/SolidWorks-WorkFlow/Docs_Index.md` remains the navigation anchor.
