# Session 011 — Universal Chunked Translation Planning After Localization Diagnostics

**Date:** 2026-04-13 21:22 (CEST)
**Branch:** main
**Version:** 1.1.978
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Verified that the diagnostic release `1.1.978` fixed the original Codex thinking-translation issue for workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4`: thinking bubbles now translate quickly, fully, and fragment-by-fragment with `OpenAI Codex · GPT-5.3 Codex Spark`.
- Separated a different localization defect from the already-fixed thinking overlay path:
  - `Description Help`
  - `Virtual Simulation Help`
  - confirmation-card helper copy
  - Settings explanatory/helper text
  were partially English only when the selected localization engine was `codex-gpt-5.3-codex-spark`.
- Proved that the defect boundary is **not UI rendering**:
  - switching the localization engine to `Google GTX Free` and restarting Core rebuilt
    - `~/.codeai-hub/localization/catalogs/user_guidance/ru.json`
    - `~/.codeai-hub/localization/catalogs/system_feedback/ru.json`
    - `~/.codeai-hub/localization/cache/browser-runtime-bootstrap.json`
    and the same surfaces became Russian in the UI.
- Proved the current root cause for the mixed-language bundles:
  - translation default timeout is `3000ms`;
  - `LocalizationMaterializer` currently translates each source string as one monolithic request;
  - on `codex-gpt-5.3-codex-spark`, long strings such as
    - `pm.description.help.cluster_module_explanation`
    - `pm.virtual_simulation.help.intro`
    reproducibly fell back with `errorCode = "empty_translation"` at roughly `3016-3108ms`;
  - shorter strings such as
    - `settings.core_controls.description`
    - `pm.confirmation_card.selected_provider_override_hint`
    completed successfully in roughly `2169-2301ms`;
  - the same long strings translated successfully on `codex-gpt-5.3-codex-spark` when run again with a higher timeout budget.
- Confirmed with the user that the current fallback contract is correct and must stay unchanged:
  - if translation fails, persisting the original English text is preferable to creating a hole in the user-facing copy.
- Agreed the next scope direction with the user:
  - do **not** special-case only localization bundles;
  - introduce universal translation chunking for both live interactive translation and persistent localization materialization;
  - select chunk size empirically per engine/model with a conservative safety margin;
  - split only on safe text boundaries, not on raw character count.
- Created the new planning document for the next execution-planning session:
  - `doc/SolidWorks-WorkFlow/Plans/Universal_ChunkedTranslation_Architecture.md`

## Git commits
(REFERENCE ONLY: this session was analysis + planning only; no new git commits were created.)

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope по предыдущему диагностическому `todo-plan.md` считать аналитически завершённым; следующий шаг — не продолжать старый instrumentation scope, а оформить новый execution plan.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент должен открыть уже подготовленный planning-doc:
  - `doc/SolidWorks-WorkFlow/Plans/Universal_ChunkedTranslation_Architecture.md`
- Из этого planning-doc нужно нарезать новый `doc/TODO/todo-plan.md` для implementation scope.
- Ключевые технические выводы, которые нельзя потерять:
  - mixed-language help/settings surface при `codex-gpt-5.3-codex-spark` не является UI bug;
  - problem boundary = monolithic-string translation under fixed `3000ms` timeout;
  - `Google GTX Free` на том же surface и тех же keys materializes correct Russian bundles;
  - fallback-to-English сохраняется осознанно и не должен убираться;
  - следующий implementation scope должен строиться вокруг universal chunked translation, а не around caller-specific UI fixes.
