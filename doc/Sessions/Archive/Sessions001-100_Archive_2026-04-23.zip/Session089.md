# Session 89 — CEF macOS reportException: Swizzle Attempt (Release 1.2.51, retrospectively closed as failed)

**Date:** 2026-04-22 (retrospective closeout 15:13 CEST)
**Branch:** main
**Version:** 1.2.51
**Execution Scope Status:** COMPLETED (attempted fix, did not work — superseded by 1.2.52)

---

# 1. Work Done in This Session

## Work summary
- Открыт cycle `1.2.51` после того как user retest 1.2.50 (`NSSetUncaughtExceptionHandler` подход) подтвердил, что mitigation не сработал. Проанализирован crash stack: AppKit на `-[NSApplication finishLaunching]` переустанавливает свой uncaught-exception handler поверх нашего; `+[NSApplication _crashOnException:]` — private Apple path, который обходит стандартную uncaught-handler chain на macOS 26 regardless что зарегистрировано через `NSSetUncaughtExceptionHandler`.
- Pivot на уровень ниже: Objective-C method swizzle на `-[NSApplication reportException:]` через category `NSApplication (CodeAIHubReportExceptionSuppression)` в `app_main_mac.mm` с `+load` → `method_exchangeImplementations`. Objective-C runtime делает swap во время dyld image load — до `main()` и до любой AppKit / CEF инициализации. AppKit не может undo swap.
- Stream A: удалён dead 1.2.50 `NSSetUncaughtExceptionHandler` код целиком (`g_previous_uncaught_handler`, `CodeAIHubUncaughtExceptionHandler`, `InstallCodeAIHubUncaughtExceptionHandler`), добавлен `#include <objc/runtime.h>` и category swizzle. Matching filter тот же: `NSInvalidArgumentException` + reason содержит `unrecognized selector sent to instance` и `NSApplication` → log в stderr + return. Non-matching → forward в original IMP через swizzle trampoline.
- Stream B: SSOT sync — `SystemArchitecture.md` §3 Invariant 32 переписан под swizzle; `Launcher_CEF.md` subsection "Shutdown-crash mitigation" полностью переписан (trigger, root cause, почему 1.2.50 не сработал, 1.2.51 mechanism, границы применимости); `BugRegistry.md` `BUG-2026-04-22-01` current resolution block — про swizzle, 1.2.50 failed attempt сохранён как timeline entry.
- Stream C: release metadata — `README.md` Current Release → v1.2.51 с объяснением почему 1.2.50 не сработал; `CHANGELOG.md` секция `## [1.2.51]` с Fixed / Changed / Known deferred issue / Not touched / Docs subsections.
- Stream D: `./scripts/build-all.sh --version 1.2.51` + `./scripts/build-release.sh --use-current-version` — VSIX `codeai-hub-1.2.51.vsix` (2.3M) создан, tarballs в `doc/tmp/releases/`.
- Stream E: planning-doc `CEF_MacOS_ReportException_Swizzle_Architecture.md` перенесён в `Plans/Archive/`; todo-plan → `doc/TODO/Archive/todo-plan-phase1-cef-macos-reportexception-swizzle.md`; stub возобновлён; `Docs_Index.md` обновлён.

## User retest result — FAILED
- Пользователь протестировал 1.2.51. Клик по красной NSWindow close кнопке всё равно показывает "CodeAI Hub Project Manager quit unexpectedly" dialog. Swizzle один не помог.
- Наиболее вероятное объяснение (записано в 1.2.52 planning-doc): на macOS 26 exception apparently достигает `+[NSApplication _crashOnException:]` не только через `-reportException:`, либо Chromium 141 teardown callback шлёт её ещё раньше, мимо swizzle. Точное path'а не известно — нужен бы ещё один crash report с enabled symbolication, но детальный анализ отложен в пользу pivot на short-circuit approach.
- Decision: вместо очередной попытки catch exception в другом месте, pivot на prevention — не запускать buggy Chromium callback вообще (1.2.52 short-circuit в `CanClose`).

## Verification
- Husky pre-commit зелёный на каждом из 5 коммитов цикла.
- `./scripts/build-all.sh --version 1.2.51` exit 0; CEF launcher slinked с new swizzle code.
- `./scripts/build-release.sh --use-current-version` exit 0: SDK exclusions verified, VSIX runtime surface verified, package size 2.3M.
- User acceptance: **FAILED** — crash dialog всё равно появляется на красной close кнопке.

## Git commits
(REFERENCE ONLY: для исторической трассировки; swizzle retained в 1.2.52 как safety net, так что этот код всё ещё активен в репозитории.)
- `77149ac34 fix(launcher-mac): swizzle -[NSApplication reportException:] to suppress CEF/macOS 26 crash`
- `d5e0ed63d docs: sync 1.2.51 reportException swizzle mitigation`
- `67dddb223 docs: prepare 1.2.51 release metadata`
- `05e666801 chore: release 1.2.51`
- `7de975052 docs: archive 1.2.51 reportException swizzle scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активного execution scope нет (1.2.52 cycle закрыт отдельным Session090 report'ом).
- При обсуждении новых задач: `BUG-2026-04-22-01` в теперь FIXED state after 1.2.52 short-circuit. Proper root-cause fix (CEF/Chromium upgrade) остаётся deferred follow-up.

## Архивы этого цикла
- Planning: `doc/SolidWorks-WorkFlow/Plans/Archive/CEF_MacOS_ReportException_Swizzle_Architecture.md`
- TODO: `doc/TODO/Archive/todo-plan-phase1-cef-macos-reportexception-swizzle.md`
- Релизный артефакт: `codeai-hub-1.2.51.vsix` (repo root, superseded by 1.2.52).
