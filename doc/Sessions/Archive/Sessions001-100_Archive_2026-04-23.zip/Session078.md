# Session 78 — Auto-Fit Zoom Natural-Width Hotfix (1.2.41)

**Date:** 2026-04-21 13:05 CEST
**Branch:** main
**Version:** 1.2.41
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Пользователь подтвердил, что после установки VSIX `1.2.40` Development Tree sidebar показывает правильную структуру (кластеры содержат свои модули, 1 standalone module), но Artifacts panel auto-fit сломался: первый cluster `Workflow And Artifact Ui` растягивается на всю natural-max ширину, второй cluster (`Session Workspace Ui`) не виден даже при `Cmd+Ctrl+0 → 100%` и `Cmd+scroll → 25%`. Пользователь предоставил два скриншота (workspace `CodeAI-Hub claude`, Artifacts panel и 25% zoom view).
- Root cause диагностика: в `src/client/project-manager/components/diagram-editor/diagram-editor-facade.tsx` релиз `1.2.40` ввёл `width: "max-content"` + `minWidth: "100%"` на inner composition div, исходя из предположения, что `scrollWidth` на `width: 100%` grid возвращает только container width. Это неверно: `scrollWidth` на нормально-сайзнутом grid уже возвращает `max(clientWidth, rightmost-child.right)` — когда реальный min-content child'ов (`minWidth: 220` у ModuleCard, `minmax(240px, 1fr)` в productPartHeaderStyle) превышает grid track width, cells overflow'ятся, и scrollWidth получается overflow-inclusive. Intrinsic-sizing keyword был лишним и активно вредным: `max-content` разрешил prose (purpose text, long titles), `auto`-колонкам в header и `1fr` column tracks в `repeat(columns, 1fr)` раскатываться в unwrappable single lines. Natural width стала тысячами пикселей, auto-fit сваливался в floor `0.25` сразу, а при userZoom ≥ 0.25 composition всё равно шире viewport.
- Phase 1 — Natural-width restoration: `width: "max-content"` и `minWidth: "100%"` убраны из inner div `DiagramEditorFacade`. Source-level regression assertion в `diagram-editor-facade.test.tsx` инвертирован на `max-content === false`, чтобы keyword не вернулся молча. Комментарий в коде объясняет, почему intrinsic-sizing keyword вреден на этом уровне. `npm run typecheck:webview` + `npm run build:webview` зелёные, source-level regression тест проходит.
- Phase 1 — SSOT sync: `SystemArchitecture.md` §6.4 rephrased: auto-fit zoom contract больше не прописывает `width: max-content + min-width: 100%`; вместо этого явно запрещает intrinsic-sizing keyword на composition-container'е с объяснением, что prose и `1fr` column tracks развернутся в unwrappable single lines и раздуют natural width. В `BugRegistry.md` добавлена запись `BUG-2026-04-21-03` с forensics / root cause / fix / commits / guards.
- Phase 2 — Release 1.2.41: README.md + CHANGELOG.md обновлены до запуска build-all.sh. `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.41.vsix` (~2.28 MB), все 7 tarball'ов в `doc/tmp/releases/`.
- Cycle closeout: planning-doc и todo-plan заархивированы в `Plans/Archive/` и `TODO/Archive/todo-plan-phase2-autofit-naturalwidth-hotfix.md`, `Docs_Index.md` обновлён с entry про hotfix цикл, восстановлен пустой todo-plan stub.
- Два baseline-failing source-level тестов в `diagram-editor-facade.test.tsx` (`auto-fill` + product-part hierarchy parser) по-прежнему не тронуты — это не текущий scope. На pre-commit/pre-push гейты они не влияют.
- **User acceptance:** пользователь установил `codeai-hub-1.2.41.vsix` и подтвердил, что на workspace `CodeAI-Hub claude` Diagram Modules Artifacts panel теперь auto-fit'ится корректно: композиция помещается по горизонтали, cluster'ы видны целиком при разных ширинах окна. Пользователь отметил, что у него есть остаточное замечание по визуальной подстройке auto-fit, но текущий вариант его устраивает — это deferred follow-up, не блокер текущего релиза, и будет сформирован в отдельный scope по запросу. Релиз `1.2.41` отправлен на GitHub (`git push origin main`).

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `6f4f18e0d docs: open auto-fit natural-width hotfix scope`
- `745d05b16 fix: restore natural grid sizing for diagram auto-fit composition`
- `00c63f2ab docs: drop max-content from auto-fit contract and register hotfix bug`
- `24470996a docs: prepare release notes for auto-fit natural-width hotfix (1.2.41)`
- `ced7d68c5 build: release 1.2.41`
- `677431047 docs: archive auto-fit natural-width hotfix cycle (1.2.41)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего hotfix-цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase2-autofit-naturalwidth-hotfix.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/DiagramModules_AutoFitZoom_NaturalWidthHotfix_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
- Known baseline-дефект не текущего scope: `diagram-editor-facade.test.tsx` содержит два source-level failing test'а (`auto-fill` string assertion, product-part hierarchy parser test). На pre-commit/pre-push гейты не влияют (PM TSX тесты вне hooks). Кандидат на отдельный cleanup-scope.
