# Session 90 — CEF macOS CanClose Short-Circuit (Release 1.2.52)

**Date:** 2026-04-22 15:13 (CEST)
**Branch:** main
**Version:** 1.2.52
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- User retest на 1.2.51 подтвердил, что method swizzle на `-[NSApplication reportException:]` один не предотвращает crash dialog — на macOS 26 exception apparently достигает `+[NSApplication _crashOnException:]` не только через `-reportException:` (точное path неизвестно без deeper debugging). Две exception-pipeline mitigations подряд (1.2.50 + 1.2.51) не сработали.
- **Pivot** к принципиально другому подходу: **не ловить** exception в пост-фактум, а **не запускать** проблемный Chromium teardown callback вообще. User подсказал правильную идею: симулировать Cmd+Q при клике по красной кнопке — тогда красная кнопка пойдёт по тому же clean pathway, что и Cmd+Q / Dock Quit.
- Planning-doc `CEF_MacOS_CanClose_ShortCircuit_Architecture.md` (Status: Accepted) обосновал pivot и описал minimal-scope реализацию: изменить `LauncherWindowDelegate::CanClose` в `launcher_app.cc` на macOS branch — вместо `browser->GetHost()->TryCloseBrowser()` (entry в buggy Chromium async teardown) вызвать cross-platform helper `codeai::launcher::RequestNativeApplicationTermination()` → `[NSApp terminate:nil]` и вернуть `false`. Это направляет close event по тому же pathway что Cmd+Q.
- Stream A: declaration helper'а в `packages/cef-launcher/src/launcher_handler.h` (namespace `codeai::launcher`) + implementation в `packages/cef-launcher/src/platform/mac/launcher_handler_mac.mm` (`[NSApp terminate:nil]`) + `#if defined(__APPLE__)` branch в `packages/cef-launcher/src/launcher_app.cc` `LauncherWindowDelegate::CanClose`. Windows/Linux branch (`#else`) оставлен без изменений — existing `TryCloseBrowser` flow.
- Stream B: SSOT sync. `SystemArchitecture.md` §3 Invariant 32 переписан: 1.2.52 short-circuit как primary fix; обе failed-попытки (1.2.50 `NSSetUncaughtExceptionHandler`, 1.2.51 `reportException:` swizzle) explicitly помечены как failed; 1.2.51 swizzle retained как safety net. Канон-список обновлён под новые файлы. `Launcher_CEF.md` получил новую subsection "Shutdown-crash primary fix (1.2.52 — CanClose short-circuit)" перед 1.2.51 subsection, которая помечена как `[superseded as primary, retained as safety net]`. `BugRegistry.md` `BUG-2026-04-22-01` → Status **FIXED**; current resolution block переписан под short-circuit; 1.2.51 swizzle attempt сохранён как "Superseded attempts (kept for history)" timeline entry рядом с 1.2.50 entry.
- Stream C: release metadata. `README.md` Current Release → v1.2.52 с описанием "stop catching, prevent the buggy callback" pivot'а; 1.2.51 в previous (swizzle alone not sufficient; retained as safety net); 1.2.50 остаётся noted как failed. `CHANGELOG.md` секция `## [1.2.52]` с Fixed / Changed / Retained as safety net / Known deferred issue / Not touched / Docs subsections, документирующая exact file paths, helper name и preservation list.
- Stream D: release build — `./scripts/build-all.sh --version 1.2.52` + `./scripts/build-release.sh --use-current-version` — VSIX `codeai-hub-1.2.52.vsix` (2.3M) создан. Tarballs в `doc/tmp/releases/` и `~/.codeai-hub/releases/`: CodeAIHubLauncher-macos-arm64-1.2.52, codeai-hub-core-darwin-arm64-1.2.52, claude/codex/gemini-module-1.2.52, vscode-webview-1.2.52, project-manager-1.2.52.
- Stream E: planning-doc `CEF_MacOS_CanClose_ShortCircuit_Architecture.md` перенесён в `Plans/Archive/`; todo-plan → `doc/TODO/Archive/todo-plan-phase1-cef-macos-canclose-shortcircuit.md`; `doc/TODO/todo-plan.md` возобновлён к neutral no-active-scope stub; `Docs_Index.md` получил описание 1.2.52 short-circuit scope. Retroactive `doc/Sessions/Session089.md` написан для закрытия 1.2.51 cycle (который был выпущен без session report'а поскольку failed).

## Verification
- Husky pre-commit зелёный на каждом из 5 коммитов цикла.
- `./scripts/build-all.sh --version 1.2.52` exit 0; CEF launcher слинкован со short-circuit кодом + retained swizzle.
- `./scripts/build-release.sh --use-current-version` exit 0: Step 7 SDK exclusions verified, Step 7.5 local artefacts validated, Step 9.5 VSIX runtime surface verified, Step 10 package size 2.3M.
- Manual acceptance matrix — user retest на installed `codeai-hub-1.2.52.vsix`:
  - Cmd+V paste / SuperWhisper / Cmd+C/X/A / меню Edit / Cmd+Q / Dock Quit / dock reopen — всё работает как в 1.2.49-1.2.51 (без регрессий).
  - **Main criterion:** клик по красной NSWindow close кнопке **больше не** показывает "quit unexpectedly" dialog — launcher закрывается clean так же как по Cmd+Q.
  - **Если всё ещё есть crash dialog:** сигнал что CEF views framework внутри всё же запускает TryCloseBrowser() где-то ещё (например через menu/close shortcut), или что Chromium callback triggerится раньше чем `CanClose`. Тогда нужен CEF/Chromium upgrade — отдельный scope.

## Git commits
(REFERENCE ONLY: для исторической трассировки.)
- `9fbd2dfaf fix(launcher-mac): short-circuit CanClose to [NSApp terminate:] bypassing buggy Chromium teardown`
- `bb086b95a docs: sync 1.2.52 CanClose short-circuit contract`
- `94fc7aa67 docs: prepare 1.2.52 release metadata`
- `1c8982c6b chore: release 1.2.52`
- `c8a23ffa0 docs: archive 1.2.52 CanClose short-circuit scope`

## User feedback
- 2026-04-22: user retest 1.2.51 показал что swizzle не помог. Пользователь предложил ключевую идею — симулировать Cmd+Q при red close button click. Это и легло в основу 1.2.52 short-circuit fix. Альтернативно upgrade CEF — если short-circuit не сработает. Я согласовал план 1.2.52 (short-circuit + retained swizzle как safety net), пользователь подтвердил.
- **2026-04-22 (retest 1.2.52) — CONFIRMED FIXED:** пользователь протестировал `codeai-hub-1.2.52.vsix`. Клик по красной NSWindow close кнопке закрывает launcher clean, без "quit unexpectedly" dialog — ведёт себя так же как Cmd+Q. Регрессий нет. Релиз готов к публикации на GitHub.

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.

## User retest checklist for 1.2.52 (обязательно)
- Установить `codeai-hub-1.2.52.vsix`, открыть standalone Project Manager.
- **Без регрессий 1.2.49-1.2.51:** Cmd+V, SuperWhisper, Cmd+C/X/A, меню Edit, Cmd+Q, Dock Quit, dock reopen работают.
- **Main criterion:** клик по красной NSWindow close кнопке **больше не** вызывает "quit unexpectedly" dialog. Launcher закрывается так же clean как по Cmd+Q.
- **Если crash dialog всё ещё появляется:** сохранить crash report. Signal что нужен CEF/Chromium upgrade — отдельный большой scope (download/rebuild CEF binary, проверка API compat).

## Deferred follow-up (если 1.2.52 сработает — remains as planned maintenance)
- **CEF/Chromium upgrade:** root cause остаётся Chromium 141 ↔ macOS 26.3.1 incompat. Short-circuit 1.2.52 устраняет observable crash, но underlying bug остаётся. Upgrade до CEF/Chromium 142+/143+ с macOS 26 semantics — proper fix. Большой scope (download/rebuild CEF framework, API compat check, risk других регрессий). С 1.2.52 urgency низкая.

## Архивы текущего цикла
- Planning: `doc/SolidWorks-WorkFlow/Plans/Archive/CEF_MacOS_CanClose_ShortCircuit_Architecture.md`
- TODO: `doc/TODO/Archive/todo-plan-phase1-cef-macos-canclose-shortcircuit.md`
- Retrospective close 1.2.51: `doc/Sessions/Session089.md`
- Релизный артефакт: `codeai-hub-1.2.52.vsix` (repo root) + tarballs в `doc/tmp/releases/`.
