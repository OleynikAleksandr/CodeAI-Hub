# Session 094 — PM Translation Engine Selector Crash Fix Release 1.2.55

**Date:** 2026-04-22 18:37 (CEST)
**Branch:** main
**Version:** 1.2.55
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Opened a new stabilization cycle for the standalone Project Manager crash on macOS 26.x when interacting with `Settings -> Localization -> UI Translation Engine`, and recorded the issue as `BUG-2026-04-22-08`.
- Confirmed the crash boundary was the shared native HTML `<select>` inside `TranslationEngineSelector`, not Core-side settings persistence or localization save logic.
- Replaced the shared translation-engine control with a DOM-owned button/listbox selector, covering both `UI Translation Engine` and `Reasoning Translation Engine` without entering the Chromium/AppKit native popup path.
- Synchronized SSOT and bug-history documents (`BugRegistry.md`, `Modules/UI_Bundles.md`, `Modules/Launcher_CEF.md`), updated release-facing docs (`README.md`, `CHANGELOG.md`), then built and packaged release `1.2.55`.
- Archived the completed planning/doc execution artifacts (`PM_TranslationEngineSelector_CEF_Crash_Architecture.md`, `todo-plan-phase1-pm-translation-engine-selector-crash-fix.md`), updated `Docs_Index.md`, and restored the neutral placeholder `doc/TODO/todo-plan.md`.
- Release verification passed through both `./scripts/build-all.sh --version 1.2.55` and `./scripts/build-release.sh --use-current-version`, including `Step 7: Verifying SDK exclusions`, `Removing dev dependencies before packaging`, and the final `✅ Package created` for `codeai-hub-1.2.55.vsix`.

## Git commits
(REFERENCE ONLY: this list is preserved for historical tracing and regression investigation; the next session does not need to read every commit by default.)
- `b013477e5 docs: plan translation engine selector crash fix`
- `bbdbc2b1e fix(settings): replace native translation engine select`
- `b10512136 docs: sync translation engine selector crash contract`
- `fdad1c542 docs: prepare 1.2.55 release metadata`
- `d237ddf65 chore: release 1.2.55`
- `8707eb2a3 docs: archive 1.2.55 planning scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Active execution scope is absent.
- The next agent must first read `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` as the base SSOT.
- Then the agent must agree a new scope with the user.
- After that, the agent must open `doc/SolidWorks-WorkFlow/Docs_Index.md`, select the relevant documents for the new scope, and only then create a new planning doc if needed.
- Until a new planning doc and a new active `doc/TODO/todo-plan.md` appear, navigation is anchored by `doc/SolidWorks-WorkFlow/Docs_Index.md`.
