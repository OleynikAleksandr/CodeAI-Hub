# Session 80 — Codex PATH + Post-Rebind Usage Limits Hotfix (1.2.43)

**Date:** 2026-04-21 16:15 CEST
**Branch:** main
**Version:** 1.2.43
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Пользователь на user acceptance `1.2.42` сообщил два симптома: (a) Codex provider провайдер выдавал `System: Provider codexCli unavailable`, (b) usage_limits виджет пустой у Claude и Codex после Core restart, Gemini работает. Анализ `~/.codeai-hub/logs/core/core.log` и `~/.codeai-hub/logs/codex/sdk-codex-app-server-*.jsonl` показал:
  - первый Codex spawn при старте Core (13:37) прошёл успешно, session работала до 13:43:50;
  - после штатного `closeSession` при `sessions.size === 0` `process.stop` завершил child;
  - recovery scheduler каждые ~60s пытался re-spawn → `spawn_error: "spawn codex ENOENT"` → `write EPIPE` на init handshake;
  - `which codex` в shell находит `/Users/oleksandroliinyk/.npm-global/bin/codex`, но inherited PATH у VS Code extension host (на macOS GUI launcher) не содержит этой директории — первый spawn мог работать по luck'у env snapshot, последующие падали.
- Для limits research agent прошёлся по broadcast path Claude/Codex/Gemini. Root cause: PM emit'ит usage_limits refresh с `lifecycleTrigger: binding_ready` ровно один раз per logical session. После 1.2.39 materializer paper-binding с `providerSessionStatus: "ready"` попадает в dispatch до `adapter.resumeSession` handshake, первый refresh возвращает null или broadcast'ит до того, как UI listener готов. Gemini `GeminiSessionManager.startManagedSession` делает proactive refresh внутри — поэтому виджет работает только у него. После 1.2.42 stale-binding retry hydrate'ит session, но второго refresh'а не было — widget не догонял.
- Phase 1 — Codex PATH augmentation (`d26868644`): в `packages/Codex_AppServer_Module/src/app-server/process/codex-app-server-process.ts` добавлены `CODEX_PATH_CANDIDATES` и `buildAugmentedPath()`. Spawn env.PATH = inherited PATH + curated candidates без дубликатов. Inherited path остаётся primary lookup — не hardcode'им absolute binary путь. Windows-ветка отдельной candidates list (`%APPDATA%\npm`).
- Phase 2 — post-rebind refresh trigger (`d70c31761` + `ef9d6897e`): новый helper `triggerPostRebindUsageLimitsRefresh` вынесен в отдельный файл `packages/core/src/remote-bridge/handlers/session-request-handler-post-rebind-usage-limits.ts` (чтобы не превысить 500-строковый лимит на `session-request-handler-message-dispatch.ts`). В `retryAfterStaleBinding` после успеха `providerSend.dispatch` helper вызывается с `adapter, broadcaster, logger, providerId, providerSessionId, session, sessionId`. Best-effort: adapter без `refreshUsageLimits` — no-op; synchronous exception — warn-лог. Broadcast идёт через существующий `normalizeUsageLimitsStreamEvent` путь. Regression тесты — 4 контрактных случая (no-op path, single invocation, event filtering, error swallowing) — проходят.
- Phase 3 — SSOT + BugRegistry sync (`2f2be9afd`): `SystemArchitecture.md` §3 Invariant 1 расширен post-rebind usage_limits refresh requirement + Codex PATH augmentation note. `BugRegistry.md` — запись `BUG-2026-04-21-05`.
- Phase 4 — Release 1.2.43: README.md + CHANGELOG.md обновлены до build-all.sh. `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.43.vsix` (~2.29 MB), все 7 tarball'ов в `doc/tmp/releases/`.
- Cycle closeout: planning-doc и todo-plan заархивированы, `Docs_Index.md` обновлён с entry про hotfix цикл, восстановлен пустой todo-plan stub.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `f5c9b3371 docs: open codex PATH + post-rebind usage limits scope`
- `d26868644 fix: resolve codex binary via augmented PATH in app-server spawn`
- `d70c31761 feat: trigger usage limits refresh after stale-binding rebind`
- `ef9d6897e test: cover post-rebind usage limits refresh trigger`
- `2f2be9afd docs: record post-rebind usage limits + codex path invariants`
- `956ccc257 docs: prepare release notes for codex path and post-rebind usage limits (1.2.43)`
- `a5a598bef build: release 1.2.43`
- `82bbfa2eb docs: archive codex path + post-rebind usage limits cycle (1.2.43)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего hotfix-цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase4-codex-path-post-rebind-limits.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/Codex_PATH_And_PostRebind_UsageLimits_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- User acceptance для 1.2.43 ожидается: Codex провайдер больше не залипает в `unavailable` после закрытия первой сессии; usage_limits виджет у Claude/Codex подтягивает цифры после Core restart в reopened dialog на первом user message (через stale-binding rebind retry path).
- Известный baseline-дефект не текущего scope: два source-level failing тестов в `diagram-editor-facade.test.tsx` (`auto-fill` + product-part hierarchy parser) — на pre-commit/pre-push гейты не влияют, кандидат на отдельный cleanup-scope.
