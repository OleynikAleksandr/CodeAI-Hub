# Session 76 — Session Input Lock Runtime Materialization (1.2.39)

**Date:** 2026-04-21 11:32 CEST
**Branch:** main
**Version:** 1.2.39
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Пользователь сообщил, что в workspace `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub codex 5.4` после установки VSIX 1.2.38 две из трёх reopened workflow sessions (`virtual_simulation` / `diagram_modules`) заблокированы "Agents is working, please wait..." навсегда; Stop-кнопка не снимает блокировку. Session `description` (которая `lastActive`) работает нормально.
- Проведена forensics-диагностика: прочитаны `.codeai-hub/codeai-hub-codex-5-4/continuity/index.json`, per-stage chain.json, `workflow/state.json`, `~/.codeai-hub/logs/core/core.log`. Root cause выявлен как three-link chain: (1) Core на cold-start не создаёт runtime session-объекты для continuity entries не-lastActive stages, (2) PM `shouldSuppressIdleDialogRestoreRefresh` подавляет `createSession` restore когда snapshot не содержит runtime session для dialog (оптимизация из 1.2.18), (3) Session UI `createInitialSnapshot` стартует workflow session с `connectionState: "running"` и никогда не разблокируется без snapshot update для несуществующей runtime session. Симметричный симптом для Stop: `handleStop` возвращает `"Session not found"` без эмиссии `turn_state: "idle"`.
- Этот класс багов расширяет BUG-2026-02-22-01/02 (закрыты в релизах 1.1.645/1.1.646): предыдущие fixes работали, когда snapshot содержал runtime session с отсутствующим unlock reason; этот — когда runtime session вообще отсутствует в snapshot.
- Пользователь выбрал Core-side fix (vs PM-only patch) как архитектурно правильный — «один раз и без follow-up костылей».
- Phase 1 — Core Runtime Session Materialization: добавлены `SessionManager.registerSessionWithId` (externally-id-preserving) и `SessionProviderBindingService.registerRestoredBinding` (paper-binding без adapter call). Создан `session-continuity-materializer.ts` — walk'ает `ContinuityIndexEntry[]`, для каждой с полной связкой `latestSessionId + providerId + providerSessionId` и отсутствующей в SessionManager создаёт stub runtime session + paper-binding + `notifySessionCreated` hydration с `turnState: "idle"`, `continuityLockActive: false`, `bindingStatus: "ready"`. Интегрирован в `RemoteBridgeDialogCommandRouter.handleDialogList` через новые dependencies (`providerBindingService` экспонирован на `SessionRequestHandler` через `getProviderBindingService()` getter, `workspaceRuntime` прокинут из message-router). Idempotent на повторных `dialog:list`. Provider `thread/resume` остаётся ленивым — срабатывает через existing `resolveProviderSessionId` на первом user message.
- Phase 1 — Regression coverage: `session-continuity-materializer.test.ts` (4 теста: happy path stub creation, idempotency при повторных `dialog:list`, skip incomplete entries, stop preconditions assertion на `sessionManager.getSession` + `providerSessions.get`).
- Phase 1 — SSOT sync: обновлены `SessionInputLock_SSOT_StateMachine.md` §3.3 (new incremental stage для релиза 1.2.39), `SessionUI_Behavior.md` §4.4 (reopened dialog cold-start contract), `CoreOrchestrator.md` §3 (runtime session materialization bullet), `SystemArchitecture.md` §3 Invariant 1 (snapshot-first lock contract расширен требованием наличия runtime session для каждой continuity entry после первого dialog:list), `BugRegistry.md` (новая запись `BUG-2026-04-21-01`).
- Phase 2 — Release 1.2.39: README.md + CHANGELOG.md обновлены до запуска build-all.sh. `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version` отработали чисто — `codeai-hub-1.2.39.vsix` (~2.38 MB), tarball'ы в `doc/tmp/releases/`.
- Cycle closeout: planning-doc и todo-plan заархивированы, `Docs_Index.md` обновлён с entry про BUG-2026-04-21-01, восстановлен пустой todo-plan stub.
- PM-side код не тронут: fix целиком Core-side. Existing `snapshotSignalsIdleUnlocked` path в `session-stream.applyWorkspaceSnapshotToSnapshots` (релиз 1.1.646) автоматически снимает initial "running" когда snapshot впервые содержит runtime session с `turnState: idle`.
- User acceptance: пользователь установил `codeai-hub-1.2.39.vsix`, проверил reopened workflow dialogs (`virtual_simulation` и `diagram_modules`) в workspace `CodeAI-Hub codex 5.4` и подтвердил, что input больше не залипает в "Agents is working..." и Stop-кнопка работает корректно. Scope закрыт и отправлен на GitHub (`git push origin main`).

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `1a246f2b0 docs: start session input lock materialization scope`
- `6dafa1523 feat: add externally-id-preserving session registration to session manager`
- `1c917a5eb feat: register restored provider binding without adapter turn`
- `58ac6bb33 feat: materialize runtime sessions on dialog list`
- `7787c4a4c test: cover continuity materializer happy path and idempotency`
- `bda2f58cc test: cover stop path preconditions for materialized continuity session`
- `896f0075e docs: record runtime session materialization invariant`
- `5dd1ed1e5 docs: sync cluster map, system invariant and bug registry`
- `9df41657d docs: prepare runtime session materialization release notes (1.2.39)`
- `2cd865eb0 build: release 1.2.39`
- `751bca87f docs: archive session input lock materialization cycle (1.2.39)`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Планирующие артефакты текущего цикла заархивированы:
  - `doc/TODO/Archive/todo-plan-phase4-session-input-lock-materialization.md`
  - `doc/SolidWorks-WorkFlow/Plans/Archive/SessionInputLock_RuntimeMaterialization_Architecture.md`
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем согласовать с пользователем новый scope.
- После этого открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc в `doc/SolidWorks-WorkFlow/Plans/`.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
