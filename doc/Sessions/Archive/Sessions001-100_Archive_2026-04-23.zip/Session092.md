# Session 92 — PM Settings Ownership + Release 1.2.53

**Date:** 2026-04-22 17:16 (CEST)
**Branch:** main
**Version:** 1.2.53
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Закрыт planning tail отдельным коммитом и затем полностью реализован execution cycle `1.2.53 — Project Manager Settings Ownership + Extension Runtime De-Scope`.
- `Core` стал единственным backend owner для settings lifecycle: remote bridge теперь владеет `settings:load/save/reset/update-provider/versions/open-user-glossary-file` и связанными broadcasts `settings:loaded/saved/save-error/localization-sync-status/user-glossary-file`.
- `Project Manager` стал единственным живым Settings UI: добавлены PM transport/state hooks, reuse shared `SettingsView` в `mode="project-manager"`, detached route `?mode=detached-settings`, dedicated settings window opener и footer action `Open Settings`.
- `VS Code extension` де-скоуплен до distribution/install/bootstrap-components shell: activation больше не стартует и не attach-ит `Core Runtime`, убраны runtime keep-alive/provider auto-update хвосты, legacy settings webview заменён на compat notice `Settings moved to Project Manager`.
- SSOT синхронизирован под новые ownership boundaries: обновлены `SystemArchitecture.md`, `Project_Manager.md`, `UI_Bundles.md`, затем release metadata в `README.md` и `CHANGELOG.md` переведены на `1.2.53`.
- Релизный цикл завершён: `./scripts/build-all.sh --version 1.2.53` и `./scripts/build-release.sh --use-current-version` прошли успешно; создан `codeai-hub-1.2.53.vsix`, tarball-артефакты обновлены в `doc/tmp/releases/` и `~/.codeai-hub/releases/`.
- Execution scope архивирован по правилам проекта: planning-doc перенесён в `doc/SolidWorks-WorkFlow/Plans/Archive/ProjectManager_Settings_And_RuntimeOwnership_Architecture.md`, active todo-plan перенесён в `doc/TODO/Archive/todo-plan-phase4-pm-settings-ownership-and-runtime-descope.md`, а `doc/TODO/todo-plan.md` возвращён в neutral completed stub без активного scope.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `0737a8c9d docs: plan pm settings ownership migration`
- `74bdce8c7 feat(core): add settings write transport`
- `0fbbf4550 feat(core): own settings persistence and localization sync`
- `85597587e feat(core): add provider update transport`
- `ad071d720 feat(core): expose provider update actions through settings`
- `d2bc20d04 feat(core): add glossary open intent for settings`
- `d33e94984 feat(pm): wire settings write transport`
- `171bc25ae feat(pm): reuse shared settings view in project manager`
- `f0815290a feat(pm): add dedicated settings window`
- `93b6254ee feat(pm): add footer settings entrypoint`
- `92a47b232 chore(extension): remove core startup from vscode activation`
- `0bec661b6 chore(extension): retire settings webview surface`
- `bfed25eef docs: sync settings and runtime ownership contract`
- `c7b55ba3f docs: prepare 1.2.53 release metadata`
- `cb202f193 chore: release 1.2.53`
- `edac0ea35 docs: archive 1.2.53 settings ownership scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового активного `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.

## Release artefacts
- VSIX: `codeai-hub-1.2.53.vsix`
- Planning archive: `doc/SolidWorks-WorkFlow/Plans/Archive/ProjectManager_Settings_And_RuntimeOwnership_Architecture.md`
- TODO archive: `doc/TODO/Archive/todo-plan-phase4-pm-settings-ownership-and-runtime-descope.md`
