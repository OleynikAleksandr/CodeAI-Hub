# Session 42 — Gemini Real Resume + Stale-Seed + Install Layout (1.2.8) + 1.2.9 scope opened

**Date:** 2026-04-17 13:00 CEST
**Branch:** main
**Version:** 1.2.8 (released) + 1.2.9 (scope opened, implementation pending)
**Execution Scope Status:** ACTIVE

---

# 1. Work Done in This Session

## 1.1. 1.2.7 retest → 1.2.8 scope discovery

Пользователь протестировал 1.2.7 на Gemini Stop → Continue и обнаружил:
- **`argv.resume` — no-op.** Прокинули флаг в compat `loadCliConfig`, но никто его не читает. Настоящий `gemini` CLI main binary делает resume-pipeline в три шага: `SessionSelector.resolveSession(uuid)` → `config.setSessionId(...)` → `client.resumeChat(convertSessionToClientHistory(messages), resumedSessionData)`. Без шага 3 `ChatRecordingService.initialize` не берёт resume-ветку и создаёт новый пустой chat-файл. На диске видели два файла с одним UUID (`09-01-443db15b` + `09-08-443db15b`).
- **PM stale-seed chaos.** PM.dialog.bootstrap.resolved создал НОВУЮ Core session `6a6da7bf`, seeded с providerSessionId `443db15b` + status `ready`. User send на эту session обошёл `hasStopInvalidatedBinding` и попал в `Gemini session <id> not found. Available: []` → красная рамка SwitchRecoveryBanner.
- **Legacy SwitchRecoveryBanner UI** — пре-1.2.5 toolbar, пользователь попросил удалить полностью.
- **Installer layout chaos** — `providers/bin/gemini` + `providers/lib/node_modules/@google/gemini-cli*` (685MB) лежали на верхнем уровне рядом с `claude/`, `codex/`, `gemini/`.

## 1.2. 1.2.8 implementation + release

8 streams, 14 коммитов, clean-slate build после user wipe'а `~/.codeai-hub/`:

### 1.2.8 Release prep
- `960fc03f6 docs: prepare 1.2.8 release notes for Gemini real resume + stale-seed guard`

### Stream 2 — Real resume wiring (`gemini-session-bootstrapper.ts` + `cli-types.ts` + `cli-bridge-module-loader.ts`)
- `94903dfd0 feat(gemini): expose convertSessionToClientHistory via cli-bridge module loader`
- `4c148c69f fix(gemini): wire real resume via client.resumeChat in bootstrapper`

### Stream 3 — Tests
- `7500864c9 test: verify real resume pipeline invokes client.resumeChat with hydrated history`
- `641f11ebf chore(gemini-tests): annotate convertSessionToClientHistory mock parameter for strict build`

### Stream 4 — Stale-seed guard (`gemini-session-stale-binding-error.ts` + `SessionRequestHandlerMessageDispatch`)
- `5dd879c69 feat(gemini): throw SessionStaleBindingError on stale provider session`
- `2ba939b5c fix(core): auto-recover from provider stale-seed binding with one-shot rebind retry`

### Stream 5 — SwitchRecoveryBanner полное удаление (3 delete + 4 edit)
- `56438bbfa chore: remove legacy SwitchRecoveryBanner and dialog-switch-offer hook`

### Stream 6 — Nested install layout (`provider-installer-paths.ts`)
- `9f4283f61 fix(core): nest Gemini CLI install under providers/gemini/cli`

### Stream 7 — SSOT promotion + archive
- `e37a724b6 docs: promote Gemini real resume + stale-seed guard + install layout contract`
- `d8a9138ba docs: archive 1.2.8 Gemini real resume planning doc`
- `295b62875 docs: mark 1.2.8 streams 1-7 DONE in todo-plan; ready for user wipe + build`

### Stream 8 — Release build
- `432356dec chore: bump version to 1.2.8 for Gemini real resume + stale-seed guard + install layout release`
- `970bf6a26 docs: close 1.2.8 todo-plan after Gemini real resume + stale-seed + install layout build`

## 1.3. 1.2.8 retest — Stop/Resume VERIFIED

Пользователь протестировал 1.2.8 на Gemini Stop → Continue. Артефакты подтверждают:
- **ОДИН chat-файл** `~/.gemini/tmp/codeai-hub-gemini/chats/session-2026-04-17T10-34-17c70192.json` (156KB, 10 messages). Был 2 в 1.2.7 retest.
- **ОДИН SDK log непрерывный** `sdk-gemini-17c70192-...jsonl` (31KB). Раньше рестартовал.
- Core.log явно показал `[gemini] Gemini resume hydration complete` (новый log из моего `hydrateResumedChat`).
- Msg #6 после "Продолжай" (10:38:25) — `Я обновил Final_Description.md, уточнив архитектурную иерархию и техническую роль компонентов` — полностью continues prior architectural discussion.
- Core sessionId swap `9a85c7cc → 9514e987` с сохранением providerSessionId `17c70192` — это 1.2.5 adoption работает корректно, всё в один chat-файл.
- Stale-seed path не сработал (PM не создавал фантомную session); stream 4 остался как safety net на будущее.

**Вердикт:** Stop/Resume трилогия (Claude 1.2.5 + Codex 1.2.6 + Gemini 1.2.7/1.2.8) закрыта полностью.

## 1.4. 1.2.8 retest — Bug A + Bug B discovered

Пользователь продолжил retest дальше (работу над `Final_Description.md`) и обнаружил две дополнительные проблемы с Gemini assistant output:

### Bug A — inline `[Thought: true]` marker в post-tool follow-up

В msg #12 (2026-04-17T10:49:44) после `write_file` tool_call Gemini SDK в follow-up turn стримит в ОДНОМ `content`-потоке:
```
**
Finalizing the Description Step** I've incorporated the last round of user feedback into
`Final_Description.md`. This includes details about the Core Daemon's HTTP protocol, client-based startup,
and how the project hierarchy is formalized in later steps. I've concluded the current step, as the document now serves as a solid
foundation for what's to come.
[Thought: true]Я завершил подготовку `Final_Description.md`.
В документе зафиксированы все ключевые архитектурные решения...
```

В SDK log этого turn'а (events 1776422983751 → 1776422984823) — **ни одного `ptype=thought` event'а**, только `content` events. Gemini SDK запихнула "thought-like" summary + литеральный разделитель `[Thought: true]` + финальный русский ответ в один поток. Наш `gemini-assistant-event-normalizer.ts:handleFinishedEvent` конкатенирует все content chunks и эмитит одним assistant bubble. User видит в dialog'е гибрид английского thought-summary + token + русский финал.

### Bug B — English pre-tool progress text без перевода

Msg #1 (2026-04-17T10:34:45.816Z) — первый ответ Gemini после system-инструкции:
```
I will read the questionnaire and the template to understand the product idea and the required document structure.
```

Это pre-tool status text — сам turn заканчивается `tool_call_request` (read_file → write_file → Final_Description.md). SDK эмитит английский текст как `content` events без сопровождающих `thought` events. Наш роутер показывает пользователю английский текст посреди русского диалога.

User дополнение: "это, как правило, первый или второй ответ после получения запроса инструкции от ядра. В середине я такого не видел." — то есть на старте сессии, не в середине.

## 1.5. 1.2.9 scope opened

- Planning-doc создан: `doc/SolidWorks-WorkFlow/Plans/Gemini_InlineThoughtSplit_And_PreToolEnglishText_1.2.9.md`
- Todo-plan установлен: `doc/TODO/todo-plan.md` с 6 streams (README/CHANGELOG prep → Bug A splitter → Bug B heuristic → tests A+B → SSOT docs + archive → release build).
- Коммит scope-opener: `559f17e2c docs: open 1.2.9 scope for Gemini inline-thought split + pre-tool text heuristic`.

**Согласованное решение:**
- **Bug A:** regex-splitter `/\[Thought:\s*(true|false)\]/` в `gemini-assistant-event-normalizer.ts:handleFinishedEvent`. Pre-marker → thinking bubble через существующий `thoughtTranslator`. Post-marker → обычный assistant.
- **Bug B:** эвристика по Cyrillic ranges. Snapshot pre-tool assistant text в `TurnAccumulator.preToolAssistantSegment` (устанавливается на первом `tool_call_request` в turn'е). Если target language в Cyrillic-family (`ru/uk/bg/sr/mk/be/ky/kk/mn/tg/ab`) И pre-tool text не содержит ни одного `U+0400..U+052F` char → route через thoughtTranslator как thinking. Target=en отключает heuristic (нельзя надёжно детектить "не-english").

## Git commits (этой сессии)

(ВАЖНО: при `Execution Scope Status: ACTIVE` следующая сессия обязана просмотреть каждый коммит через `git show --stat <hash>` и `git show <hash>` ТОЛЬКО для последнего scope-opener'а 559f17e2c, плюс исторический contextual 1.2.8 список для reference; 1.2.8 коммиты можно не перечитывать детально — они уже в рантайме.)

### 1.2.8 cycle (released, см. также Session041.md для предыстории)
- `960fc03f6 docs: prepare 1.2.8 release notes`
- `94903dfd0 feat(gemini): expose convertSessionToClientHistory`
- `4c148c69f fix(gemini): wire real resume via client.resumeChat`
- `7500864c9 test: verify real resume pipeline invokes client.resumeChat`
- `641f11ebf chore(gemini-tests): annotate convertSessionToClientHistory mock`
- `5dd879c69 feat(gemini): throw SessionStaleBindingError`
- `2ba939b5c fix(core): auto-recover from provider stale-seed binding`
- `56438bbfa chore: remove legacy SwitchRecoveryBanner`
- `9f4283f61 fix(core): nest Gemini CLI install under providers/gemini/cli`
- `e37a724b6 docs: promote Gemini real resume + stale-seed guard + install layout contract`
- `d8a9138ba docs: archive 1.2.8 Gemini real resume planning doc`
- `295b62875 docs: mark 1.2.8 streams 1-7 DONE in todo-plan`
- `432356dec chore: bump version to 1.2.8`
- `970bf6a26 docs: close 1.2.8 todo-plan after build`

### 1.2.9 scope opened (pending implementation)
- `559f17e2c docs: open 1.2.9 scope for Gemini inline-thought split + pre-tool text heuristic` ← **ОБЯЗАТЕЛЬНО прочитать `git show 559f17e2c` в начале следующей сессии.**

Все гейты на каждом commit'е зелёные. 4/4 stop-resume тестов PASS.

## Artifacts

- VSIX `codeai-hub-1.2.8.vsix` (2.3M) в корне репозитория (released, retest passed).
- Tarballs 1.2.8 в `doc/tmp/releases/` и `~/.codeai-hub/releases/`.
- `doc/TODO/Archive/todo-plan-1.2.8-gemini-real-resume-and-pm-stale-seed-guard.md` (1.2.8 closed).
- `doc/SolidWorks-WorkFlow/Plans/Archive/Gemini_Real_Resume_And_PM_StaleSeed_Guard_1.2.8.md` (1.2.8 closed).
- `doc/SolidWorks-WorkFlow/Plans/Gemini_InlineThoughtSplit_And_PreToolEnglishText_1.2.9.md` (1.2.9 opened).
- `doc/TODO/todo-plan.md` (1.2.9 active).

## Retest evidence for 1.2.8 (для contextual reference в 1.2.9)

- Native chat: `~/.gemini/tmp/codeai-hub-gemini/chats/session-2026-04-17T10-34-17c70192.json` — 13 messages total по состоянию на ~12:50 CEST.
- SDK log: `~/.codeai-hub/logs/gemini/sdk-gemini-17c70192-7cd3-4a82-b805-adb276822d18.jsonl` — 31 events (last-turn slice).
- Our transcript: `~/.codeai-hub/sessions/-Users-oleksandroliinyk-VSCODE-CodeAI-Hub-gemini/geminiCli/gemini-9a85c7cc-...-description.jsonl` + `.translations.jsonl`.
- Bug A фрагмент: msg #12 content starts `**\nFinalizing the Description Step** I've incorporated...` ends `[Thought: true]Я завершил подготовку...`.
- Bug B фрагмент: msg #1 content `I will read the questionnaire and the template to understand the product idea and the required document structure.`

---

# 2. Instructions for Next Session

**Recovery Owner:** `doc/TODO/todo-plan.md`

## Plans for next session

- Продолжать активный execution scope 1.2.9 по `doc/TODO/todo-plan.md`.
- Список документов для восстановления контекста — **только** `doc/TODO/todo-plan.md` (Context Pack For This Cycle).
- Первый шаг следующей сессии: `git show 559f17e2c` чтобы увидеть планирующий документ и todo-plan одним коммитом.
- Далее идти по 6 streams по порядку: README/CHANGELOG prep → Bug A splitter → Bug B heuristic → tests A+B → SSOT docs + archive → release build (user может снова сделать wipe `~/.codeai-hub/` если захочет clean-slate, но для 1.2.9 это не обязательно — layout не меняется).

## Процессные заметки

- **Two-bug cycle после clean release.** 1.2.8 закрыл Stop/Resume триаду полностью, но Gemini assistant output имеет отдельный класс багов (provider-side quirks в том как SDK эмитит content/thought boundaries). 1.2.9 — первый релиз в этой новой "Gemini assistant output hygiene" теме.
- **Formatter strips unused imports aggressively.** Ultracite stripped imports between Edit steps в `gemini-provider-adapter.ts` и `index.ts` при работе 1.2.8. Правильный паттерн: import + usage в ОДНОМ Edit'е. Для 1.2.9 Bug A splitter usage helper и его вызов надо добавить одним эдитом.
- **Core не зависит от gemini-module.** При работе Bug A splitter внутри `gemini-assistant-event-normalizer.ts` это не актуально — всё в одном модуле. Но если Bug B потребует сигнал из Core (например прокидки language из settings) — реф на 1.2.8 pattern `GEMINI_SESSION_STALE_BINDING_ERROR_CODE` (duck-typing на error.code через shared constant, не instanceof).
- **`thoughtTranslator` уже поддерживает Cyrillic/non-English target.** В Gemini retest msg #11 его thoughts (English) переводились на русский через overlay. Reuse того же пути для Bug A pre-marker и Bug B pre-tool text.
- **Release без clean wipe.** 1.2.9 не меняет installer layout, в отличие от 1.2.8. User'у не нужно чистить `~/.codeai-hub/`. Но перед build check tarballs 1.2.8 всё ещё в `doc/tmp/releases/` (их build-all.sh перезапишет).
