# Session 093 — PM Settings In-Shell Stabilization Release 1.2.54

**Date:** 2026-04-22 18:14 (CEST)
**Branch:** main
**Version:** 1.2.54
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Opened a new stabilization cycle for the `1.2.53` post-release regressions around Settings: detached popup lifecycle, missing `Restart Core`, and false localization overlay on provider-only saves.
- Replaced the detached PM Settings window with an in-shell right-panel takeover, restored shared `Core Controls` / `Restart Core`, and added the standalone launcher restart bridge (`codeai://core-restart` + `RestartCoreProcess()`).
- Exposed real `settings:localization-sync-status` to the shared settings state and gated the `Synchronizing localization` overlay by actual sync busy-state instead of generic save-state.
- Synchronized SSOT and bug-history documents (`SystemArchitecture.md`, `Project_Manager.md`, `UI_Bundles.md`, `Launcher_CEF.md`, `BugRegistry.md`), updated release-facing docs (`README.md`, `CHANGELOG.md`), then built and packaged release `1.2.54`.
- Archived the completed planning/doc execution artifacts (`PM_Settings_InShell_Stabilization_Architecture.md`, `todo-plan-phase2-pm-settings-in-shell-stabilization.md`), updated `Docs_Index.md`, and restored the neutral placeholder `doc/TODO/todo-plan.md`.
- Release verification passed through both `./scripts/build-all.sh --version 1.2.54` and `./scripts/build-release.sh --use-current-version`, including `Step 7: Verifying SDK exclusions`, `Removing dev dependencies before packaging`, and the final `✅ Package created` for `codeai-hub-1.2.54.vsix`.

## Git commits
(REFERENCE ONLY: this list is preserved for historical tracing and regression investigation; the next session does not need to read every commit by default.)
- `33c12f370 docs: plan pm settings stabilization`
- `cc98d7713 feat(pm): host settings inside main area`
- `179eaaf2e chore(pm): remove detached settings window`
- `a05fa9c61 feat(pm): add core restart transport`
- `123125555 fix(pm): restore restart core in settings`
- `8f69ae002 feat(launcher): add core restart primitive`
- `f15310b91 feat(launcher): wire restart bridge`
- `b413fd7f1 feat(settings): expose localization sync status`
- `75135ca08 fix(settings): gate localization overlay by sync status`
- `69e1dab92 docs: sync pm settings stabilization contract`
- `689938320 docs: close pm settings stabilization bugs`
- `fd6c689d2 docs: prepare 1.2.54 release metadata`
- `ad06f74e3 chore: release 1.2.54`
- `50d53e45e docs: finalize 1.2.54 todo-plan`
- `c20711439 docs: archive 1.2.54 planning scope`
- `08c5a0a49 docs: close 1.2.54 todo-plan after build`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Active execution scope is absent.
- The next agent must first read `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` as the base SSOT.
- Then the agent must agree a new scope with the user.
- After that, the agent must open `doc/SolidWorks-WorkFlow/Docs_Index.md`, select the relevant documents for the new scope, and only then create a new planning doc if needed.
- Until a new planning doc and a new active `doc/TODO/todo-plan.md` appear, navigation is anchored by `doc/SolidWorks-WorkFlow/Docs_Index.md`.
