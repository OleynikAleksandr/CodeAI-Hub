# Session 34 — Project Manager Stop Button Release 1.1.996

**Date:** 2026-04-16 16:08 CEST
**Branch:** main
**Version:** 1.1.996
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Устранён баг `Project Manager`, при котором shared-кнопка `Stop` справа от поля ввода не работала в подвешенном состоянии continuity rollover, потому что отправляла `session:stop` в bridge обычного UI вместо transport `Project Manager`.
- Добавлен regression test для `core-bridge stopSession`, который фиксирует делегирование stop-команды в `Project Manager` среде и защищает shared input-panel от повторного расхождения transport bootstrap paths.
- Подготовлены release notes для `1.1.996`, выполнены `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version`, собран VSIX `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub/codeai-hub-1.1.996.vsix`, свежие tarball-артефакты обновлены в `doc/tmp/releases/` и `~/.codeai-hub/releases/`.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `a0944b29b fix: route project manager stop through pm transport`
- `8c1630def docs: prepare 1.1.996 release notes`
- `8e104af80 chore: build 1.1.996 release assets`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
