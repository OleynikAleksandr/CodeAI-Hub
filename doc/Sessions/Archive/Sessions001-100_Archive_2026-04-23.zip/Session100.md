# Session 100 — Canonical Settings Path Fix Release 1.2.61

**Date:** 2026-04-23 18:28 (CEST)
**Branch:** main
**Version:** 1.2.61
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Убрали live runtime fallback/write-path через `~/.codeai-hub/settings/claude.json` и зафиксировали единый canonical settings path: `~/.codeai-hub/settings/settings.json`.
- Core теперь материализует свежий normalized `settings.json`, если canonical файл отсутствует; extension-side settings storage больше не читает и не пишет `claude.json`.
- Обновили SSOT и contract docs под hard cutover away from `claude.json`, затем архивировали planning-doc и active todo-plan этого execution cycle.
- Подготовили release docs для `1.2.61`, прогнали `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version`, собрали `codeai-hub-1.2.61.vsix` и обновили release tarballs.
- Локально верифицировали fix таргетной сборкой Core, общим TypeScript type-check и smoke-проверками materialization path для Core/extension settings storage.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `14fc03392 fix(settings): canonicalize core settings path`
- `cd14e98ee fix(settings): remove legacy settings fallback`
- `5b1313e73 docs(plan): capture settings canonical path scope`
- `cea4aa8ae docs(settings): define canonical settings path invariant`
- `1eba7d108 docs: prepare README/CHANGELOG for 1.2.61`
- `68136b575 chore: release 1.2.61`
- `8dc8ed247 docs: archive settings canonical path release scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
