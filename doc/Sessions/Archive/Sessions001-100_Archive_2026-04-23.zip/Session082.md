# Session 82 — Daily Summary: Releases 1.2.40 → 1.2.44

**Date:** 2026-04-21 (полный день работы)
**Branch:** main
**Version:** 1.2.44 (собран, не протестирован)
**Execution Scope Status:** COMPLETED (все 5 циклов закрыты; user acceptance запланирован на следующую сессию)

---

# 1. Work Done in This Session

## Обзор — пять последовательных циклов + audit cleanup за день

Сегодня было закрыто 5 релизов: `1.2.40`, `1.2.41`, `1.2.42`, `1.2.43`, `1.2.44`. Дополнительно — один audit-cleanup без отдельного planning-doc'а. Каждый цикл имеет собственный Session файл (`Session077` → `Session081`), этот файл — meta-отчёт для быстрого восстановления контекста в следующей сессии.

**Хронология:**
1. `1.2.40` — DevTree parser stability + Artifacts auto-fit zoom ([Session077](./Session077.md)).
2. `1.2.41` — Auto-fit natural-width hotfix ([Session078](./Session078.md)).
3. Audit cleanup `doc/SolidWorks-WorkFlow/` (один коммит, без цикла).
4. `1.2.42` — Provider stale-binding auto-recovery (Claude + Codex, симметрично Gemini 1.2.8) ([Session079](./Session079.md)).
5. `1.2.43` — Codex PATH augmentation + post-rebind usage limits refresh ([Session080](./Session080.md)).
6. `1.2.44` — Single-probe usage limits warmup ([Session081](./Session081.md)).

---

## 1.2.40 — Development Tree parser stability + Artifacts auto-fit zoom

**Сценарий пользователя:** workspace `CodeAI-Hub claude`, stage `diagram_modules`. Development Tree в sidebar нестабильно перещёлкивал структуру при expand/collapse кластеров — 4 кластерных модуля ложно появлялись как standalone, после нескольких манипуляций возвращались на место. Плюс Artifacts panel при уменьшении ширины окна не масштабировался, cluster'ы уходили за правую границу.

**Root cause 1 (sidebar):** `packages/core/src/remote-bridge/handlers/development-tree-snapshot.ts` — module-level `NEXT_SECTION_RE = /^##\s+/gm` использовался через прямой `.exec(body.slice(1))` в `clampSectionBody`. Global regex singleton сохранял `lastIndex` между вызовами в long-lived Core процессе, чередуя hit/null. Когда exec возвращал null — `clampSectionBody` отдавал body целиком, и строки `## Simple Relations` попадали в standalone-scan. Плюс `MODULE_ROW_RE` был nonstrict (non-greedy `(.+?)` на 4-колоночные rows), первая колонка ловилась как module id.

**Root cause 2 (auto-fit):** `DiagramEditorFacade` применял `transform: scale(${zoom})` только через Cmd/Ctrl+scroll, auto-fit к container width отсутствовал.

**Fix 1.2.40 ([commits 4f43fd76d → 9adac5139](.)):**
- `development-tree-snapshot.ts`: все `/g`-regex через `.matchAll()` / factory-функции, `clampSectionBody` через `.search()` на non-global `NEXT_SECTION_SEARCH_RE`, `MODULE_ROW_RE` ужесточён до строго 2-column (`[^|\n]+` + `\|[ \t]*$` якорь).
- `DiagramEditorFacade`: `ResizeObserver` + `autoFitScale = min(1, containerWidth / naturalWidth)`, `effectiveZoom = autoFitScale × userZoom`, `Cmd+0` сбрасывает только user-overlay.
- `SystemArchitecture.md` §6.4 — два новых invariant'а, `BugRegistry.md` `BUG-2026-04-21-02`.

## 1.2.41 — Auto-fit natural-width hotfix

**Сценарий:** после установки 1.2.40 composition на Artifacts panel уходила за правую границу ДАЖЕ при `Cmd+Ctrl+0` и `Cmd+scroll → 25%`.

**Root cause:** в 1.2.40 на inner div я выставил `width: "max-content"` + `minWidth: "100%"` — это разрешило prose (purpose text, long titles) и `1fr` column tracks раскатываться в unwrappable single lines. Natural width раздулась до тысяч пикселей, auto-fit сваливался в floor `0.25`.

**Insight:** `scrollWidth` на нормально-сайзнутом grid **уже** возвращает `max(clientWidth, rightmost-child.right)` — intrinsic keyword не нужен.

**Fix 1.2.41 ([commits 6f4f18e0d → 677431047](.)):**
- Убрать `width: max-content + minWidth: 100%` из inner div.
- Regression assertion в тесте инвертирован: `max-content === false`.
- `BUG-2026-04-21-03`.

## Audit cleanup `doc/SolidWorks-WorkFlow/` ([commit 3e5a652d0](.))

**Что сделано без отдельного цикла:**
- Архивированы 2 устаревших planning-доков: `Implementation_Foundation_Architecture.md`, `MultiProvider_Orchestration_Scenarios.md` (draft-only, never Accepted, no code).
- Status-notes добавлены в 2 активных plan'а: `DevelopmentTree_Sidebar_Visualization` + `DevelopmentTree_BranchWorkflow` (часть реализована, часть deferred).
- Переписаны stale toolbar-refs в 2 Contracts: `ProjectManager_WorkflowNavigation_SSOT.md`, `VirtualSimulation_Step.md` (top-toolbar удалён в 1.1.924, sidebar — sole surface).
- `Docs_Index.md` обновлён.
- Позже (в ходе 1.2.42 push) пришлось поправить 4 broken links в `ProviderFailure_Recovery_And_ProviderSwitch.md` на перенесённый `MultiProvider_Orchestration_Scenarios.md` ([commit 452daeb08](.)).

## 1.2.42 — Provider stale-binding auto-recovery (Claude + Codex)

**Сценарий:** после Core restart первое сообщение в reopened Claude диалоге тихо пропадало: UI не блокируется "Agents is working", нет error, JSONL не обновляется. `core.log` показывал `Provider sendMessage failed: Session <id> not found` → classifier `session_binding_recoverable / retryable:true`, но retry для Claude не был wired (Gemini это закрыл в 1.2.8 через `GeminiSessionStaleBindingError`).

**Root cause:** 1.2.39 materializer создаёт paper-binding с `providerSessionStatus: "ready"`, но `ready` означает только "journaled in Core", НЕ "provider module hydrated". Первый user message попадает в dispatch → сразу в `adapter.sendMessage` без resume. Claude SDK Manager in-memory Map пустой после рестарта процесса → generic `Error("Session X not found")`. Аналогично Codex: child app-server умирает вместе с Core, `facade.sessions` пустой, `turn/start` на unknown thread → JSON-RPC error.

**Fix 1.2.42 ([commits e3f087752 → fa73943e4](.)):**
- `ClaudeSessionStaleBindingError` в `packages/Claude_Module/src/provider/claude-session-stale-binding-error.ts` с `code: "CLAUDE_SESSION_STALE_BINDING"` + `providerSessionId`.
- `ClaudeSDKManager.sendMessage` бросает typed error вместо generic.
- `CodexSessionStaleBindingError` в `packages/Codex_AppServer_Module/src/provider/codex-session-stale-binding-error.ts`.
- `CodexAppServerFacade` получил `handshakedThreadIds: Set<string>`, заполняется в `createSession`/`resumeSession`, вычищается в `closeSession`. `sendMessage` проверяет membership до `turn/start` и бросает `CodexSessionStaleBindingError` — **не полагаемся на error content от app-server**, а гарантируем handshake на facade уровне.
- `SessionRequestHandlerMessageDispatch` detector обобщён на `ReadonlySet<string>` кодов (`GEMINI_/CLAUDE_/CODEX_SESSION_STALE_BINDING`). Retry-ветка та же — one-shot `invalidateProviderBinding + ensureSessionReadyForSend + resend`.
- `SystemArchitecture.md` §3 Invariant 1 расширен. `BUG-2026-04-21-04`.

## 1.2.43 — Codex PATH + Post-rebind usage limits refresh

**Сценарий 1:** после установки 1.2.42 Codex выдал `System: Provider codexCli unavailable`. `~/.codeai-hub/logs/codex/sdk-codex-app-server-*.jsonl` показал `spawn_error: "spawn codex ENOENT"` на каждом recovery re-spawn. Первый spawn при старте Core (13:37) прошёл успешно, после штатного `closeSession`/`process.stop` app-server умер, потом ENOENT.

**Root cause 1:** Inherited `process.env.PATH` у VS Code extension host на macOS GUI launcher не содержал `~/.npm-global/bin`, где установлен `codex`. `spawn("codex")` не находил binary.

**Сценарий 2:** usage_limits widget у Claude и Codex пустой после Core restart до первого turn'а. Gemini работал. `core.log` показывал `Usage limits refresh dispatched to adapter` но никаких broadcast'ов после.

**Root cause 2:** PM emit'ит `binding_ready` usage_limits refresh ровно один раз на логическую session. После 1.2.39 materializer paper-binding с `ready` попадает в dispatch до `adapter.resumeSession` handshake. Первый refresh возвращает null (race). После stale-binding retry из 1.2.42 session hydrated, но второго refresh'а не было.

**Fix 1.2.43 ([commits f5c9b3371 → 82bbfa2eb](.)):**
- `CodexAppServerProcess.startInternal`: `buildAugmentedPath()` приписывает к inherited PATH curated-список (`~/.npm-global/bin`, `/opt/homebrew/bin`, `/usr/local/bin`, `/usr/bin` на POSIX; `%APPDATA%\npm` на Windows). PATH lookup остаётся primary mechanism.
- Новый helper `packages/core/src/remote-bridge/handlers/session-request-handler-post-rebind-usage-limits.ts`: `triggerPostRebindUsageLimitsRefresh({adapter, broadcaster, logger, ...})` вызывается из `retryAfterStaleBinding` после успеха rebind'а.
- `BUG-2026-04-21-05`.

## 1.2.44 — Single-probe usage limits warmup

**Сценарий:** после 1.2.43 continuation сессий работает, но usage_limits widget у Claude/Codex показывает `Session 0% / Weekly 0%` до первого turn'а. После первого turn'а — корректные цифры в формате `Session 23% (Resets Apr 21 at 11pm) / Weekly 43% (Resets Apr 23 at 11pm)`.

**Опытная проверка:**
- **Codex app-server**: пушит `account/rateLimits/updated` notification 7-8 раз за turn с полным payload (`primary.usedPercent`, `secondary.usedPercent`, `windowDurationMins`, `resetsAt`, `planType: "prolite"`). Passive extraction работает бесплатно.
- **Claude SDK**: эмитит `sdk:rate_limit_event` только со `status` / `resetsAt` / `rateLimitType`, без `usedPercent`. Anthropic отдаёт % только в HTTP headers `anthropic-ratelimit-unified-*`. Поэтому `ClaudeLiveHeadersReader` делает отдельный HTTP probe на `api.anthropic.com/v1/messages` с `max_tokens: 1`.
- `providerScopeKey` **уже** account-wide (`{providerId}:global` с `070139b9e`) — один успешный probe наполняет payload для всех sessions провайдера.

**Архитектурное обсуждение с пользователем** (важный контекст):
- Отклонили persistence на диск: shared across clients (параллельный Claude Code CLI выел бы лимиты, snapshot устарел бы).
- Отклонили "refresh дважды в turn" (start + end): start-of-turn probe бесполезен, cache от прошлого turn'а уже актуален.
- Отклонили формат widget'а "5h resets in 2h 14m / weekly resets in 3d" — пользователь хочет проценты.
- Отклонили eager resume всех reopened dialog'ов в materializer: слишком дорогой cold-start.

**Root cause:** PM эмитит `binding_ready` refresh на каждое открытие dialog'а, все refresh'и гонятся против paper-binding hydration. Первый probe возвращает null, subsequent повторяют ту же гонку.

**Fix 1.2.44 ([commits c2ecb6b01 → e0e765b5d](.)):**
- `packages/core/src/remote-bridge/handlers/session-request-handler-usage-limits-warmup.ts`: новый `UsageLimitsWarmupTracker: Set<providerId>` + diagnostic log helpers. На `binding_ready` — если провайдер уже warmed, skip dispatch и fall back to cached replay. Другие triggers (`turn_completed`, `reconnect`, `manual`, `provider_session_rebound`, `dialog_opened`, `session_opened`) не дедуплицируются.
- `packages/core/src/remote-bridge/handlers/session-request-handler-usage-limits-refresh.ts`: вынесенный из handler'а `handleRefreshUsageLimitsFlow` (чтобы удержать `session-request-handler.ts` под 500-строковым лимитом: 491 → 400).
- `SessionRequestHandler.handleRefreshUsageLimits` теперь тонкий delegate.
- UI widget не трогали (Phase 3 skipped — `usage-limits-stream.readBucket` уже возвращает null на `percentUsed === null`, `hasUsageLimits` скрывает row целиком, legitimate `Session 0%` в начале 5-часового окна остаётся честным API response).
- `BUG-2026-04-21-06`.

---

## Общий список релизных артефактов в `doc/tmp/releases/`

- `codeai-hub-1.2.40.vsix` (2.28 MB) + 7 tarball'ов
- `codeai-hub-1.2.41.vsix` (2.28 MB) + 7 tarball'ов
- `codeai-hub-1.2.42.vsix` (2.28 MB) + 7 tarball'ов
- `codeai-hub-1.2.43.vsix` (2.29 MB) + 7 tarball'ов
- `codeai-hub-1.2.44.vsix` (2.30 MB) + 7 tarball'ов

**Финальный VSIX для тестирования:** `codeai-hub-1.2.44.vsix`.

## Ключевые коммиты (33 всего)

**1.2.40 цикл (9 коммитов):** `4f43fd76d`, `c1ede86b0`, `3661b315d`, `63fdac691`, `72097ad9a`, `41591193a`, `f7b3d45e0`, `2f26ac882`, `9adac5139`.

**1.2.41 цикл (6 коммитов):** `6f4f18e0d`, `745d05b16`, `00c63f2ab`, `24470996a`, `ced7d68c5`, `677431047`.

**Audit cleanup (1 коммит):** `3e5a652d0`.

**1.2.42 цикл (10 коммитов):** `e3f087752`, `783deba31`, `e4e117e6e`, `c65e5172f`, `e588dda80`, `f3266a443`, `0d24d60cc`, `1e948e9c1`, `fa73943e4`, `452daeb08`.

**1.2.43 цикл (7 коммитов):** `f5c9b3371`, `d26868644`, `d70c31761`, `ef9d6897e`, `2f2be9afd`, `956ccc257`, `a5a598bef`, `82bbfa2eb`.

**1.2.44 цикл (6 коммитов):** `c2ecb6b01`, `d9e7114a4`, `de586e9e8`, `9dbc987fb`, `5884812b1`, `e0e765b5d`.

---

## Git/remote state

- `main` pushed до `e0e765b5d`.
- Дерево чистое. Незакоммиченными остаются только Session[077-082].md файлы (они `doc/Sessions/*` gitignored).

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` (§3 Invariant 1 — полностью покрывает stale-binding auto-recovery + Codex PATH + single-probe warmup).
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`.
**Active todo-plan:** пустой stub.

## Что предстоит протестировать в 1.2.44

Установить `codeai-hub-1.2.44.vsix` и проверить три независимых сценария:

### Тест 1 — Development Tree sidebar стабильность (1.2.40 baseline)
- Workspace `CodeAI-Hub claude`, stage `diagram_modules`, reopened dialog с заполненным `product-parts/project-manager.md`.
- Несколько раз expand/collapse кластеры в sidebar — структура **не должна** перещёлкиваться между правильной и ложной. Должно быть стабильно: 2 cluster'а (`workflow-and-artifact-ui`, `session-workspace-ui`) + 1 standalone (`cef-launcher`).

### Тест 2 — Artifacts auto-fit zoom (1.2.41 baseline)
- Тот же workspace, panel Artifacts показывает product-part composition.
- Уменьшать горизонтальный размер окна VS Code — composition **должна** помещаться по ширине, масштабируясь. Cmd+scroll даёт overlay поверх auto-fit. Cmd+Ctrl+0 возвращает user-zoom к 1 (auto-fit остаётся).

### Тест 3 — Stale-binding + usage limits warmup (1.2.42/43/44 комбинированный)
- **Перед тестом**: полный Core restart (закрыть VS Code → снова открыть).
- Открыть PM, пройтись по reopened dialog'ам у Claude, Codex, Gemini **без отправки сообщения**.
- **Ожидание по 1.2.44**: widget сразу показывает актуальные цифры `Session N% (Resets …) / Weekly M% (Resets …)` у всех трёх провайдеров. Никакого `Session 0% / Weekly 0%` в моменте открытия.
- **Ожидание по 1.2.42**: отправить первое сообщение в reopened dialog — **не** должно быть silent drop, `turn_state: "running"` появляется в UI, turn выполняется нормально.
- **Ожидание по 1.2.43**: Codex provider остаётся available после открытия и закрытия dialog'ов (нет `Provider codexCli unavailable`).

### Что проверить в логах если что-то не работает
- `~/.codeai-hub/logs/core/core.log` — искать:
  - `"Usage limits refresh skipped: provider already warmed"` — индикатор работы dedup (ожидается на 2-м и далее binding_ready того же провайдера).
  - `"Post-rebind usage limits refresh dispatched"` — 1.2.43 trigger после rebind'а.
  - `"Stale provider session detected during send"` — 1.2.42 retry path сработал.
- `~/.codeai-hub/logs/codex/sdk-codex-app-server-*.jsonl` — `account/rateLimits/updated` должны приходить после каждого turn.
- `~/.codeai-hub/logs/claude/sdk-claude-*.jsonl` — `sdk:rate_limit_event` на turn boundary.

## Deferred items (кандидаты на новый scope)

1. **Rate-limit error handler на Core dispatch'е** — перехват `rate_limit_error` от API, graceful display reset time + restore prompt в input + cache update из error headers. Обсуждали с пользователем в 1.2.44 planning-doc'е как Out of Scope.
2. **Baseline failing tests** в `src/client/project-manager/components/diagram-editor/diagram-editor-facade.test.tsx` (2 тестa): `auto-fill` string assertion не соответствует текущему facade, product-part hierarchy parser test — не связано с моими правками сегодня, существующий baseline дефект. На pre-commit/pre-push гейты не влияет.
3. **Branch-level workflow execution** — planning-doc `DevelopmentTree_BranchWorkflow_Architecture` и sidebar core реализованы, но session-execution для `Product Part Specification`, `Cluster Design`, `Module Design`, `Implementation Foundation` — [DESIGNED, NOT IMPLEMENTED] (§20 SystemArchitecture).

## Файлы, которые могут потребоваться для контекста

- `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` §3 Invariant 1 (собран весь флоу stale-binding + PATH + warmup).
- `doc/BugRegistry.md` — записи `BUG-2026-04-21-02`, `-03`, `-04`, `-05`, `-06` (в хронологическом порядке).
- Отдельные Session файлы 077-081 если нужны более мелкие детали (хранятся локально, gitignored).
- Archived planning-doc'и в `doc/SolidWorks-WorkFlow/Plans/Archive/`:
  - `DiagramModules_DevTreeParser_And_AutoFitZoom_Architecture.md` (1.2.40)
  - `DiagramModules_AutoFitZoom_NaturalWidthHotfix_Architecture.md` (1.2.41)
  - `Provider_StaleBinding_AutoRecovery_Architecture.md` (1.2.42)
  - `Codex_PATH_And_PostRebind_UsageLimits_Architecture.md` (1.2.43)
  - `Usage_Limits_AccountScoped_Warmup_Architecture.md` (1.2.44)

## Состояние кода и инфраструктуры на конец сессии

- Версия: `1.2.44`.
- Branch: `main`, чистое дерево, pushed до `e0e765b5d`.
- Активного execution scope нет — `todo-plan.md` в stub-форме.
- Все Husky гейты (pre-commit: architecture check + lint + knip + format; pre-push: check:dup + check:links) зелёные.
- Архитектурный check: 0 файлов > 500 строк, 31 файл в warning zone (400-500). `session-request-handler.ts` = 400 строк (был 491 до рефакторинга).
- Duplication: 2.05% (< 3% threshold).

## Ключевые архитектурные решения дня

1. **Provider-scoped stale-binding errors** — каждый provider module имеет свой typed error с shared `code`-схемой (`{PROVIDER}_SESSION_STALE_BINDING`). Core dispatch распознаёт через string-match на `.code`, никакого capability flag.
2. **In-memory-only usage limits cache** — никакой persistence на диск, cache account-scoped (`{providerId}:global`).
3. **Single-probe warmup per provider per Core process** — дедуплицирует только `binding_ready` triggers, остальные lifecycle-события (turn_completed, reconnect, manual и т.д.) проходят как раньше.
4. **Passive extraction приоритетнее active probe** — Codex app-server push'ит полный payload 7-8 раз за turn; Claude SDK отдаёт частичный payload через `rate_limit_event`, HTTP probe остаётся для `usedPercent` headers.
5. **Widget UI не мудрит** — `Session 0%` в legitimate начале 5-часового окна остаётся честным, UI не пытается скрывать валидные нули.

