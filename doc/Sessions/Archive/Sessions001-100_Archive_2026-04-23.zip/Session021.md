# Session 021 — Anthropic Haiku Translation Engine Planning Intake

**Date:** 2026-04-15 12:30 (CEST)
**Branch:** main
**Version:** 1.1.985
**Execution Scope Status:** COMPLETED
**Planning artefact:** `doc/SolidWorks-WorkFlow/Plans/Localization_TranslationEngine_AnthropicHaiku_Architecture.md` (Status: Draft) — создан в этой сессии, ждёт обсуждения и выбора decision points в следующей сессии.

---

# 1. Work Done in This Session

## Work summary

- Восстановлен контекст по `Session020` (Execution Scope Status: COMPLETED, release `1.1.985` собран и протестирован пользователем). Прочитаны базовый SSOT `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` (акцент на инвариантах 5 / 16 / 21 / 22 / 23) и `doc/SolidWorks-WorkFlow/Docs_Index.md` для навигации.
- Пользователь подтвердил ручное тестирование релиза `1.1.985` — все AC и регрессии зелёные, работает как задумано.
- Принято новое задание: подключить **Anthropic Claude Haiku 4.5** как четвёртый Translation Engine (параллельно Google GTX, Codex GPT-5.4 Mini, Codex GPT-5.3 Codex Spark). Вызов через `@anthropic-ai/claude-agent-sdk` в подписочном режиме (OAuth, provider-home) — тот же механизм, что используется для основных Opus/Sonnet сессий. Ключевое отличие — полная замена дефолтного Claude Code system preset на короткий translator-промпт через `systemPrompt: string` (экономия input-токенов ≈95%, меньше latency, меньше нагрузки на подписочный usage).
- Проведён research через два параллельных Explore-агента:
  - **Translation Engine architecture + Codex Spark specifics** — контракт `TranslationEngine`, registry паттерн, chunk policy registry, UI catalog, integration points.
  - **Claude Agent SDK subscription flow** — `SDKInstaller` с динамическим `import()` `@anthropic-ai/claude-agent-sdk v0.2.109`, `ClaudeAuthRuntime` с OAuth token resolve chain, provider-home (`~/.codeai-hub/providers/claude/home/`), `buildQueryOptions()` в `claude-sdk-manager.ts`, тип `systemPrompt` из `sdk.d.ts` (поддерживает строку как полную замену preset).
- Дополнительный research по уточняющему вопросу пользователя:
  - **Chunking фактическое состояние** — подтверждено: на практике chunking выключен для всех реальных путей (Core session translation всегда `category: "reasoning"` → disabled; localization materializer передаёт `chunkingMode: "disabled"` явно + один batch с маркерами). Категории `generic` / `document` с default `"auto"` существуют в нормализаторе, но фактических вызовов нет. Для Haiku engine chunk-policy формально нужен (контракт), но не активируется.
- Создан planning-doc `doc/SolidWorks-WorkFlow/Plans/Localization_TranslationEngine_AnthropicHaiku_Architecture.md` (Status: Draft) со следующими секциями:
  1. Задача
  2. Причина
  3. Non-Goals
  4. Recap существующей системы (engine contract, SDK subscription flow, chunking state)
  5. Архитектура решения (путь вызова, отключение systemPrompt, минимальные query options, изолированный project slug, concurrency)
  6. **Decision points с рекомендациями** — sharing strategy A/B, engine ID, UI label, system prompt текст, project slug, tools blocking, chunk policy значения
  7. Impact map (новые файлы, изменения существующих, документация, что не трогаем)
  8. Open questions (rate limits, token refresh, keychain prompts, logging, version pinning)
  9. Phasing suggestion (5 фаз со стримами ≤3 файла / пакета)
  10. Чек-лист решений до старта todo-plan.md
- Все изменения прошли husky gates (architecture check, lint, knip) — зелёные.

## Git commits

(REFERENCE ONLY: этот список сохраняется для исторической трассировки; следующая сессия не обязана читать все коммиты по умолчанию.)

- `4bca2b263 docs: add anthropic haiku translation engine plan`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`
**Active planning artefact:** `doc/SolidWorks-WorkFlow/Plans/Localization_TranslationEngine_AnthropicHaiku_Architecture.md`

## Plans for next session

- **Активный execution scope отсутствует** — `doc/TODO/todo-plan.md` не создан. Планинг-док по новой задаче создан в Draft и ждёт утверждения.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT. Особенно обратить внимание на:
  - **Инвариант 5** (provider-home isolation + SDK isolation mode для CodeAI Hub-managed Claude turns) — критичен для дизайна Haiku engine.
  - **Инвариант 21** (translation execution-mode: live chunking vs interface strict materialization) — контекст для chunking state.
  - **Инвариант 22** (localization blocking UI) — поведение при save, incremental sync.
- Далее агент обязан прочитать полностью `doc/SolidWorks-WorkFlow/Plans/Localization_TranslationEngine_AnthropicHaiku_Architecture.md`.
- **Обсудить с пользователем и зафиксировать решения по decision points §6 planning-дока:**
  1. **§6.1** — sharing strategy для SDKInstaller + ClaudeAuthRuntime (A = прямой импорт из Claude_Module / B = выделение shared sub-package `@codeai-hub/claude-runtime`). Рекомендация планинг-дока: B.
  2. **§6.2** — engine ID. Рекомендация: `anthropic-claude-haiku-4-5`.
  3. **§6.3** — UI label. Рекомендация: `"Anthropic Claude · Haiku 4.5"`.
  4. **§6.4** — translator instruction (формулировка system prompt).
  5. **§6.5** — project slug внутри provider-home. Рекомендация: `translation-runtime-haiku`.
  6. **§6.6** — tools blocking. Рекомендация: `allowedTools: []`.
  7. **§6.7** — chunk policy значения. Рекомендация: soft 400 / hard 600.
- **Обсудить open questions §8** planning-дока при необходимости:
  1. Rate limit awareness (достаточно ли fallback-per-request).
  2. Token refresh (polагаться на основной Claude-поток или добавить explicit pre-warm).
  3. Keychain access prompts на macOS (pre-warm first Claude session до первого translate).
  4. Diagnostic logging (reuse TranslationReporter или отдельный claude-translation-logger).
  5. Version pinning Haiku model ID (snapshot `claude-haiku-4-5-20251001` vs alias `claude-haiku-4-5`).
- **После утверждения всех решений** — перевести planning-doc в `Status: Accepted` (с датой), обновить `Created/Updated` поля.
- **Затем создать `doc/TODO/todo-plan.md`** с Context Pack:
  - `Planning source:` путь к утверждённому planning-doc.
  - `Read this context before implementation:` — релевантные документы для текущего cycle:
    - `doc/SolidWorks-WorkFlow/Modules/Shared_RuntimeTranslation_Module.md` (engine contract, chunk policy, transport-only principle).
    - `doc/SolidWorks-WorkFlow/Modules/Localization.md` (engine catalog, language catalog, materializer flow).
    - `doc/SolidWorks-WorkFlow/Modules/Claude.md` (provider-home, auth runtime, SDK isolation mode).
    - `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` (инварианты 5, 21, 22).
    - `doc/SolidWorks-WorkFlow/Contracts/UserFacing_Text_Localization_Boundary.md` (если потребуются изменения в localization helper copy).
  - Phases + Streams следуя разбивке в §9 planning-дока, с учётом выбранного варианта §6.1 (Phase 1 существует только при B).
  - Каждая подзадача ≤ 3 файла / пакета, каждая пара «реализация + Git Commit».

## Context snippets для быстрого старта

- **Release baseline:** `1.1.985` (`codeai-hub-1.1.985.vsix` в корне репозитория, tarballs в `doc/tmp/releases/` и `~/.codeai-hub/releases/`).
- **Engine registry entry point:** `packages/translation/src/translation-facade.ts:16-30` — `createDefaultTranslationEngines()`.
- **UI catalog entry point:** `src/client/ui/src/components/settings/use-settings-state-support.ts:107-111` — `SUPPORTED_LOCALIZATION_ENGINE_IDS`.
- **Claude SDK subscription loader:** `packages/Claude_Module/src/installer/sdk-installer.ts:80-85` (динамический `import()` `sdk.mjs`).
- **Claude auth env assembly:** `packages/Claude_Module/src/auth/claude-auth-runtime.ts:103-131` (`HOME`, `CLAUDE_USE_CLI_AUTH=true`, `CLAUDE_SUBSCRIPTION_MODE=true`, удаление `ANTHROPIC_API_KEY` / `CLAUDECODE`).
- **SDK `systemPrompt` тип:** `~/.npm-global/lib/node_modules/@anthropic-ai/claude-agent-sdk/sdk.d.ts:1434-1480` — `string | { type: 'preset', preset: 'claude_code', append?, excludeDynamicSections? }`. Передача строки полностью заменяет дефолтный preset.
- **Haiku model ID precedent:** `packages/Claude_Module/src/auth/claude-auth-runtime.ts:24` (`AUTH_PROBE_MODEL_ALIAS`) + `scripts/measure-claude-haiku-translation.ts:10` (`claude-haiku-4-5-20251001`) — модель уже присутствует в коде.
- **Result extraction pattern:** iterate `AsyncIterable<SDKMessage>` → `msg.type === "result"` && `subtype === "success"` → `msg.result: string`.

