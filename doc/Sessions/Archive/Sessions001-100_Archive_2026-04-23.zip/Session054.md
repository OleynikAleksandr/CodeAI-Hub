# Session 54 — Codex App-Server Module Release Execution

**Date:** 2026-04-19 15:33 CEST
**Branch:** `main`
**Version:** `1.2.22`
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Восстановлен контекст после `Session053`: подтверждён чистый baseline релиза `1.2.21`, отсутствие активного execution scope и готовность репозитория к новому planning cycle.
- Для нового scope утверждён planning-doc `doc/SolidWorks-WorkFlow/Plans/Archive/Codex_AppServer_Module_Architecture.md`. Документ зафиксировал target-подход: отдельный пакет `packages/Codex_AppServer_Module`, прежний внешний provider contract `codexCli`, дешёвое переключение через существующий provider slot `codex` и rollback path через legacy override seam. После завершения реализации planning-doc архивирован.
- Создан active execution `doc/TODO/todo-plan.md`, который довёл scope до релизной сборки новой Codex runtime line через `codex app-server`. После релизного closeout план архивирован в `doc/TODO/Archive/todo-plan-1.2.22-codex-app-server-release.md`, а active `doc/TODO/todo-plan.md` возвращён в placeholder `Execution Scope Status: EMPTY`.
- Execution cycle открыт первым содержательным коммитом `758fc7b07 docs: open codex app-server execution cycle`, который зафиксировал approved planning-doc, обновлённый `Docs_Index` и новый active `todo-plan.md`.
- В Core снят жёсткий special-case `geminiCli` для create-time binding: provider capabilities теперь явно несут `supportsImmediateBinding`, а resolver использует provider-neutral capability вместо захардкоженного `providerId === "geminiCli"`; таргетная сборка `npm run build --workspace @codeai-hub/core` прошла успешно. Изменение зафиксировано коммитом `53c4aa934 refactor: generalize provider immediate binding`.
- Создан buildable scaffold нового workspace-пакета `packages/Codex_AppServer_Module` с совместимыми публичными экспортами `CodexProviderAdapter` / `CodexModuleOptions`; таргетная сборка `npm run build --workspace=@codeai-hub/codex-app-server-module` прошла успешно. Scaffold зафиксирован коммитом `e97122bc5 feat: scaffold codex app-server module`.
- Публичный surface нового пакета нормализован в `src/index.ts`, `src/types/index.ts` и `src/provider/codex-provider-adapter.ts`, чтобы Core мог быстро переключиться на новый модуль без смены верхнего export-контракта. Этот baseline зафиксирован коммитом `2210826eb feat: add codex app-server adapter baseline`.
- В новом пакете реализован реальный app-server runtime: long-lived `codex app-server`, initialize с `experimentalApi`, `thread/start` / `thread/resume` / `turn/start` / `turn/interrupt`, final `dialog_message` mapping, token usage и usage limits stream events, provider-home path через `~/.codeai-hub/providers/codex/home` с копированием legacy `auth.json` / `config.toml`. Локальный smoke test нового `CodexProviderAdapter` подтвердил рабочий цикл `createSession -> subscribe -> sendMessage -> dialog_message -> token_usage -> turn_completed`, а отдельный reasoning smoke test подтвердил появление `thinking` bubble через reasoning summary notifications.
- По ходу внедрения runtime был пойман архитектурный gate: `codex-app-server-facade.ts` разросся до 609 строк. Файл сразу разрезан на отдельный `codex-app-server-event-router.ts`, после чего лимиты снова соблюдены (`facade` 201 строк, `event-router` 436 строк, `process` 335 строк), а повторный smoke test остался зелёным. Реальный transport-runtime зафиксирован коммитом `b7fb5be51 feat: add codex app-server transport core`.
- Core bundled seam переведён на `@codeai-hub/codex-app-server-module`: после `npm install` новый workspace-пакет материализован в `node_modules/@codeai-hub/codex-app-server-module`, `@codeai-hub/core` снова собирается зелёно, а отдельный loader-smoke подтвердил, что `loadCodexAdapterCtor(undefined, logger)` реально возвращает constructor нового пакета. Core switch зафиксирован коммитом `8a42ecd40 build: wire core to codex app-server package`.
- Packaging/release seam переведён на новый workspace-пакет без смены внешнего codex-артефакта: `build-core.sh` теперь включает tarball `@codeai-hub/codex-app-server-module` в staged runtime, `build-codex-module.sh` собирает `packages/Codex_AppServer_Module`, а `build-release.sh` вычищает новый bundled package из VSIX так же, как остальные provider modules. Локальная верификация прошла через `bash -n scripts/build-core.sh scripts/build-codex-module.sh scripts/build-release.sh` и реальный прогон `./scripts/build-codex-module.sh --version 1.2.21`. Packaging seam зафиксирован коммитом `5decedc37 build: switch codex packaging to app-server module`.
- Core больше не держит type/dependency surface на legacy `@codeai-hub/codex-module`: `packages/core/package.json`, `provider-module-loader.types.ts` и `provider-installer-paths.ts` переведены на `@codeai-hub/codex-app-server-module`, а таргетная сборка `npm run build --workspace=@codeai-hub/core` подтвердила зелёный compile-path. Этот cleanup зафиксирован коммитом `07484eb8a refactor: remove legacy codex module core dependency`.
- Release pipeline доведён до полного app-server cutover: `scripts/build-core.sh` больше не собирает и не пакует legacy codex workspace, `scripts/build-all.sh` поднимает версию у `packages/Codex_AppServer_Module`, а `package-lock.json` фиксирует новый dependency graph без старой codex-зависимости внутри `packages/core`. Локальная проверка прошла через `npm install`, `bash -n scripts/build-all.sh scripts/build-core.sh` и реальный прогон `./scripts/build-core.sh --version 1.2.21`. Эти изменения зафиксированы коммитом `5b337b78d build: align codex app-server release pipeline`.
- Подготовлен public release-note surface для `1.2.22`: `README.md` переключён на новую release line, а `CHANGELOG.md` получил отдельный раздел про Codex app-server cutover и сохранение внешнего provider contract. Это зафиксировано коммитом `02cf2cfc0 docs: prepare 1.2.22 release notes`.
- Канонический Codex SSOT переведён на новый runtime: `Modules/Codex.md`, `SystemArchitecture.md` и `Codex_ResponseMode_Settings_Architecture.md` теперь описывают active line через `packages/Codex_AppServer_Module`, `codex app-server`, `turn/interrupt`, immediate `threadId` binding и прежний внешний contract `codexCli` / `codex-module-<version>.tar.bz2`. Этот архитектурный closeout зафиксирован коммитом `076d69406 docs: sync codex app-server architecture ssot`.
- `./scripts/build-all.sh` успешно поднял unified version до `1.2.22`, пересобрал Claude/Codex/Gemini provider bundles, Core, UI bundles и CEF launcher, обновил manifests и release artefacts, после чего это состояние зафиксировано коммитом `a7f1ec825 build: release 1.2.22`.
- `./scripts/build-release.sh --use-current-version` затем успешно собрал финальный VSIX `codeai-hub-1.2.22.vsix`; release validation path прошёл через Step 7 SDK exclusions, Step 7.5 artefact validation, markdown link check, duplication check, prune dev dependencies и финальную проверку package surface.
- Финальный closeout commit `b89a0dec4 docs: close 1.2.22 codex app-server release scope` архивировал completed planning/todo scope, переключил `Docs_Index` на archive reference, вернул active `todo-plan.md` в placeholder и закрепил `.vscodeignore` exclusions для `@codeai-hub/codex-app-server-module` / `packages/Codex_AppServer_Module`, чтобы следующий `build-release` не оставлял тот же build-side effect в git tree.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `758fc7b07 docs: open codex app-server execution cycle`
- `53c4aa934 refactor: generalize provider immediate binding`
- `e97122bc5 feat: scaffold codex app-server module`
- `2210826eb feat: add codex app-server adapter baseline`
- `b7fb5be51 feat: add codex app-server transport core`
- `8a42ecd40 build: wire core to codex app-server package`
- `5decedc37 build: switch codex packaging to app-server module`
- `07484eb8a refactor: remove legacy codex module core dependency`
- `5b337b78d build: align codex app-server release pipeline`
- `02cf2cfc0 docs: prepare 1.2.22 release notes`
- `076d69406 docs: sync codex app-server architecture ssot`
- `a7f1ec825 build: release 1.2.22`
- `b89a0dec4 docs: close 1.2.22 codex app-server release scope`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
