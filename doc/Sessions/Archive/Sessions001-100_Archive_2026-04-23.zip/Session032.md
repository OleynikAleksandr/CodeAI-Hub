# Session 32 — Translation Engine Availability Release 1.1.994

**Date:** 2026-04-16 10:20 CEST
**Branch:** main
**Version:** 1.1.994
**Execution Scope Status:** COMPLETED

---

# 1. Work Done in This Session

## Work summary
- Реализован provider-aware gating для `Translation engine` в Settings: `Google GTX Free` остается доступным по умолчанию, а `OpenAI Codex` и `Anthropic Claude` становятся недоступными для выбора, когда backing provider stack недоступен по live `core:state`.
- Зафиксировано продуктовое ограничение: в коде по-прежнему нет отдельного entitlement/subscription-check для OpenAI и Anthropic; UI теперь честно опирается на реальный provider availability/auth state и показывает recovery/status message вместо ложного сигнала о проверенной подписке.
- Подготовлены release notes для `1.1.994`, выполнены `./scripts/build-all.sh` и `./scripts/build-release.sh --use-current-version`, собран VSIX `/Users/oleksandroliinyk/VSCODE/CodeAI-Hub/codeai-hub-1.1.994.vsix`.

## Git commits
(REFERENCE ONLY: этот список сохраняется для исторической трассировки и расследования регрессий; следующая сессия не обязана читать все коммиты по умолчанию.)
- `bab629941 fix: gate translation engines by provider availability`
- `9f72b4f8c docs: prepare 1.1.994 release notes`
- `f87316fe9 chore: build 1.1.994 release assets`

---

# 2. Instructions for Next Session

**Base SSOT:** `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md`
**Scope Discovery Index:** `doc/SolidWorks-WorkFlow/Docs_Index.md`

## Plans for next session
- Активный execution scope отсутствует.
- Следующий агент обязан сначала прочитать `doc/SolidWorks-WorkFlow/System/SystemArchitecture.md` как базовый SSOT.
- Затем агент обязан согласовать с пользователем новый scope.
- После этого агент обязан открыть `doc/SolidWorks-WorkFlow/Docs_Index.md`, выбрать релевантные документы для нового scope и только потом формировать новый planning-doc.
- До появления нового planning-doc и нового `doc/TODO/todo-plan.md` навигационной опорой служит `doc/SolidWorks-WorkFlow/Docs_Index.md`.
