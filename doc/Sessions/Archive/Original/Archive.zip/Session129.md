# Session 129 — Phase 4–5 Autonomous Core migration (CEF Launcher & Providers)

**Дата:** 17 ноября 2025  
**Время:** 13:30–14:45 (Madrid, UTC+1)  
**Ветка:** renaissance  
**Версия:** 1.1.260

---

## Обязательные документы к прочтению перед следующей сессией

1. `doc/AutonomousCore_Architecture.md` — актуальная архитектура Autonomous Core, включая обновлённые разделы про инициализацию провайдеров и контракты UI‑клиентов.
2. `doc/TODO/todo-plan.md` — план работ; Phase 5 помечена как завершённая, актуальны задачи Phase 6 и Phase 7.
3. `AGENTS.md` — инструкции по микрозадачам, гейтам качества и правилам завершения сессий.
4. `doc/Sessions/Session128.md` и `doc/Sessions/Session129.md` — контекст перехода от Phase 3 к Phase 4–5 и завершения миграции провайдеров в ядро.

---

## Что было сделано в этой сессии

### 1. Phase 4 — CEF Launcher → attach-only client

**Коммит:** `ab0bf76` — `feat(cef-launcher): use core supervisor for startup and status`  
**Коммит:** `9ef6f21` — `refactor(cef-launcher): keep extension launcher module focused on config`

- Переведён `packages/cef-launcher/src/core_launcher.cc` на запуск ядра через Core Supervisor: лаунчер больше не спавнит `node dist/index.js`, а вызывает `codeai-core start --host/--port` и ждёт готовности по TCP.
- Обновлён health‑мониторинг в лаунчере: `MonitorCoreHealth` использует `/api/v1/status` и пишет предупреждения в лог вместо самовольного рестарта ядра.
- Улучшен UX ошибок в `launcher_handler.cc`: при невозможности загрузить UI пользователь получает страницу с инструкцией проверить `/api/v1/status` и лог `~/.codeai-hub/logs/launcher/launcher.log`.
- На стороне extension модули лаунчера укорректированы так, чтобы фокусироваться на конфигурации/запуске CEF клиента, а не на управлении core.

### 2. Phase 5.1 — ProviderRegistry & файловый реестр провайдеров

**Коммит:** `a1107af` — `feat(core): resolve providers from filesystem registry`  
**Коммит:** `6c2038a` — `feat(core): add degraded provider status`

- В `ProviderRegistry` реализован файловый реестр провайдеров: ядро читает `~/.codeai-hub/providers/<provider>/<version>` (через `latest` и сканирование `install.json`) и использует найденные пути как базу для загрузки модулей Claude/Codex/Gemini.
- Источники `CLAUDE_MODULE_PATH`/`CODEX_MODULE_PATH`/`GEMINI_MODULE_PATH` теперь строятся из реестра, с возможностью override через переменные окружения.
- Введена расширенная модель статуса провайдера: `active` / `inactive` / `degraded` + диагностическое сообщение `statusMessage`.
- `/api/v1/status` отдаёт список провайдеров с новыми статусами и диагностикой; ошибки инициализации/рантайма переводят провайдер в `inactive` или `degraded`, не останавливая core.

### 3. Phase 5.2 — Provider Autonomy inside Core

**Коммиты:** `53e69b8`, `7049e97`, `a1107af`, `6c2038a`

- Подтверждена целевая модель: при старте ядра `CoreOrchestrator.start()` вызывает `ProviderRegistry.initialize()`, который один раз инициализирует адаптеры Claude/Codex/Gemini.
- Для Gemini использован `GeminiInstaller` и `cli-bridge`: ядро подготавливает `gemini-cli-core` в файловом реестре, обнаруживает/обновляет глобальный `@google/gemini-cli` и фиксирует версию/ошибки в логах.
- Ошибки отдельных провайдеров больше не валят orchestrator: статусы `inactive`/`degraded` отражаются в `/status`, а повторные попытки восстановления выполняются самим ядром.

### 4. Phase 5.3 — Удаление auto-ensure провайдеров из UI и обновление UX

**Коммит:** `e84bdba` — `refactor(extension): stop auto-installing provider modules on activate`  
**Коммит:** `16b158b` — `feat(ui): surface provider inactive/degraded states`

- Extension больше не выполняет автоматическую установку модулей Claude/Codex/Gemini при активации: `ensureCoreAndProviderComponents` делегирует только установку core, а провайдеры поднимаются ядром.
- UI обновлён для работы с новыми статусами провайдеров:
  - provider‑picker показывает провайдеры с `inactive/degraded` как недоступные; диагностическое сообщение из ядра отображается как warning.
  - статус‑панель сессии дополняется текстом о том, что отключённые/деградированные провайдеры недоступны и требуют явного Repair/настройки.

### 5. Актуализация архитектурной документации

**Коммит:** _(последующий, только для доков текущей сессии)_  

- `doc/AutonomousCore_Architecture.md` обновлён под фактическую реализацию:
  - раздел 5.2 описывает файловый реестр провайдеров, одноразовую инициализацию при старте и статусы `active/inactive/degraded` с диагностикой;
  - раздел 6.1 фиксирует роль VS Code extension как attach‑only клиента, использующего Supervisor/RemoteBridge без скрытых установок провайдеров;
  - раздел 6.2 обновлён под новый контракт CEF Launcher, использующий Supervisor для старта ядра и `/api/v1/status` для health‑мониторинга.

---

## План на следующую сессию

### Phase 6 — Core TTL & Long-Lived Sessions

1. **6.1.1 — TTL ядра и модель активности**  
   - Реализовать базовую модель TTL/idle для ядра в `core-orchestrator.ts` + `runtime-status-reporter.ts`: отслеживать активность (запросы/сессии), рассчитывать время до auto‑shutdown и отдавать эти данные через `/status`.

2. **6.1.2 — Конфигурация TTL и режим "долго живущее ядро"**  
   - Добавить параметры конфигурации TTL в `core` (`config/index.ts`) и задокументировать поведение в `doc/AutonomousCore_Architecture.md` (включая бесконечный режим и сценарии auto‑shutdown).

3. **6.2.1 — UX сессий при перезапуске VS Code**  
   - Проверить, что при живом ядре перезапуск VS Code не приводит к потере сессий; при необходимости скорректировать `unified-session/storage.ts` и UI‑слой `session-view`, зафиксировать результаты в новом Session‑отчёте.

4. **6.2.2 — UX сессий при перезапуске лаунчера**  
   - Аналогично VS Code, убедиться, что перезапуск лаунчера не влияет на активные сессии при живом ядре (`unified-session/storage.ts` + CEF‑обвязка под macOS).

### Phase 7 — High-Level Architecture Sync

5. **7.1.1 — Синхронизация Architecture/SystemArchitecture**  
   - Обновить `doc/Architecture/Architecture.md` и `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`, чтобы они отражали фактическое состояние автономного ядра, роль Supervisor, attach‑only клиентов (extension/launcher) и новый lifecycle провайдеров, опираясь на реализованные Phase 2–5 и результаты Phase 6.

