# Session 080 — Outside UI launcher handoff

**Дата:** 09.11.2025 15:10 — Madrid (UTC+0100)  
**Ветка:** main  
**Версия:** 1.1.177

## Обязательные документы
- `doc/Architecture/Architecture.md`
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`
- `doc/Project_Docs/UnifiedSessionArchitecture.md`
- `doc/Project_Docs/knowledge/Settings_Architecture_Guide.md`
- `doc/Project_Docs/Stacks/Launcher_CEF_Module.md`
- `doc/TODO/todo-plan.md`

## Что произошло
1. Перенёс bootstrap/lock ядра полностью в расширение: `CoreProcessManager` теперь единственный владелец установки и passthrough connection info, кнопка Outside UI гарантирует работающий оркестратор перед запуском лаунчера, а action bar в standalone UI скрыт.
2. В `CodeAIHubLauncher` удалил ensureCoreProcessRunning/monitoring, добавил health-check перед стартом и подсказку «откройте VS Code» при ложном standalone запуске. Launcher получает реальный host/port через config/URL, закрывается вместе с VS Code и больше не создаёт `.app/.lnk/.desktop` ярлыков.
3. Обновил README, CHANGELOG, SystemArchitecture и Launcher_CEF_Module, зафиксировал прогресс в `doc/TODO/todo-plan.md`, собрал релизы `./scripts/build-all.sh` → `codeai-hub-1.1.176.vsix` и `codeai-hub-1.1.177.vsix` (второй — сервисная перепаковка) и задокументировал билд (смоук → `npm run compile`, `npm run lint`, `./scripts/build-all.sh`).
4. Git commits:
   - `894bd6b` — feat: vscode owns launcher bootstrap
   - `2346ae6` — chore: rename outside ui command
   - `b6a9eed` — feat: v1.1.176 - outside ui launcher
   - `68136ab` — chore: update roadmap and deps

## План на следующую сессию
1. Продолжить задачу «Многооконный лаунчер»: проектировать модель отделяемых вкладок и менеджер окон в CEF. - `doc/TODO/todo-plan.md`
2. Начать работу над «Изоляцией провайдеров»: продумать degraded-state и сигналы в UI.
3. Подготовить эксперименты для unified session slug/restore (синхронизация истории между webview и standalone).
