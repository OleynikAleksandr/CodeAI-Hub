# Session 034 — Node 20 runtime, Gemini CLI bridge

**Дата:** 30 октября 2025 — Madrid (UTC+1)
**Время:** 15:45 – 18:20
**Ветка:** main
**Версии:** 1.1.69 → 1.1.71 (VSIX), core 0.2.20 → 0.2.21, gemini-module 0.2.x → 0.3.0

---

## Артефакты, обязательные к изучению перед стартом следующей сессии
- `doc/TODO/todo-plan_Gemini_Module.md` (объединённый и актуальный план)
- `doc/Architecture/Architecture.md` (версия 0.3.7 — сведения о Node 20 runtime и локальных артефактах)
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md` (секция про Gemini CLI bridge)
- `scripts/build-core.sh`, `scripts/build-gemini-module.sh`, `scripts/build-release.sh`
- Манифесты: `assets/core/manifest.json`, `assets/providers/gemini/manifest.json`
- `packages/Gemini_Module/src/installer/gemini-installer.ts`, `packages/core/src/provider-registry/index.ts`

---

## Что сделано
1. **Переход ядра на Node 20**: пересобран `@codeai-hub/core` (0.2.21) как JS-бандл + официальный Node runtime. Скрипт `build-core.sh` раскладывает runtime в `~/.codeai-hub/core/<platform>/<version>/` и обновляет manifest на `file://` базу (`~/.codeai-hub/releases`). `CoreProcessManager` теперь запускает Node напрямую.
2. **Gemini module → CommonJS**: выпущен `@codeai-hub/gemini-module@0.3.0`, адаптер и сессии переведены на CJS. Инсталлятор скачивает `@google/gemini-cli` (в `~/.gemini`) и `@google/gemini-cli-core` (в `dist/vendor/node_modules/@google`) из npm, записывает метаданные.
3. **Манифесты и VSIX**: все manifests указывают на локальный кэш `file:///Users/oleksandroliinyk/.codeai-hub/releases/`. Новый VSIX собран через `scripts/build-release.sh` → `codeai-hub-1.1.71.vsix`.
4. **Документация**: обновлены `doc/TODO/todo-plan_Gemini_Module.md`, `doc/Architecture/Architecture.md` (v0.3.7) и `SystemArchitecture.md` — зафиксированы изменения и проблема с ESM.

---

## Текущее состояние
- **Gemini CLI закрывает сессию с ошибкой**: при инициализации ядро пытается `require()` `@google/gemini-cli`, что приводит к `ERR_REQUIRE_ESM`. CLI остаётся ESM, нужно либо CJS-бандл, либо отдельный worker на Node20. Провайдер продолжает запускаться, но помечается `inactive`.
- **Диагностика**: лог ядра (`Starting CodeAI Hub core orchestrator...`) показывает установку CLI и Core 0.2.21, затем падает на `require() of ES Module .../node_modules/@google/gemini-cli/dist/src/config/config.js`. Это подтверждает, что мост всё ещё не решён.

---

## Проблемы / Блокеры
1. `@google/gemini-cli` и `@google/gemini-cli-core` остаются ESM — попытка загрузить их через `require()` невозможна в CJS (`ERR_REQUIRE_ESM`).
2. При старте ядра `ProviderRegistry` ждёт синхронный конструктор, что требует либо bundling CLI в CJS, либо вынесения логики в асинхронный worker.

---

## План на следующую сессию
1. **Решить ESM → CJS мост** (блокер): либо собрать CLI-core в CJS (Babel/tsup), либо организовать отдельный процесс/worker на Node20 и общаться через IPC/WebSocket. Без этого Gemini продолжит падать.
2. После реализации моста — пересобрать `gemini-module`, `core` и VSIX, проверить работы на чистой установке.
3. Обновить документацию (Architecture/SystemArchitecture) после выбора финального решения.

---

## Шаги решения проблемы Gemini (анализ по log ядра)
- Лог показывает, что core загружает модуль, устанавливает `@google/gemini-cli` и `@google/gemini-cli-core`, но при импортировании `config.js` из пакета CLI падает с `ERR_REQUIRE_ESM`. Пакет является чистым ES Module, поэтому `require()` невозможен. Это подтверждает, что текущая реализация (складирование в `dist/vendor/node_modules`) недостаточна без дополнительного CJS-моста.
- Следующий шаг: либо транслировать CLI-core в CJS (например, Babel + tsup), либо запускать CLI как отдельный процесс, с которым наш адаптер будет общаться через IPC.

на Node 20 ядро получает поддержку полноценного import(), но текущая реализация провайдера всё ещё живёт в CommonJS. Внутри
  GeminiProviderAdapter и реестра используется require(), и когда он доходит до пакета @google/gemini-cli, тот — чистый ESM,
  поэтому Node выдаёт ERR_REQUIRE_ESM. Сам runtime уже способен работать с ESM, но нужно либо:

  1. переписать загрузку на await import(...) (перевести адаптер/инсталлятор на ESM или хотя бы выполнять динамический import() в
     CJS), либо
  2. вынести работу с CLI в отдельный процесс/воркер, который запускается на Node 20 и использует ESM-пакеты напрямую.

  Пока этого не сделаем, ядро, хоть и на Node 20, продолжит падать при require() ESM-пакета.

---

## Git commits
Коммитов нет — изменения остаются незафиксированными.

---

## Артефакты для тестирования
- Core runtime: `~/.codeai-hub/core/darwin-arm64/0.2.21`
- Gemini module: `~/.codeai-hub/providers/gemini/0.3.0`
- VSIX: `codeai-hub-1.1.71.vsix`

