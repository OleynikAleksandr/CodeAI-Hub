# Session 076 — Сценарий «VS Code перезапускает уже запущенное ядро»

**Дата:** 09.11.2025 09:04 — Madrid (UTC+0100)
**Ветка:** main
**Версия:** 1.1.173

## Обязательные документы
- `doc/Architecture/Architecture.md`
- `doc/TODO/todo-plan.md`
- `doc/TODO/todo-critical.md`
- `doc/Sessions/Session075.md`

## Что произошло
1. **Цель:** подтвердить, что при одновременной работе двух UI (VS Code + лаунчер) закрытие и повторное открытие VS Code не пересоздаёт ядро и не прерывает сессии, которыми в это время управляет лаунчер. По итогам вчерашних правок ядро перестаёт убивать себя при совпадении версии, но система всё же прерывает запущенные в лаунчере сессии.
2. **Сценарий воспроизведения (фейл):**
   - Запустил Launcher (CEF) через `codeai-hub` artefacts, убедился, что он подключился к ядру и открыл UI с двумя сессиями (Claude + Gemini).
   - Открыл VS Code, активировал CodeAI Hub, в webview создал третью сессию (Codex) и удостоверился, что обе UI отображают все три session-слота (уловиманность UI-потоков).
   - Закрыл полностью окно VS Code (делал Quit, чтобы extension выгрузился).
   - Не трогал лаунчер (он оставался запущенным с тремя сессиями). Затем снова открыл VS Code.
   - В Output канале extension увидел: `CodeAI Hub core already running.` (несколько строк) и затем снова `Preparing to launch CodeAI Hub core on port 8080...`, а потом `Core orchestrator is managed by launcher, skipping local launch.` — видно, что VS Code всё же пытается войти в режим запуска, несмотря на уже действующее ядро.
   - Как результат, после перезапуска VS Code все сессии, отображавшиеся в лаунчере, пропали («Session not found», history очищена). Лаунчер по-прежнему показывает warning «core disconnected» и не восстанавливает предыдущие сессии.
3. **Логический вывод:** даже если `CorePortManager.resolve` уже возвращает `{kind: "running"}` при совпадении версии, `CoreProcessManager.ensureStarted` продолжает вести себя как будто нужна перезапись (снова идёт `portManager.resolve`, `launch`, `managerLock`), что запускает процедуры прерывания провайдеров. Поэтому текущая защита не работает — ядро зашли в state «running», но extension повторно прогоняет всё, нарушая сессии.

## План на следующую сессию
1. _Первый шаг:_ перестроить `CoreProcessManager.ensureStarted` и `CorePortManager` так, чтобы в случае обнаружения работающего core matching target version мы **немедленно выходили** из `ensureStarted`, не вызывая `resolve`/`launch`/`shutdown` и не трогая `CoreManagerLock`. Детали:
   - Сначала получить `targetVersion` (из manifest/context или `declaredVersion`).
   - Вызвать `portManager.detectRunning(targetVersion, currentPort)`; если `kind === "match"`, обновить `connectionInfo` и вернуть, не загружая runtime и не вызывая `shutdownExistingCore`.
   - `CorePortManager.resolve` остаётся для случаев `null`/`mismatch`, но `ensureStarted` должен избегать вызовов resolve после успешного `detectRunning`.
2. _Второй шаг:_ удостовериться, что `runtimeInfo` создаётся только в случае перехода к новому ядру, а загруженная информация сохраняется, чтобы `ensureStarted` не вызывала `ensureCoreInstalled` в ситуации match. Возможно, `ensureStarted` должен графированно разделять ветку «attach-only» и «install+launch».
3. _Третий шаг:_ написать проверку/сценарий (ручной или unit), аналогичный текущему: открываем Launcher, создаём сессии, убиваем VS Code, запускаем снова и проверяем, что сессии остаются. Если нужно, добавить логирование `detectRunning`/`shouldRestart` и проверять, что `shutdownExistingCore` вызывается только при подвёргнувшей mismatch.
4. _Четвёртый шаг:_ после внесения изменений прогнать `npm run compile` и `./scripts/build-all.sh`, чтобы убедиться, что артефакты обновлены, затем повторить ручной сценарий и подтвердить, что лаунчер-сессии остаются живыми.

Дополнительно: описать в `doc/TODO/todo-critical.md` сценарий для отслеживания, и создать короткий трекер (либо новый пункт) на эту проблему, чтобы можно было моментально приступить к отладке в следующей сессии.
