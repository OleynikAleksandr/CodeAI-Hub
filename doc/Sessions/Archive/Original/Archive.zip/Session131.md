# Session 131 — Core TTL, Launcher Supervisor Path & Release 1.1.264

**Дата:** 17 ноября 2025  
**Время:** _(заполнить)_ (Madrid, UTC+1)  
**Ветка:** renaissance  
**Версия:** 1.1.264

---

## Обязательные документы к прочтению перед следующей сессией

1. `doc/AutonomousCore_Architecture.md` — актуальная архитектура Autonomous Core (особенно разделы 4.2 TTL, 7.3 Status / Runtime Status Reporter и 7.4 Unified Session Storage).
2. `doc/TODO/todo-plan.md` — план работ, включая новую фазу `Phase 6.1` для исправления сценариев старта ядра через Supervisor.
3. `doc/Sessions/Session128.md`, `doc/Sessions/Session129.md`, `doc/Sessions/Session130.md`, `doc/Sessions/Session131.md` — контекст миграции на Autonomous Core, завершения Phase 6 и выявленных проблем с автозапуском ядра из UI.

---

## Что было сделано в этой сессии

### 1. Core TTL, статус и конфигурация (Phase 6.1 — завершение базовой модели)

**Ключевой коммит:** `c150679` — `feat(core): add ttl model and status`

- В `CoreOrchestrator` реализована модель TTL/idle:
  - поля `idleTtlMs: number | null`, `lastActivityAt: Date`, `idleSince: Date | null` для отслеживания активности и состояния idle;
  - при подключении/отключении клиентов обновляется `lastActivityAt`, при уходе последнего клиента фиксируется `idleSince` и планируется auto-shutdown;
  - при `idleTtlMs === null` idle-shutdown полностью отключён (режим «долго живущее ядро»), с явным логом в core.
- TTL привязан к конфигурации core:
  - `CoreConfig.shutdownGracePeriodMs` и новое поле `idleTtlMinutes: number | null`;
  - `CORE_SHUTDOWN_GRACE_MS` задаёт интервал ожидания после ухода последнего клиента:
    - `> 0` — конечный TTL (по умолчанию 60 минут);
    - `<= 0` — бесконечный TTL (ядро живёт до явного `stop` или перезагрузки).
- Эндпоинт `/api/v1/status` расширен:
  - блок `core.ttl` с полями `mode`, `idleTtlSeconds`, `lastActivityAt`, `idleSince`, `secondsUntilShutdown`.
- `doc/AutonomousCore_Architecture.md` синхронизирован с реализацией (раздел 4.2), фиксируя:
  - конфигурацию TTL через `CORE_SHUTDOWN_GRACE_MS` / `idleTtlMinutes`;
  - режим бесконечного TTL;
  - контракт `core.ttl` в `/api/v1/status`.

### 2. Launcher → Core Supervisor → Core: сборка и исправление лаунчера

**Коммиты:**
- `a6e8557` — `fix(cef-launcher): restore launcher build for 1.1.x`
- `7bdca50` — `feat: v1.1.264 - core ttl, launcher and supervisor packaging`

Сделано:
- Починена сборка CEF лаунчера для macOS (darwin-arm64):
  - устранили ошибку `use of undeclared identifier 'ReleaseManagerLock'` добавлением объявления `ReleaseManagerLock` до использования в `std::atexit`;
  - подавили предупреждения о неиспользуемых вспомогательных функциях (`AcquireManagerLock`, `ResolveNodeExecutable`, `ResolveEntryPoint`, `LaunchProcess`) через `[[maybe_unused]]`, чтобы не падать на `-Werror,-Wunused-function`.
- `scripts/build-cef-launcher.sh` успешно собирает `CodeAIHubLauncher.app` и кладёт:
  - runtime в `~/.codeai-hub/cef-launcher/darwin-arm64`;
  - архив `CodeAIHubLauncher-macos-arm64-<version>.tar.bz2` в `~/.codeai-hub/releases` и `doc/tmp/releases/`.
- Лаунчер корректно:
  - читает core-mанифест (`assets/core/manifest.json`) и использует core runtime 1.1.264;
  - при уже запущенном ядре (через CLI/скрипт) подключается как attach-only клиент:
    - в `launcher.log` видно:
      - `Using core runtime at ~/.codeai-hub/core/darwin-arm64/1.1.264`;
      - `Core orchestrator already listening on 127.0.0.1:8080`;
      - `Starting core health monitoring`.

**Важно:** логика автозапуска ядра через Supervisor (`EnsureCoreProcessRunning` → `LaunchSupervisorStart` → `codeai-core start`) **есть в коде**, но пока не гарантировано работает «из коробки» (см. раздел «Неработающие сценарии»).

### 3. Packaging core-supervisor и релизные скрипты

**Коммиты:**
- `bde36be` — `chore(build): keep core supervisor and track release scripts`
- `34ac798` — `chore(vscodeignore): include core supervisor in vsix`

Сделано:
- В корневой `package.json` добавлена зависимость:
  - `"@codeai-hub/core-supervisor": "file:packages/core-supervisor"`;
  - это позволяет собирать модуль Supervisor вместе с VSIX и использовать его из расширения.
- Убрали агрессивное удаление `node_modules/@codeai-hub` в `scripts/build-release.sh`:
  - теперь удаляются только внешние SDK (`@anthropic-ai`, `@openai`, `@google`, etc.), а namespace `@codeai-hub` сохраняется;
  - провайдерские модули `@codeai-hub/claude-module`, `codex-module`, `gemini-module` игнорируются через `.vscodeignore` и не попадают в VSIX.
- Обновлён `.vscodeignore`:
  - добавлены исключения:
    - `!node_modules/@codeai-hub/core-supervisor/**`
    - `!node_modules/@codeai-hub/core/**`
  - это гарантирует попадание `core-supervisor` и `core` в VSIX.
- В Git добавлены и формально отслеживаются ключевые скрипты:
  - `scripts/build-all.sh`
  - `scripts/build-release.sh`
  - `scripts/build-cef-launcher.sh`
  - `scripts/build-claude-module.sh`
  - `scripts/build-webview.js`
  - `scripts/build-web-client.js`
  - в `.gitignore` исключения настроены так, чтобы эти скрипты больше не выпадали из Git.

### 4. Полные релизные сборки и артефакты (1.1.261–1.1.264)

В рамках сессии последовательно были выполнены несколько сборок `./scripts/build-all.sh`:

- `2d90780` — `feat: v1.1.261 - autonomous core ttl and providers`  
  Первая полноценная сборка после реализации TTL и переносов провайдеров; использовалась как промежуточная.

- `1e0d7a5` / `d47f5db` / `7bdca50` — релизы 1.1.262–1.1.264  
  Содержат:
  - подъём версий пакетов (`package.json` + workspace пакеты);
  - пересборку core, провайдеров (Claude/Codex/Gemini), unified-session;
  - обновление манифестов (`assets/core/manifest.json`, `assets/launcher/manifest.json`, `assets/providers/*/manifest.json`);
  - формирование артефактов в `doc/tmp/releases`:
    - `codeai-hub-core-darwin-arm64-1.1.264.tar.bz2`
    - `CodeAIHubLauncher-macos-arm64-1.1.264.tar.bz2`
    - `claude-module-1.1.264.tar.bz2`
    - `codex-module-1.1.264.tar.bz2`
    - `gemini-module-1.1.264.tar.bz2`
  - VSIX:
    - `codeai-hub-1.1.264.vsix`, в котором:
      - присутствуют `extension/node_modules/@codeai-hub/core/**`;
      - присутствуют `extension/node_modules/@codeai-hub/core-supervisor/**`.

Все релизные коммиты проходят прехуки (`architecture`, `lint`, `tsprune`, `ultracite_fix`), дерево перед `build-all` было чистым.

---

## Неработающие сценарии и текущие проблемы

### 1. Extension → Supervisor → Core: ядро не стартует

**Симптом:** при установке `codeai-hub-1.1.264.vsix` и запуске VS Code, если ядро не запущено заранее:

- В контейнере уведомлений VS Code появляется сообщение:
  - `Failed to prepare CodeAI Hub runtime: Core did not become healthy via /api/v1/health. Check logs and try again.`
- Extension Host лог фиксирует:
  - ошибка активации расширения `CodeAIHub.codeai-hub` с этим сообщением;
  - `core-supervisor` как модуль найден (ошибка `Cannot find module '@codeai-hub/core-supervisor'` устранена), но supervisor не может довести core до состояния `status: "ok"` на `/api/v1/health` в отведённый таймаут.

**Фактическое состояние:**

- При ручном запуске ядра (через `CodeAI-Core-Control` или `codeai-core start`) и успешном `/api/v1/health`:
  - Launcher корректно прикрепляется к живому core;
  - UI работает; проблема проявляется именно на этапе первичного старта через Supervisor.
  - Extension также корректно стартует и отображает UI

**Предполагаемые причины (для следующей сессии):**

- Несоответствие между портом/хостом, который выбирает `CorePortManager` (`ENV_CORE_PORT`, `CORE_HOST`), и тем, куда supervisor реально поднимает ядро.
- Неполное или некорректное ожидание здорового состояния в `startCore` (внутри `core-supervisor`):
  - возможна гонка между запуском процесса и чтением `/api/v1/health`;
  - TTL/managedMode или ошибки инициализации провайдеров могут тормозить доступность `/health`.
- Недостаточное логирование внутри `core-supervisor` и ядра для детальной диагностики в `~/.codeai-hub/logs/core` и `~/.codeai-hub/logs/extension`.

### 2. Launcher → Supervisor → Core: ядро не стартует (при отсутствии предварительного ядра)

**Симптом:** при запуске лаунчера без заранее поднятого core:

- UI лаунчера показывает длительное состояние:
  - `Please hold on - we are getting CodeAI Hub ready.`
  - `Checking CodeAI Hub services...`
  - `Starting CodeAI Hub core via Supervisor...`
- Ядро при этом не стартует; пользователь не видит CodeAI Hub UI.

**Поведение c ручным ядром:**

- После запуска ядра 1.1.264 через `CodeAI-Core-Control`:
  - лаунчер корректно обнаруживает живой core (`Core orchestrator already listening on 127.0.0.1:8080`) и загружает UI;
  - `launcher.log` подтверждает attach-only сценарий.

**Вывод:**  
Логика `EnsureCoreProcessRunning` и `LaunchSupervisorStart` работает корректно как минимум в части attach (к уже живому ядру), но цепочка `Launcher → codeai-core (CLI) → core` требует доработки и проверок:

- нужно убедиться, что `codeai-core` CLI доступен в `PATH` и корректно работает в среде, где установлен лаунчер;
- нужна более подробная телеметрия в `launcher.log` на шаге Supervisor-вызова и последующих health‑проверок.

### 3. Логирование ядра и расширения

- `~/.codeai-hub/logs/launcher/launcher.log` — заполняется ожидаемыми событиями (инициализация контекста, workspace override, выбор runtime, статус ядра).
- `~/.codeai-hub/logs/core/core.log` — в текущих тестах отсутствовал (core лог ещё не используется как центральный источник).
- `~/.codeai-hub/logs/extension` — в текущих версиях нет отдельного лог-файла для extension, логирование идёт через `extension.log` / Output Channels VS Code.

**Вывод:**  
Для диагностики цепочек `Extension → Supervisor → Core` и `Launcher → Supervisor → Core` не хватает централизованных логов в известных директориях (`logs/core`, `logs/extension`, `logs/launcher`) с единообразной структурой событий.

---

## План на следующую сессию

### Phase 6.1 — Core/Launcher Startup Reliability & Diagnostics

Цель: сделать сценарии автозапуска ядра надёжными и диагностируемыми, чтобы и VS Code расширение, и CEF Launcher могли безопасно поднимать core через Supervisor без ручного вмешательства, а все проблемы легко отслеживались по логам.

**Stream 6.1.1 — Diagnostic Logging (Core / Extension / Launcher)**

- Введение единообразных лог-сообщений для цепочек старта:
  - ядро (`core.log`): события старта, TTL/idle переходы, обработка `/api/v1/health` и `/api/v1/status`, статусы провайдеров;
  - расширение (`logs/extension`): попытки `ensureStarted`, решения `CorePortManager`, вызовы `startCore/stopCore`, ошибки Supervisor;
  - лаунчер (`launcher.log`): все шаги `EnsureCoreProcessRunning`, вызовы `LaunchSupervisorStart`, health‑проверки, таймауты.
- Соглашения по форматам (timestamp, уровень, компонент), чтобы можно было сопоставлять события по времени.

**Stream 6.1.2 — Extension → Supervisor → Core (VS Code)**  

- Проанализировать фактическое поведение `CoreProcessManager.ensureStarted` + `CorePortManager.resolve/detectRunning`:
  - убедиться, что выбранный порт совпадает с тем, куда supervisor реально стартует ядро;
  - устранить случаи, когда core поднимается, но `/health`/`/status` ещё не готовы к моменту проверки.
- Улучшить UX и сообщения расширения:
  - различать «не удалось поднять ядро» (Supervisor-ошибка) и «ядро поднялось, но провайдеры/сессии в проблеме»;
  - логировать детальные причины в `logs/extension`.

**Stream 6.1.3 — Launcher → Supervisor → Core (CEF Launcher)**  

- Проверить, что `EnsureCoreProcessRunning`:
  - корректно обрабатывает отсутствие CLI `codeai-core` (отдельный лог и понятное сообщение пользователю);
  - при наличии CLI успешно вызывает Supervisor и дожидается готовности ядра.
- При необходимости:
  - добавить fallback‑механизм (например, дополнительный запрос к `core-supervisor` через HTTP/pipe вместо `posix_spawnp`, если CLI недоступен);
  - улучшить diagnosics при «вечном ожидании» (чёткие таймауты, подсказка пользователю).

**Stream 6.1.4 — CLI/Core Alignment & Config**

- Синхронизировать поведение `codeai-core-control.js`, `@codeai-hub/core-supervisor` и лаунчера:
  - единый способ выбора runtime (`assets/core/manifest.json`, `~/.codeai-hub/core/<platform>/<version>` и `install.json`);
  - единые правила выбора порта и записи `runtime-registry.json`.
- Убедиться, что запуск ядра через любые из трёх путей (CLI, extension, launcher) оставляет согласованные записи в `runtime-registry` и логах.

---

## Git commits (для справки)

- `c150679` — `feat(core): add ttl model and status`  
- `a6e8557` — `fix(cef-launcher): restore launcher build for 1.1.x`  
- `bde36be` — `chore(build): keep core supervisor and track release scripts`  
- `34ac798` — `chore(vscodeignore): include core supervisor in vsix`  
- `7bdca50` — `feat: v1.1.264 - core ttl, launcher and supervisor packaging`  

> Важно: дальнейшие изменения по Phase 6.1 (исправление сценариев автозапуска ядра) отложены на следующую сессию. Эта сессия фиксирует достигнутое состояние и выявленные проблемы, не внося новых правок в рабочий код после релиза 1.1.264.

## Главные выводы из всех тестов с релизом 1.1.264

Если Ядро стартануть скриптом - /Users/oleksandroliinyk/Desktop/codeai-core-control.jsПри помощи ярлыка - /Users/oleksandroliinyk/Desktop/CodeAI-Core-Control.command
И Extension и Launcher Работают ИМЕННО так, как ДОЛЖНЫ - просто подключаются и отключаются от ядра при своем старте или закрытии, при подключении корректно отображают интерфейсы сессий, которые остались открытыми, не пытаются сами что то перезагружать!
Отсюда можно сделать вывод, что механизмы -
Extension → Supervisor → Core (VS Code)
Launcher → Supervisor → Core (CEF Launcher)
Реализованны не правильно! Либо сам Supervisor создан не правильно.
Почему бы не скопировать полностью механизм запуска ядра из скрипта, который работает отлично?
Из - /Users/oleksandroliinyk/Desktop/codeai-core-control.js
Возможно не верно создан сам механизм запуска -
Extension и Launcher - они вообще при своем старте должны в начале ТОЛЬКО запускать Supervisor,
ждать от Supervisor точного подтверждения, что Ядро запущенно, не таймауты, а точное событие -
Core status: RUNNING
  Version: 1.1.264
  PID: 1323
  Clients: 0
  Managed mode: cli
И только потом запускать сами процессы - Extension и Launcher и просто подключать UI к Ядру, как это сейчас происходит при старте ядра в начале скриптом!
И также при очередных стартах нужно просто проверять какой то статический флаг (от куда то считывать) - который ставит само Ядро, что оно запущенно (не по новой сканировать что то в ядре, а читать то, что записал в флаг ядро) - если флаг говорит, что ядро стартануло - запускать Extension и Launcher без запуска Supervisor.
Любые усложнения при старте Extension и Launcher с какими то проверками чего угодно - приведут к сбоям и повторным попыткам запуска повторного ядра, что категорически не допустимо - ядро должен Один раз запускать Supervisor, если оно уже не запущено - или Останавливать старое ядро и запускать новое - если не совпадают номера релизов.