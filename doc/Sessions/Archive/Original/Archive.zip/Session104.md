# Session 104 — Vendor SDK/CLI & Versions diagnostics

**Дата:** 2025-11-13 18:05 — Madrid (UTC+0100)
**Ветка:** main
**Версия:** 1.1.214 → 1.1.214

**Обязательные документы**
- `doc/TODO/todo-plan.md`
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`
- `doc/Architecture/Architecture.md`

## Что сделано
- Завершил vendor-перенос Claude и Codex: installer/SDK/Auth хитрости теперь обслуживают `dist/vendor/node_modules`, возвращают версионную информацию и больше не опираются на глобальные `~/.npm-global` пути, а реестр провайдеров передаёт `versionInfo` в Core (`packages/Claude_Module/src/*`, `packages/Codex_Module/src/*`, `packages/core/src/provider-registry/index.ts`, `packages/core/src/remote-bridge/index.ts`).
- Добавил панель «Providers → Versions» в General Settings: она слушает `core:state`, вызывает `provider:refresh-versions`, показывает vendor/global версии, пути и mismatch-состояние, и позволяет копировать пути CLI (`src/client/ui/src/components/settings/general-settings.tsx`, `src/client/ui/src/components/settings/provider-versions.tsx`, `src/client/ui/src/core-bridge/core-bridge.ts`).
- Обновил `doc/TODO/todo-plan.md` и привязал выполненные пункты к соответствующим коммитам (`doc/TODO/todo-plan.md:10-50`).

## Git commits (релевантные)
- `87c2550` — feat: vendorize Claude SDK/CLI
- `d5f4eb8` — chore: document todo plan commits
- `dfde5b7` — feat: vendorize Codex SDK/CLI
- `2d4b181` — chore: sync todo plan for codex
- `8426674` — feat: provider versions panel
- `f7c5f03` — chore: sync todo plan for versions panel

## Планы на следующую сессию
1. Подготовить новый пакет/VSIX для проверки: собрать свежие артефакты (`./scripts/build-claude-module.sh`, `./scripts/build-codex-module.sh`, затем `./scripts/build-all.sh` в чистом дереве) и убедиться, что vendor-инсталляторы корректно подтягивают pinned SDK/CLI.
2. Проверить приём информации в UI/Telemetry по `ProviderVersionInfo` (можно прогнать `npm run lint` + `npm run build:webview/web-client` и вручную осмотреть панель No.9).
3. Обновить документацию (SystemArchitecture/Architecture, Knowledge, README) в рамках Docs/Build, чтобы новая vendor-политика и панель версий описывались с ссылками на свежие коммиты.
