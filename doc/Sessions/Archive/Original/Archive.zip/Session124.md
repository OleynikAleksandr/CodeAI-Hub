# Session 124 — Resetting to stable core/ui baseline

**Дата:** 2025-11-15 16:15 — Madrid (UTC+0100)
**Ветка:** main
**Версия:** 1.1.241 → 1.1.242

**Обязательные документы перед стартом**
1. `doc/Sessions/Session123.md`
2. `doc/TODO/todo-plan.md`
3. `doc/Architecture/Architecture.md`
4. `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`

## Ход сессии
- Проанализировал `core.log`/`launcher.log`/`launcher-window-state.json`: ядро 1.1.242 работает стабильно, HTTP `/api/v1/status` отвечает 200, но `detachedSessions` никогда не очищается — UI фильтрует все вкладки и показывает «Please hold on». Лаунчер повторно пишет snapshot после `detached-unregister`, поэтому новая логика синхронизации ядра с детач-окнами приводит к регрессии.
- Согласовали с пользователем радикальный план: временно отрезать лаунчер и все провайдеры кроме Claude, настроить стабильную работу только встроенного UI + core, добавить файл-логирование вместо разрозненных Output’ов.
- Обновил `doc/TODO/todo-plan.md`: удалён старый стрим, создан новый `Stabilize Core + VS Code UI baseline` (ветка `feature/stable-core-ui`) с четырьмя задачами: (1) выключить лаунчер и лишних провайдеров, (2) добавить структурное логирование (extension/core/ui) в `~/.codeai-hub/logs`, (3) подтвердить, что Claude-сессия переживает перезапуск VS Code, (4) только после этого возвращать лаунчер под фичефлагом.
- Согласовали, что новая работа пойдёт с нулевого контекста в отдельной ветке.

## Итоги
- Регистрировали регрессию детач-окон: HTTP ядра жив, но `detachedSessions` не очищается → UI зависает.
- Подготовлен новый план стабилизации: минимальный сценарий Claude+UI, массивное логирование, постепенное возвращение лаунчера.

## План на следующую сессию
1. Создать ветку `feature/stable-core-ui`, отключить лаунчер и все провайдеры кроме Claude (заглушить Codex/Gemini/launcher wiring в extension + core). Убедиться, что `npm run compile` проходит.
2. Добавить файловое логирование: extension пишет в `~/.codeai-hub/logs/extension.log`, UI webview — в `ui.log`, core дописывает события ensure/session-window-state (минимум для следующих шагов).
3. Сценарий: открыть Claude-сессию, перезапустить VS Code, проверить автогидратацию. Если провал — лог анализ, фиксы до успеха.
4. После стабильного базового цикла вернуть лаунчер под новым флагом и повторить тесты, прежде чем включать по умолчанию.

**Git commits**
- 47f8259 — feat: v1.1.242 - detached session recovery
- 0cc6b83 — feat(ui): restore detached session state
- 8349776 — chore(todo): record reattach milestone
