# Session 068 — Gemini smoke-test и повторное падение ядра при скрытом webview

**Дата:** 8 ноября 2025 — Madrid (UTC+1) 16:30 – 17:15  
**Ветка:** main  
**Версия:** 1.1.166

## Обязательные документы
- `doc/Architecture/Architecture.md`
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`
- `doc/TODO/todo-plan.md`
- `doc/TODO/todo-critical.md`

## Что произошло
- Проверил релиз 1.1.166: Gemini CLI 0.11.x успешно поднимается, VSIX и launcher открывают сессии.
- При параллельной работе webview и launcher: после закрытия launcher и скрытого webview ядро решило, что активных клиентов нет, выполнило idle shutdown. VS Code был открыт, но core остановился.
- Дополнительно: после неожиданного shutdown расширение не смогло повторно запустить ядро при разворачивании webview (остались “core already running” и зависание).

## Планы
1. Обновить critical-план: запретить idle shutdown, пока VS Code активен, и обеспечить автозапуск ядра при `child.on("exit")` и повторном открытии webview.
2. В следующей сессии — реализовать sticky keepalive для webview и нормальный restart flow.
