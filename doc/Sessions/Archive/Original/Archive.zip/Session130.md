# Session 130 — Phase 6 Core TTL & Long-Lived Sessions

**Дата:** 17 ноября 2025  
**Время:** _(заполнить)_ (Madrid, UTC+1)  
**Ветка:** renaissance  
**Версия:** 1.1.260

---

## Обязательные документы к прочтению перед следующей сессией

1. `doc/AutonomousCore_Architecture.md` — актуальная архитектура Autonomous Core, разделы 4.2 (TTL) и 7.x (Status/RuntimeStatus/Unified Session Storage).
2. `doc/TODO/todo-plan.md` — план работ по Phase 6–7, статусы задач и поле `Phase 6 Commit`.
3. `AGENTS.md` — правила микрозадач, гейты качества и регламенты релизов.
4. `doc/Sessions/Session128.md`, `doc/Sessions/Session129.md`, `doc/Sessions/Session130.md` — контекст миграции к Autonomous Core и завершения Phase 6.

---

## Что было сделано в этой сессии

### 1. Phase 6.1 — Core TTL модель и статус ядра

- **Файлы:**  
  - `packages/core/src/orchestrator/core-orchestrator.ts`  
  - `packages/core/src/remote-bridge/index.ts`  
  - `packages/core/src/config/index.ts`  
  - `doc/AutonomousCore_Architecture.md`
- **Изменения в ядре:**
  - Core Orchestrator получил явную модель TTL/idle:
    - поле `idleTtlMs: number | null` (null = бесконечный TTL);
    - поля `lastActivityAt: Date` и `idleSince: Date | null` для отслеживания последней активности и момента перехода в idle-состояние;
    - логика `handleClientIncrease`/`handleClientDecrease` обновляет `lastActivityAt` и, при уходе последнего клиента, фиксирует `idleSince` и планирует авто-выключение.
  - При запуске ядра `idleTtlMs` вычисляется из `CoreConfig.shutdownGracePeriodMs`:
    - `shutdownGracePeriodMs <= 0` → `idleTtlMs = null` (TTL бесконечен, авто-shutdown по idle отключён);
    - `shutdownGracePeriodMs > 0` → TTL в миллисекундах, по умолчанию `3_600_000` (60 минут).
  - Авто-выключение по idle:
    - если `idleTtlMs === null`, ядро логирует "Idle shutdown is disabled because TTL is infinite" и **не планирует** таймер;
    - если `idleTtlMs > 0`, при `activeClients === 0` планируется таймер на `idleTtlMs`, который инициирует `requestShutdown("idle")`, если к моменту срабатывания клиентов всё ещё нет.
- **Конфигурация TTL:**
  - В `CoreConfig` добавлено поле `idleTtlMinutes: number | null`:
    - рассчитывается как `Math.round(shutdownGracePeriodMs / 60_000)` при `shutdownGracePeriodMs > 0`;
    - равное `null` означает бесконечный TTL.
  - Переменная окружения `CORE_SHUTDOWN_GRACE_MS` теперь трактуется как **TTL после ухода последнего клиента**:
    - дефолт: `3_600_000` (60 минут);
    - `0` или отрицательные значения обозначают "долго живущее ядро" (бесконечный TTL).
- **Статус ядра (`/api/v1/status`):**
  - В `RemoteBridge` добавлен тип `CoreTtlState` и новый опциональный callback `getTtlState`.
  - Core Orchestrator передаёт в `RemoteBridge` `getTtlState: () => CoreTtlState`, который возвращает:
    - `idleTtlMs: number | null` — конфигурация TTL в миллисекундах;
    - `lastActivityAt: string | null` — ISO-время последней активности (подключение/отключение клиента);
    - `idleSince: string | null` — ISO-время перехода в idle (момент ухода последнего клиента) либо `null`, если клиенты подключены;
    - `secondsUntilShutdown: number | null` — оставшееся время до авто-выключения при `idleSince != null` и `idleTtlMs != null`.
  - Эндпоинт `/api/v1/status` теперь возвращает блок:
    - `core.ttl` с полями:
      - `mode: "finite" | "infinite"` — режим TTL;
      - `idleTtlSeconds: number | null` — конфигурационный TTL в секундах (если конечный);
      - `lastActivityAt`, `idleSince`, `secondsUntilShutdown` — текущее состояние таймера.
- **Документация:**
  - Раздел 4.2 `Время жизни (TTL)` в `doc/AutonomousCore_Architecture.md` синхронизирован с реализацией:
    - описано, что TTL задаётся через `CORE_SHUTDOWN_GRACE_MS` и поле `idleTtlMinutes` в `CoreConfig`;
    - зафиксировано поведение `0`/отрицательных значений (бесконечный TTL) и роль блока `core.ttl` в `/api/v1/status`.
- **Проверки:**
  - `npm run build --workspace @codeai-hub/core`
  - `npm run build:webview`
  - `npm run typecheck:webview`
  - `npm run quality` (архитектурный чек, Ultracite lint, typecheck webview) — прошёл с предупреждениями только по длине некоторых файлов, без ошибок.

### 2. Phase 6.2 — UX сессий при перезапуске UI

- **Файлы для анализа:**  
  - `packages/core/src/unified-session/storage.ts`  
  - `packages/core/src/remote-bridge/index.ts` (`/api/v1/status`, `/api/v1/sessions/:id/history`, начальное состояние `core:state`)  
  - `src/client/ui/src/core-bridge/core-bridge.ts` и `session-history.ts`  
  - `src/client/ui/src/app-host/session-store.ts`, `src/client/ui/src/session/session-view.tsx`  
  - `packages/cef-launcher/src/platform/mac/app_main_mac.mm` + связанный launcher-код (через `launcher_app.cc`, `launcher_handler.cc` — см. предыдущие сессии)
- **Выводы по VS Code (6.2.1):**
  - Ядро хранит сессии в памяти (`SessionManager`) и в файловом хранилище (`UnifiedSessionStorage`) в `~/.codeai-hub/sessions/<workspace>/<provider>/<sessionId>.jsonl`.
  - При подключении нового клиента RemoteBridge:
    - отправляет через WS событие `core:state` с текущим списком сессий (`sessionManager.listSessions()` + provider-статусы);
    - по HTTP `GET /api/v1/status` UI получает такой же список сессий;
    - затем UI вызывает `loadSessionHistories`, который обращается к `GET /api/v1/sessions/:id/history` и догружает историю сообщений из unified-session.
  - Webview в VS Code (`core-bridge` + `session-store`):
    - при старте вызывает `fetchStatusSnapshot` → получает список сессий и провайдеров, восстанавливает локальное состояние через `hydrateFromCoreState`;
    - запускает `loadSessionHistories` для каждой сессии и сливает историю в `SessionSnapshots`.
  - С учётом новой TTL-модели:
    - пока живо ядро, перезапуск VS Code приводит только к пересозданию клиента и повторному `fetchStatusSnapshot`;
    - если перезапуск произойдёт **до истечения TTL после ухода последнего клиента**, список сессий и история восстанавливаются целиком.
  - Дополнительных изменений в `unified-session/storage.ts` и `session-view` не потребовалось: текущая реализация уже соответствует целям Phase 6.2.1.
- **Выводы по CEF Launcher (6.2.2):**
  - Launcher на macOS поднимает CEF-приложение и подключается к тому же RemoteBridge, что и VS Code, используя Supervisor для старта ядра (см. Session 129, Phase 4).
  - Жизненный цикл CEF-клиента отделён от ядра:
    - закрытие лаунчера закрывает клиентское приложение, но ядро остаётся работать до истечения TTL;
    - повторный запуск лаунчера при живом ядре приводит к тому же сценарию, что и в VS Code: загрузка `/api/v1/status`, получение `core:state` и догрузка истории через unified-session.
  - Благодаря новой TTL-модели:
    - перезапуск лаунчера при живом ядре не приводит к потере сессий;
    - ядро может жить заданный интервал после ухода последнего клиента (или бесконечно, если TTL отключён), позволяя пользователю закрывать/открывать лаунчер без потери состояния.

> Итог по Phase 6.2: сессии логически "принадлежат" ядру и unified-session storage, а не UI. Перезапуск VS Code или лаунчера при живом ядре не обнуляет список сессий и историю; UI получают текущее состояние через `/api/v1/status` и `/api/v1/sessions/:id/history`.

---

## План на следующую сессию

1. **Phase 6 — финализация:**
   - Пройтись по `doc/TODO/todo-plan.md` и обновить статусы задач Phase 6 на основании выполненных изменений (оставив `Commit` с плейсхолдерами до фактического git-оператора).
   - После ручного коммита с вашей стороны внести фактические хеши в `todo-plan` и в этот отчёт (раздел Git commits).
2. **Phase 7 — High-Level Architecture Sync:**
   - Обновить `doc/Architecture/Architecture.md` и `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md` под фактическую реализацию Autonomous Core:
     - Core Orchestrator + Core Supervisor;
     - attach-only клиенты (VS Code extension, CEF Launcher, Web Client);
     - модель TTL/idle и блок `core.ttl` в `/api/v1/status`;
     - файловый реестр провайдеров и статусы `active/inactive/degraded`.
3. **Релиз и визуальная проверка:**
   - После обсуждения результатов Phase 6–7 и вашего подтверждения:
     - запустить полный релизный pipeline (`./scripts/build-all.sh` на чистом дереве);
     - собрать новый VSIX-пакет и tarball’ы модулей;
     - обновить `doc/TODO/todo-plan.md` (Phase 6 Commit / Phase 7 Commit) и добавить новый Session-отчёт для релизной сборки.

### Git commits

> Внимание: в этом окружении Codex не выполняет `git commit`.  
> Новые коммиты по результатам этой сессии нужно создать вручную, после чего:
> - добавить их хеши в `doc/TODO/todo-plan.md` (Phase 6 Commit и задачи 6.1.x/6.2.x);  
> - дописать сюда список вида: `hash — "message"`.

