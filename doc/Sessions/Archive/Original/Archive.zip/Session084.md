# Session 084 — Gemini JSONL cleanup & release flow

**Дата:** 11.11.2025 12:10–13:40 — Madrid (UTC+0100)
**Ветка:** main
**Версия:** 1.1.185 ➜ 1.1.187

## Обязательные документы
- `doc/Architecture/Architecture.md`
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`
- `doc/TODO/todo-plan.md`

## Что сделано
1. Починили нормализованные логи: Core больше не пишет временные `temp_*`/`codex-*` сессии, Thinking объединяются в одну запись, UI показывает reasoning одной плашкой.
2. Собрали релиз 1.1.187 строго через `scripts/build-all.sh`, обновили манифесты и VSIX.
3. Обновили регламент в `AGENTS.md` (релиз только через `build-all` на чистом дереве) и актуализировали `doc/TODO/todo-plan.md`.

## Коммиты
- `949304b` — `fix: skip codex provisional session logs`
- `28404a1` — `chore: update release manifest checksums`
- `7497f68` — `feat: v1.1.186 - telemetry suppression`
- `4a1cbd6` — `docs: update gemini stream plan`
- `9d45933` — `docs: enforce build-all release rule`

## План на следующую сессию
1. Перестать создавать временные лог-файлы в провайдерах Claude/Codex: запускать sdk-логгер и Norman JSONL строго после реального providerSessionId.
2. Проверить, что UI/нормализация корректно обрабатывают thinking после переноса логики.
