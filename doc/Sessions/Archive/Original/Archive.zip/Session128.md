# Session 128 — Phase 3 attach-only extension & Supervisor UX

**Дата:** 17 ноября 2025  
**Время:** 11:10–13:00 (Madrid, UTC+1)  
**Ветка:** renaissance  
**Версия:** 1.1.260

---

## Обязательные документы к прочтению перед следующей сессией

1. `doc/AutonomousCore_Architecture.md` — целевая архитектура Autonomous Core (ядро, Supervisor, TTL, провайдеры, контракты UI).
2. `doc/TODO/todo-plan.md` — актуальный план работ; Phase 3 помечена как завершённая, актуальны задачи Phase 4–6.
3. `AGENTS.md` — обновлённые правила микрозадач и ведения todo‑плана (особенно про разбиение задач при >2–3 файлов).
4. `doc/Sessions/Session127.md` и `doc/Sessions/Session128.md` — контекст перехода от архитектуры Autonomous Core к практической миграции extension/launcher.

---

## Что было сделано в этой сессии

### 1. Подготовка Supervisor к использованию из extension

**Коммит:** `2c9e180` — `feat(supervisor): expose programmatic api`

- Расширен `@codeai-hub/core-supervisor` программным API: функции `startCore`, `stopCore`, `readHealth` и типы `SupervisorClientOptions`, `SupervisorHealth`, `SupervisorLogger` стали доступны для импорта из кода расширения.
- Логика CLI вынесена в `main()` с защитой `if (require.main === module)`, чтобы Supervisor можно было безопасно использовать как модуль, а не только через `codeai-core` в shell.
- Введены служебные функции `logInfo`/`logError`, позволяющие переопределить канал логирования (stdout/stderr или кастомный логгер extension).

### 2. Stream 3.1 — CoreProcessManager и запуск ядра через Supervisor

**Коммиты:**
- `b996ab4` — `feat(logger): add severity helpers`
- `ac336c0` — `feat(extension): route core manager through supervisor`
- `e394dcf` — `feat(extension): align activation with supervisor`

Сделано:
- В `ExtensionLogger` добавлены методы `info`, `warn`, `error`, `debug`, чтобы единообразно логировать события Supervisor с разными уровнями важности (`src/extension-module/logging/extension-logger.ts`).
- `CoreProcessManager` больше не создаёт процессы ядра напрямую (убраны `spawn`, `CoreManagerLock`, знание о runtimeDir/entryPoint). Вместо этого он:
  - пытается прикрепиться к уже работающему ядру через `CorePortManager.detectRunning`;
  - если нужно, определяет порт через Supervisor‑ориентированный `CorePortManager.resolve`;
  - запускает ядро через `supervisorStartCore` с кастомным `SupervisorLogger`;
  - после успешного старта повторно выполняет `attachToRunningCore`.
- Все операции Supervisor (`start/stop/status`) логируются как события `core-manager:supervisor:*` в `extension.log` + выводятся в отдельный OutputChannel "CodeAI Hub Core".
- Активатор расширения (`initializeCoreManager` в `src/extension.ts`) теперь строит lifecycle вокруг Supervisor: сначала пробует `attach`, затем — при необходимости — инициирует запуск через Supervisor, а не через `spawn`.

### 3. Stream 3.2 — Порты, runtime-registry и keep-alive поверх Supervisor

**Коммиты:**
- `f65d8c6` — `feat(extension): read core port state from supervisor`
- `068ad05` — `feat(extension): monitor supervisor status in keepalive`

Сделано:
- `CorePortManager`:
  - больше не сканирует порты и не управляет процессами ядра напрямую;
  - использует `resolvePreferredCorePort(envPort, requestedPort)` (`core-port-candidates.ts`), читающий сохранённый порт из `runtime-registry` (который заполняет Supervisor);
  - проверяет живость ядра исключительно через `Supervisor.readHealth` и версию core, возвращая `running`/`launch`.
- `CoreKeepAlive`:
  - удалено обращение к `CoreProcessManager.ensureStarted()` — keep‑alive перестал выполнять запуск ядра;
  - при ошибках WebSocket или закрытии соединения вызывает `Supervisor.readHealth` и пишет диагностические сообщения `[Supervisor] Core reachable / Core is not reachable / Status check failed` в `KeepAlive`‑канал;
  - только планирует переподключения, не влияя на lifecycle core.

### 4. Stream 3.3 — Команды VS Code и UX загрузки UI

**Коммиты:**
- `10ac31e` — `feat(home-view): let supervisor handle launch commands`
- `c862ec3` — `feat(ui core-bridge): report detailed connection status`
- `85ca912` — `feat(ui host): surface supervisor connection details`
- `0c396da` — `feat(ui session): show supervisor state in status panel`
- `f04f90c` — `fix(ui core-bridge): add missing provider id import`

Сделано:
- **Команды VS Code и Home View**:
  - `HomeViewMessageRouter` теперь хранит ссылку на `CoreProcessManager` и прокидывает её в `command-handler`.
  - Перед выполнением команды `launchWebClient` вызывается `coreProcessManager.ensureStarted()` (через Supervisor), а ошибки старта/подключения отображаются как ошибки Supervisor/ядра, а не как общие сбои UI.
  - `extension.ts` кэширует `LauncherInstallInfo` в `cachedLauncherInstallInfo`, чтобы не инициировать повторную установку лаунчера при каждом запуске web‑клиента.
- **Core-bridge и состояния подключения**:
  - В `core-bridge.ts` введены `currentConnectionStatus` и `currentConnectionDetail`; событие `core:connection` теперь содержит не только статус (`connecting | ready | error`), но и текстовое пояснение ("Starting core via Supervisor…", "Waiting for status response…", "Supervisor will retry automatically" и т.п.).
  - Константы default‑конфигурации и дефолтных провайдеров вынесены в `core-bridge/constants.ts`, что упростило модуль `core-bridge.ts` и позволило уложиться в архитектурные лимиты.
- **AppHost и SessionView**:
  - `app-host.tsx` хранит `coreStatus` и `coreStatusDetail`; overlay состояния загрузки теперь использует пояснения от core‑bridge (например, "Unable to reach CodeAI Hub core…" вместо абстрактного сообщения).
  - `SessionView` начинает передавать `coreConnectionStatus` и `coreConnectionDetail` в `StatusPanel`, чтобы сессионная панель могла отображать статус ядра до появления активных сессий.
- **StatusPanel**:
  - Пока ядро не в состоянии `ready`, панель показывает блок "Core Supervisor" с текстом `Core online / Core unavailable / Starting core…` плюс диагностическую строку `connectionDetail` (если есть).
  - После перехода в `ready` панель возвращается к стандартному отображению провайдеров и токен‑лимитов.

### 5. Пересборка webview‑бандла

**Коммит:** `730c79a` — `chore(webview): rebuild react chat bundle`

- После изменения `core-bridge`, `AppHost` и `StatusPanel` пересобран бандл `media/react-chat.js`, чтобы встроенный webview использовал обновлённый контракт `core:connection` и новые тексты статуса.

### 6. Обновление регламентов todo‑плана и AGENTS

- В `doc/TODO/todo-plan.md` (секция `## Правила исполнения`) добавлено правило: если при реализации задачи фактически затрагивается больше 2–3 файлов, работу нужно остановить, разбить задачу на несколько микрозадач (каждая со своим `scope` и `Commit`) и **только потом** продолжать изменять код.
- В `AGENTS.md`:
  - В `Mandatory Workflow` это же правило зафиксировано для микрозадач: "Если по факту для одной задачи требуется изменить больше 2–3 файлов, работу останавливаем, сразу разбиваем её на несколько микрозадач и актуализируем todo-plan".
  - В `TODO Plan Template / Execution Rules` добавлен англоязычный пункт про разбиение задач при превышении порога 2–3 файлов.
- В `doc/TODO/todo-plan.md` Phase 3 полностью отмечена как `DONE`, а поле `Phase 3 Commit` заполнено хешем `0c396da` как логически завершающим коммитом фазы.

---

## Git commits этой сессии

В хронологическом порядке (от старых к новым в пределах сессии):

- `2c9e180` — `feat(supervisor): expose programmatic api`
- `b996ab4` — `feat(logger): add severity helpers`
- `ac336c0` — `feat(extension): route core manager through supervisor`
- `e394dcf` — `feat(extension): align activation with supervisor`
- `f65d8c6` — `feat(extension): read core port state from supervisor`
- `068ad05` — `feat(extension): monitor supervisor status in keepalive`
- `10ac31e` — `feat(home-view): let supervisor handle launch commands`
- `c862ec3` — `feat(ui core-bridge): report detailed connection status`
- `85ca912` — `feat(ui host): surface supervisor connection details`
- `0c396da` — `feat(ui session): show supervisor state in status panel`
- `f04f90c` — `fix(ui core-bridge): add missing provider id import`
- `730c79a` — `chore(webview): rebuild react chat bundle`
- `f04f90c` — `fix(ui core-bridge): add missing provider id import` (финальная правка импорта `ProviderStackId` перед пересборкой)
- `730c79a` — `chore(webview): rebuild react chat bundle` (обновление React‑бандла после всех изменений UI)

> Примечание: ранние коммиты Supervisor (`ae0581c`, `2a68dfc`, `0526942`) и документации (`db6a3b5`) относятся к предыдущим сессиям (Phase 2 и перезапуск плана) и здесь не дублируются.

---

## Планы на следующую сессию

Фокус — переход к Phase 4 (CEF Launcher → attach‑only client) и подготовка почвы для Phase 5 (Provider Autonomy), с сохранением принципа микрозадач ≤2–3 файлов.

### Phase 4 — CEF Launcher → attach-only client

**Stream 4.1 — Интеграция лаунчера с Supervisor**

1. **4.1.1 — Перевести старт ядра в лаунчере на Supervisor.start()**  
   Область: `packages/cef-launcher/src/core_launcher.cc`, `packages/cef-launcher/src/launcher_app.cc`.  
   Цель: заменить прямой запуск процессов ядра на вызов Supervisor (CLI или программный API), сохранив текущие аргументы/окружение.

2. **4.1.2 — Health monitoring лаунчера через /status ядра**  
   Область: `packages/cef-launcher/src/launcher_handler.cc`, `packages/core/src/status/runtime-status-reporter.ts`.  
   Цель: использовать публичный эндпоинт `/status` для health‑check вместо мониторинга процессов; при ошибках только отображать статус пользователю, не перезапуская core самовольно.

**Stream 4.2 — Extension-side launcher integration**

3. **4.2.1 — Очистить extension от прямого управления лаунчером и core**  
   Область: `src/extension-module/cef/launcher.ts`, `src/extension-module/cef/launcher-installer.ts`.  
   Цель: оставить в этих модулях только установку/обновление лаунчера; всё, что касается старта/статуса core, проксировать через Supervisor.

### Phase 5 — Provider Autonomy inside Core (подготовка)

4. **5.1.1 — Реализовать файловый реестр провайдеров в ядре**  
   Область: `packages/core/src/provider-registry/index.ts`, `packages/core/src/config/index.ts`.  
   Цель: добавить сканирование `~/.codeai-hub/providers/<provider>/<version>` и базовую модель статуса провайдера.

5. **5.1.2 — Расширить runtime-status для провайдеров**  
   Область: `packages/core/src/status/runtime-status-reporter.ts`.  
   Цель: включить статусы провайдеров (`active/inactive/degraded`) в `/status` и подготовить контракт для UI/Supervisor.

> Перед началом следующей сессии: перечитать этот отчёт, актуальный `todo-plan`, `AGENTS.md` и архитектуру Autonomous Core, чтобы продолжить с Phase 4 без накопления изменений более чем в 2–3 файлах на задачу.

