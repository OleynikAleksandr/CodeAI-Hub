# Session 056 — Managed Mode Fix v1.1.154

**Дата:** 6 ноября 2025 — Madrid (UTC+1) 08:30 – 09:27  
**Ветка:** main  
**Версии:** 1.1.152 → 1.1.154

---

## Обязательные артефакты
- doc/Architecture/Architecture.md
- doc/Project_Docs/SystemArchitecture/SystemArchitecture.md
- doc/Project_Docs/UnifiedSessionArchitecture.md

## Что сделано

### 🐛 Критический баг исправлен
Обнаружен и исправлен баг auto-shutdown ядра: core останавливался через 60 секунд после отключения последнего клиента, даже если VS Code оставался открытым. При смене фокуса и возврате к расширению UI не мог переподключиться.

### ✅ Реализовано Managed Mode
1. **Core config** — добавлена переменная окружения `CORE_MANAGED_MODE`
2. **Core Orchestrator** — ядро пропускает auto-shutdown, если `managedMode` установлен
3. **Extension host** — передаёт `CORE_MANAGED_MODE=vscode` при запуске ядра
4. **UI reconnect** — при ошибке подключения отправляет `core:restart-request` в extension host
5. **Auto-restart** — extension host автоматически перезапускает ядро по запросу от UI

### 📦 Релиз 1.1.154
- Полная пересборка через `./scripts/build-all.sh`
- Все артефакты обновлены: VSIX, core, launcher, провайдеры
- Размер пакета: 324KB

### 🧹 Git cleanup
Удалены из tracking (остались локально, в .gitignore):
- `doc/Sessions/` — отчёты сессий
- `doc/tmp/` — временные файлы планирования
- `AGENTS.md` — файл разработки

## Блокеры
- Нет.

## ⚠️ Обнаруженные проблемы (исправить в следующей сессии)

### Launcher не поддерживает managed mode и auto-restart
**Сценарий воспроизведения:**
1. Открыли расширение в VS Code
2. Открыли Launcher (CEF UI)
3. Закрыли VS Code
4. Launcher свернули в Dock (не закрыли полностью)
5. Прошло 2-3 минуты
6. Развернули Launcher → UI начинает опрашивать модули, но **ядро мёртвое и не запускается**

**Причина:**
- Launcher не передаёт `CORE_MANAGED_MODE=launcher` при запуске ядра
- Launcher не имеет механизма auto-restart ядра (как extension host)
- Когда VS Code закрывается и managed mode был `vscode`, ядро остаётся без управляющего процесса
- Launcher UI пытается переподключиться, но ядро не перезапускается

**Требуется реализовать:**
1. Launcher должен передавать `CORE_MANAGED_MODE=launcher` при bootstrap ядра
2. Standalone UI должен отправлять restart-request при ошибке подключения
3. Launcher (native код) должен обрабатывать restart-request и перезапускать ядро
4. Standalone режим должен работать полностью независимо от VS Code

## Git commits
- 475f940 — chore: remove local-only files from git tracking
- 5a48dcd — feat: add managed mode to prevent auto-shutdown
- d2ce2fe — feat: v1.1.154 - managed mode prevents auto-shutdown

## План на следующую сессию
1. **🔥 ПРИОРИТЕТ: Исправить Launcher managed mode**
   - Launcher должен передавать `CORE_MANAGED_MODE=launcher`
   - Реализовать auto-restart ядра в Launcher
   - Standalone UI должен отправлять restart-request
   - Протестировать сценарий: VS Code закрыт → Launcher работает независимо
2. **Тестирование managed mode:** проверить VS Code restart, смену фокуса
3. **Продолжить Unified Session работу:**
   - Подготовить smoke-чеклист восстановления истории
   - Выполнить прогон тестов refresh/resume
4. **Сформировать критерии** для расширения JSONL новыми типами (tool/error/system)

