# Session 103 — Vendor‑стратегия SDK/CLI, UI минорные апдейты

**Дата:** 2025-11-13 15:32 — Madrid (UTC+0100)
**Ветка:** main
**Версия:** 1.1.211 → 1.1.214

**Обязательные документы**
- `doc/TODO/todo-plan.md`
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`
- `doc/Architecture/Architecture.md`

## Что сделано
- Провёл анализ хранения версий CLI/SDK для всех провайдеров (Claude/Codex/Gemini):
  - Claude/Codex: сейчас SDK/CLI берутся из глобального npm‑префикса пользователя (`~/.npm-global`), что несёт риск несовместимости при самостоятельных апдейтах.
  - Gemini: используем vendor‑подход — фиксированные версии `@google/gemini-cli` и `@google/gemini-cli-core` ставятся в модуль провайдера под `~/.codeai-hub/providers/gemini/<version>/dist/vendor/node_modules` и не зависят от глобалок.
- Синхронизировал понимание рисков и согласовал стратегию: авторизация — глобальная; версии CLI/SDK — управляемые нами (vendor) для Claude и Codex по аналогии с Gemini. Приоритет: vendor → явный override (`CODEAI_HUB_*_CLI_ROOT`) → глобалка как fallback с предупреждением, без авто‑переключения.
- Обновил план разработки под эту стратегию: добавлена Фаза 5 (vendor‑перенос SDK/CLI, чистка core, UI раздел “Versions”, обновление документации).
- Зафиксировал минорные UI‑апдейты вкладок (Detach/Close) и релизные инкременты 1.1.212–1.1.214.

## Git commits (релевантные)
- `13e1d84` — feat: session tabs detach icon layout
- `ffb9cf0` — feat: session tabs detach hover styling
- `eb9ecdd` — feat: session tabs action zone tighten
- `babf3ff` — feat: v1.1.212 - session tabs detach icon layout
- `fdbd8dd` — feat: v1.1.213 - session tabs detach hover styling
- `dfc89ba` — feat: v1.1.214 - session tabs action zone tighten

## Обсуждение: стратегия хранения версий (итоги)
- Проблема: для Claude и Codex мы подхватываем глобальные SDK/CLI пользователя; обновления вендора могут ломать совместимость.
- Решение: перейти на vendor‑managed для Claude/Codex (как у Gemini):
  - Пиновать версии SDK и CLI в метаданных модулей.
  - Ставить их в `dist/vendor/node_modules` внутри установленного провайдера (`~/.codeai-hub/providers/<prov>/<version>/`).
  - Авторизация остаётся глобальной (пользовательский login), запуск/health — через vendor.
  - Глобальные версии отображать в UI (для сравнения) и использовать только как контролируемый fallback.
- Дистрибуция: на этапе разработки не зеркалим tarball’ы в Releases; полагаемся на загрузку из npm при первом запуске и локальный кэш в `~/.codeai-hub/releases/`. К вопросу зеркалирования вернёмся позже (после оценки лицензий).

## Планы на следующую сессию
- Реализация принятого решения (см. `doc/TODO/todo-plan.md` — Фаза 5):
  - Claude: pinned версии в `package.json`, vendor‑инсталлятор SDK/CLI, health/auth через vendor‑CLI, предупреждения о несовпадениях.
  - Codex: аналогичный перенос SDK/CLI в vendor, загрузка из vendor по умолчанию.
  - Core: убрать жёсткие пути `~/.npm-global` из `provider-registry`, полагаться на адаптеры.
  - UI: раздел “Providers → Versions” для сравнения vendor vs global и ручной проверки.
- Место хранения SDK/CLI впредь:
  - `~/.codeai-hub/providers/<provider>/<version>/dist/vendor/node_modules/**` (Claude: `@anthropic-ai/claude-agent-sdk` + `@anthropic-ai/claude-code`; Codex: `@openai/codex-sdk` + `@openai/codex`).
- Оффлайн‑кэш tarball’ов: `~/.codeai-hub/releases/` (prefetch — опционально, без включения в VSIX).
