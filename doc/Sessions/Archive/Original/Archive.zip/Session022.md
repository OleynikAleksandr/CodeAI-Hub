# Session 022 — Claude Module bundle + core auto-download fixes

**Дата:** 26 октября 2025  
**Время:** 13:00 - 15:30 (Madrid, UTC+2)  
**Ветка:** main  
**Версии:** 1.1.8 → 1.1.13 (Extension), 0.2.0 → 0.2.2 (Core), 0.1.0 → 0.1.2 (Claude Module)

---

## Выполненные задачи

### 1. Claude Module pipeline
- Переписан `SDKInstaller.loadModule()` на нативный `import()` и пересобран модуль: `claude-module-0.1.2.tar.bz2` публикуется через `./scripts/build-claude-module.sh` и автоматически ставится в `~/.codeai-hub/providers/claude/<version>/`.
- VSIX теперь скачивает модуль из `assets/providers/claude/manifest.json`; локальный инсталлер добавлен в runtime-подготовку (`ensureClaudeModuleInstalled`).

### 2. Core + RemoteBridge
- Core обновлён до `0.2.2`, `build-core.sh` чистит старые архивы и размещает только актуальные `codeai-hub-core-darwin-arm64-<version>.tar.bz2`.
- `CoreProcessManager` пробрасывает `CLAUDE_MODULE_PATH`; ProviderRegistry динамически грузит адаптер из override.

### 3. Release tooling
- `build-release.sh` автоматизирует bump (1.1.8 → 1.1.13), очищает `doc/tmp/releases/` и пересобирает VSIX (`codeai-hub-1.1.13.vsix`).
- `doc/tmp/releases/` содержит только три файла: launcher, core (darwin-arm64), Claude module.
- CEF manifest в VSIX использует URL-encoded пакеты, устранён 404.

### 4. Документация
- `doc/Project_Docs/Stacks/Claude_Agent_SDK_Module.md` дополнен разделом "Build & Distribution Snapshot".
- `doc/Project_Docs/knowledge/Инструкция_по_созданию_релизов.md` обновлена: `baseUrl` всегда указывает на `.../releases/latest/download/`.

---

## Артефакты релиза
- `codeai-hub-1.1.13.vsix`
- `doc/tmp/releases/codeai-hub-core-darwin-arm64-0.2.2.tar.bz2`
- `doc/tmp/releases/claude-module-0.1.2.tar.bz2`
- `CodeAIHubLauncher-macos-arm64-1.0.43.tar.bz2` (без изменений)

---

## Проблема на конец сессии
Core при старте падает с `Error [ERR_UNSUPPORTED_DIR_IMPORT]: Directory import '/.../node_modules/@anthropic-ai/claude-agent-sdk'... Did you mean .../sdk.mjs?`. То есть динамический `import()` всё ещё получает путь до директории, а не до `sdk.mjs`, из-за чего ядро не поднимается и `/api/v1/status`/WebSocket недоступны. В `claude-code-fusion` этот момент решён: `SDKInstaller` вычисляет точный entry через `require.resolve(PATH + '/sdk.mjs')`, и `DirectSDKManager` делает `require()` уже конкретного файла. В следующей сессии нужно перенести эту логику (искать `sdk.mjs` внутри глобального пакета, а не импортировать каталог), после чего пересобрать Claude Module → Core → VSIX для валидации.
