# Session 047 — Unified release workflow rollout

**Дата:** 2 ноября 2025 — Madrid (UTC+1)
**Время:** 13:05 – 14:45
**Ветка:** main
**Версии:** 1.1.121 → 1.1.123

---

## Артефакты, обязательные к изучению
- `README.md` (Current Release — v1.1.123)
- `CHANGELOG.md` (entries up to 1.1.123)
- `doc/Architecture/Architecture.md`
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`
- `AGENTS.md`

---

## Что сделано
1. Реализован скрипт `scripts/build-all.sh`, который очищает локальные артефакты и пересобирает провайдеры, core, лаунчер и VSIX с единым номером.
2. Внесены правки в CEF-лаунчер (меню Edit) и Input Panel clipboard-модуль; собран релиз `v1.1.123` с обновлёнными manifest’ами и документацией.
3. README, CHANGELOG и SystemArchitecture отражают новый релиз и процедуру сборки; Release Discipline в `AGENTS.md` обновлена.

## Текущее состояние
- В `~/.codeai-hub/releases/` лежат свежие архивы core/launcher/providers версии 1.1.123.
- `codeai-hub-1.1.123.vsix` собран и готов к установке; Command+C/V/Superwhisper работают в standalone UI.
- Сборочный процесс теперь стандартизирован через `build-all.sh`.

## Проблемы / Блокеры
- Требуется протестировать общий сценарий на Windows/Linux, чтобы убедиться в корректной работе `build-all.sh` и clipboard-пайплайна на других платформах.

## План на следующую сессию
1. Запустить `build-all.sh` на Windows/Linux окружениях, проверить версии артефактов и работу drag & drop/clipboard.
2. Обновить документацию с учётом кросс-платформенных результатов (при необходимости).
3. Подготовить дополнительное руководство по использованию `build-all.sh` для команды.

## Git commits
- a32aa81 — feat: v1.1.123 - clipboard parity release
- 69f2938 — chore: add unified build script
- 6c9cec7 — feat: v1.1.121 - mac clipboard parity
- 7a3c1fb — fix: enable standalone clipboard paste
- 6cae0f6 — feat: v1.1.121 - mac clipboard parity
