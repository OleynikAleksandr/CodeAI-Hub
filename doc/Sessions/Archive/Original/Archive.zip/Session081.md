# Session 081 — Persistent core lifecycle & Gemini plan

**Дата:** 10.11.2025 13:05–14:35 — Madrid (UTC+0100)
**Ветка:** main
**Версия:** 1.1.178 (раньше 1.1.177)

## Обязательные документы
- `doc/Architecture/Architecture.md`
- `doc/Project_Docs/SystemArchitecture/SystemArchitecture.md`
- `doc/Project_Docs/knowledge/Settings_Architecture_Guide.md`
- `doc/TODO/todo-plan.md`

## Что сделано
1. Реализован «вечный» lifecycle ядра: переподключение к живому процессу, корректный force-restart через `CorePortManager`, вынесены fallback-провайдеры (коммит `21ee4ad`).
2. Добавлен фоновой health watchdog (`CoreHealthMonitor`) с предупреждениями и кнопкой Restart core; обновлена документация (`16069b8`).
3. Улучшен UX кнопки «Restart Core» в Settings и отражён процесс в knowledge базе (`3b453c6`).
4. Собран релиз `v1.1.178` через `./scripts/build-all.sh`, обновлены манифесты и пакеты (`42e4ac0`).
5. Уточнены инструкции для агентов и шаблон todo-плана, добавлен строгий workflow микрозадач (`bf03afe`).
6. Исключены отчёты `doc/Sessions/*.md` из репозитория, добавлен `.gitkeep` (`ba01c06`).
7. Сформирован новый план с приоритетом «Gemini vendorization» (`a5d3d33`).

## Коммиты
- `21ee4ad` — feat: persistent core lifecycle
- `16069b8` — feat: core health watchdog
- `3b453c6` — feat: settings restart core ux
- `42e4ac0` — feat: v1.1.178 - persistent core watchdog
- `bf03afe` — docs: micro task workflow
- `ba01c06` — chore: stop tracking session reports
- `a5d3d33` — chore: plan gemini cli vendorization

## План на следующую сессию
(из `doc/TODO/todo-plan.md`)

### Stream: Gemini vendorization
1. [TODO] Embed `@google/gemini-cli` и `@google/gemini-cli-core` в `~/.codeai-hub/providers/gemini/<version>/` (files: `packages/Gemini_Module/src/installer/**`). Commit: `feat: gemini cli vendor bundle`.
2. [TODO] Обновить `cli-bridge` для поиска локальной копии (`CODEAI_HUB_GEMINI_CLI_ROOT` fallback) и документировать процесс (Architecture/SystemArchitecture + knowledge/Gemini_CLI_Module). Commit: `feat: gemini cli vendor bridge`.
3. [TODO] Smoke-test installer + документировать шаги обновления CLI (README/SystemArchitecture). Commit: `docs: gemini vendor workflow`.
