# Session 127 — Core Supervisor foundation & docs sync

**Дата:** 17 ноября 2025  
**Время:** 09:00–09:10 (Madrid, UTC+1)  
**Ветка:** renaissance  
**Версия:** 1.1.260

---

## Обязательные документы к прочтению перед следующей сессией

1. `doc/AutonomousCore_Architecture.md` — целевая архитектура автономного ядра (Autonomous Core): роли Core Orchestrator, Core Supervisor, TTL, статус провайдеров, контракты UI‑клиентов.
2. `doc/TODO/todo-plan.md` — актуальный план работ, обновлённый под Autonomous Core (особенно Phase 2 и Phase 3).
3. `doc/Sessions/Session126.md` — экспериментальные сценарии 1–4 и выводы про зависимость ядра от UI и нестабильность при владении ядром со стороны VS Code extension.
4. `doc/Sessions/Session127.md` (текущий отчёт) — фиксация архитектурного решения и реализованной части Supervisor.

Перед началом следующей сессии важно перечитать эти документы, чтобы не потерять контекст архитектуры автономного ядра и текущего состояния плана.

---

## Что было сделано в этой сессии

### 1. Документирование архитектуры автономного ядра

**Коммит:** `db6a3b5` — `docs: document autonomous core architecture and quality gates`

- Подготовлен и добавлен документ `doc/AutonomousCore_Architecture.md`, который формализует модель **Autonomous Core**:
  - Core Orchestrator (`packages/core/src/orchestrator/core-orchestrator.ts`) — автономный сервис, запускающий HTTP/WS API, управляющий сессиями и провайдерами.
  - Core Supervisor — отдельный надзорный процесс/CLI, который отвечает за `start/stop/status` ядра, работу с портами, lock‑файлом и runtime‑registry.
  - UI‑клиенты (VS Code Extension, CEF Launcher, CLI) — **attach‑only**, без права запускать/переустанавливать ядро; их задача — подключиться к живому ядру и отображать состояние.
  - Провайдеры (Claude, Codex, Gemini) — плагины ядра: инициализируются один раз при старте core, при ошибках помечаются `inactive/degraded`, но не валят orchestrator целиком.
- Документ описывает жизненный цикл ядра (TTL, idle‑таймер), механизм graceful shutdown, поведение при падениях, а также переходный план (Phase 1–6), на который теперь опирается `doc/TODO/todo-plan.md`.

### 2. Обновление knowledge‑документов под Autonomous Core

**Коммит:** `db6a3b5` — тот же коммит, что и выше (единый пакет док‑изменений)

- `doc/Project_Docs/knowledge/Local_Artifacts_Workflow.md`:
  - Уточнено, что с артефактами работают не только установщики VSIX, но и Core Supervisor.
  - Добавлен раздел об автономном ядре: скрипты `./scripts/build-*` + Supervisor обеспечивают **one‑shot install**, а UI‑клиенты больше не выполняют скрытых установок при старте.
  - В чек-лист релиза добавлена проверка, что ядро стартует через Supervisor без участия UI, а extension/launcher только подключаются.
- `doc/Project_Docs/knowledge/Quality Gate Manager/Project_Bootstrap_Quality_Guide.md`:
  - Добавлен раздел с дополнительными гейтами для Autonomous Core: проверка Supervisor (`start/stop/status`), attach‑only поведения клиентов, TTL/восстановления сессий и корректной деградации провайдеров.

### 3. Перезагрузка плана работ под Autonomous Core

**Коммит:** `db6a3b5` — отражение изменений в `doc/TODO/todo-plan.md`

- Полностью очищен старый план и подготовлен новый `doc/TODO/todo-plan.md` с фазами:
  - Phase 1 — архитектура и планирование (Autonomous Core, актуализация todo‑плана и knowledge‑доков).
  - Phase 2 — Core Supervisor Foundation.
  - Phase 3 — VS Code extension как attach‑only клиент.
  - Phase 4 — CEF launcher как attach‑only клиент.
  - Phase 5 — автономия провайдеров внутри ядра.
  - Phase 6 — TTL ядра и долгоживущие сессии.
  - Phase 7 — финальная синхронизация Architecture/SystemArchitecture после подтверждённого релиза.
- Для каждой задачи зафиксированы область (1–3 файла), статус и обязательное поле `Commit`. План теперь жёстко требует заполнять хеши коммитов сразу при переводе задачи в `DONE`.

### 4. Жёсткие правила синхронизации плана с Git

**Коммиты:** `db6a3b5` и обновления `AGENTS.md`

- В `doc/TODO/todo-plan.md` добавлены правила:
  - Задачу нельзя помечать `DONE` без фактического `Commit: <hash>`.
  - Строка `Phase N Commit` должна быть заполнена сразу после логического завершения фазы.
  - Перед завершением сессии обязательно сверять `git log -1` и `todo-plan`, чтобы план не отставал от истории Git.
- В `AGENTS.md` в секции `TODO Plan Template` эти правила продублированы как часть глобального шаблона, чтобы в будущем нельзя было забыть указать хеши коммитов в плане.

### 5. Core Supervisor — каркас CLI‑пакета

**Коммит:** `39ac133` — `feat(supervisor): scaffold CLI package`

- Создан новый workspace‑пакет `@codeai-hub/core-supervisor`:
  - `packages/core-supervisor/package.json` — описание пакета, `bin: { "codeai-core": "dist/index.js" }`, зависимость от `@codeai-hub/core`.
  - `packages/core-supervisor/tsconfig.json` — конфигурация TypeScript.
  - `packages/core-supervisor/src/index.ts` (начальная версия) — CLI‑скелет команд `start`, `stop`, `status`, `help`.
- Это первый шаг реализации **Core Supervisor** из `doc/AutonomousCore_Architecture.md` — появилось отдельное CLI, которое будет единым входом для управления ядром.

### 6. Реализация команды `start` в Supervisor (запуск автономного ядра)

**Коммит:** `ae0581c` — `feat(supervisor): allow starting local core from CLI`

- `packages/core-supervisor/src/index.ts`:
  - Реализован запуск ядра (`codeai-core start`) как отдельного процесса:
    - Определение entry point через `@codeai-hub/core/package.json` → `dist/index.js`.
    - Старт процесса `node <entryPoint>` в детаченном режиме с окружением `CORE_HOST`, `CORE_PORT`, `CORE_MANAGED_MODE=cli`.
  - Введены `--host`/`--port` опции для CLI с простым парсером аргументов.
  - Добавлен опрос `/api/v1/health` с таймаутом и ожиданием готовности ядра.
- Это приближает нас к модели, описанной в архитектурном документе: ядро может быть запущено **до** любого UI‑клиента, через Supervisor/CLI.

### 7. Реализация команд `stop` и `status` в Supervisor

**Коммит:** `2a68dfc` — `feat(supervisor): add stop and status commands`

- `packages/core-supervisor/src/index.ts` дополнен командами:
  - `codeai-core status` — читает `/api/v1/health` и печатает JSON‑состояние ядра (эндпоинт, статус, версия, pid), что позволяет увидеть, живо ли ядро и кто им управляет.
  - `codeai-core stop` — отправляет `POST /api/v1/shutdown`, затем ждёт фактического остановки, опрашивая `/health`.
- Эти команды реализуют базовый контракт Supervisor из `doc/AutonomousCore_Architecture.md`: устойчивый запуск/остановка ядра **без участия UI**.

### 8. Централизация runtime‑registry и core‑lock в Supervisor

**Коммит:** `0526942` — `feat(supervisor): manage runtime registry and lock`

- Добавлены модули состояния Supervisor:
  - `packages/core-supervisor/src/state/paths.ts` — единые пути к `~/.codeai-hub/state`, `runtime-registry.json`, `core-manager.lock`.
  - `packages/core-supervisor/src/state/runtime-registry.ts` — чтение/запись `runtime-registry.json`, в т.ч. полей `network.corePort`:
    - `recordCorePortPreference(port)` — обновляет предпочитаемый порт ядра.
    - `clearCorePortPreference()` — сбрасывает порт при остановке.
    - `readPreferredCorePort()` — чтение порта (будет использоваться extension/launcher через Supervisor на следующих фазах).
  - `packages/core-supervisor/src/state/core-lock.ts` — перенос логики `CoreManagerLock` из extension в Supervisor:
    - Создание и снятие `core-manager.lock` с проверкой живости процесса по PID.
- `packages/core-supervisor/src/index.ts` теперь:
  - При `start`:
    - Берёт lock через `CoreManagerLock("core-supervisor-cli")`, чтобы не конкурировать с другими менеджерами.
    - После успешного старта ядра записывает выбранный порт в runtime‑registry.
  - При `stop`:
    - После подтверждения остановки ядра очищает `corePort` в runtime‑registry.
- На уровне архитектуры это означает:
  - **Supervisor становится единственным владельцем lock‑файла и записи порта**, как и задумывалось в `AutonomousCore_Architecture.md`.
  - VS Code extension и лаунчер в следующих фазах будут читать порт и статус ядра через Supervisor, а не через свои локальные эвристики.

---

## Связь с `doc/AutonomousCore_Architecture.md`

В этой сессии мы начали фактическую реализацию документа `doc/AutonomousCore_Architecture.md`:

1. **Раздел "Core Supervisor (надзорный процесс ядра)"**:
   - Теперь существует реальный пакет `@codeai-hub/core-supervisor` с CLI `codeai-core`, который умеет:
     - стартовать ядро (`start`),
     - останавливать его (`stop`),
     - читать состояние (`status`).
   - Логика start/stop/status больше не привязана к VS Code extension или лаунчеру.

2. **Жизненный цикл ядра и независимость от UI**:
   - Через Supervisor ядро может быть запущено **до** любого UI и жить независимо от их рестартов.
   - Остановка ядра теперь оформлена как явная операция Supervisor (`codeai-core stop`), а не побочный эффект UI.

3. **Управление портом и lock‑файлом**:
   - Механика `core-manager.lock` и поля `network.corePort` в runtime‑registry перенесены в Supervisor, как это описано в архитектурном документе:
     - lock — для избежания гонок между несколькими менеджерами;
     - registry — единый источник данных о порте ядра для всех клиентов.

4. **Подготовка к attach‑only клиентам**:
   - Реализованный Supervisor — фундамент для следующего шага: перехода extension и лаунчера в режим attach‑only, когда они обращаются к Supervisor вместо того, чтобы управлять ядром напрямую.

---

## План на следующую сессию (продолжение по Phase 3)

Следующая сессия будет посвящена Phase 3 из `doc/TODO/todo-plan.md` — переводу VS Code extension в attach‑only режим с использованием Core Supervisor.

Ключевые задачи:

1. **Stream 3.1 — CoreProcessManager и запуск ядра**
   - Переписать `src/extension-module/core/core-process-manager.ts`, чтобы:
     - вместо `ensureCoreAndProviders`/`ensureStarted` использовать Supervisor (`codeai-core start` / будущий API);
     - убрать прямой запуск процесса ядра (`spawn` + env), полагаясь на уже реализованный `startCore` в Supervisor;
     - использовать status/health Supervisor для определения готовности ядра.
   - Обновить обработку ошибок запуска core в extension (`src/extension-module/logging/extension-logger.ts`), чтобы сообщения отражали ошибки Supervisor/ядра, а не локальные инсталляторы.

2. **Stream 3.2 — Порты, lock и keep‑alive**
   - Упростить `src/extension-module/core/core-port-manager.ts` и `core-port-candidates.ts`:
     - отказаться от собственного сканирования портов;
     - вместо этого использовать `network.corePort`, который ведёт Supervisor.
   - Обновить `src/extension-module/core/core-keep-alive.ts` и `core-process-notifiers.ts` так, чтобы:
     - при потере связи extension не перезапускал ядро, а запрашивал статус Supervisor и просто переподключался.

3. **Stream 3.3 — Команды VS Code и UX при старте ядра**
   - Перенастроить команды в `src/extension.ts` и `src/extension-module/home-view-message-router/command-handler.ts`:
     - "Open Home" / "Launch Web Client" должны инициировать `Supervisor.start()` и ждать готовности ядра;
     - любые административные действия по core должны быть обёртками над Supervisor, а не над установочными хелперами.
   - Обновить UX загрузки в `src/client/ui/src/core-bridge/core-bridge.ts` и `session-view/status-panel.tsx`:
     - пока Supervisor/ядро не готовы, UI должен явно показывать состояние "Starting core…"/"Core unavailable" с диагностикой;
     - после `ready` — просто подключаться и отображать текущие сессии.

Эти шаги приблизят систему к целевой архитектуре: ядро будет «жить» само по себе, а VS Code extension станет тонким клиентом, который только подключается к уже работающему автономному ядру через Core Supervisor.

